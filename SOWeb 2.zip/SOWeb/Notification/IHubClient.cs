﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SecondOpinionWeb.Notification
{
    public interface IHubClient
    {
        Task BroadcastMessage(string type, Message message);

    }
}
