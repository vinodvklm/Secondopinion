﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SecondOpinionWeb.Notification
{
    public class NotifyHub : Microsoft.AspNetCore.SignalR.Hub//<IHubClient>
    {
        public async Task BroadcastMessage(Message msg)
        {
            List<Message> msgLst = new List<Message>();
            msgLst.Add(msg);
            await Clients.All.SendCoreAsync("MessageReceived",msgLst.ToArray());
        }
        //public async Task BroadcastMessage(string type, string payload)
        //{
        //    await Clients.All.SendAsync("MessageReceived", msg);
        //    //throw new NotImplementedException();
        //}
    }
}
