﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using log4net;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SignalR;
using CommonUtils;
using SecondOpinionWeb.Notification;

namespace SecondOpinionWeb.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class NotificationController : ControllerBase
    {
        //private IHubContext<NotifyHub, IHubClient> _hubContext;
        //private ILog m_logger = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);
        //public NotificationController(IHubContext<NotifyHub, IHubClient> hubContext)
        //{
        //    _hubContext = hubContext;
        //}
        //[HttpPost]
        //public string Post([FromBody]Message msg)
        //{
        //    string retMessage = string.Empty;
        //    try
        //    {
        //        _hubContext.Clients.All.BroadcastMessage(msg.type, msg);//.clientuniqueid,msg.message
        //        retMessage = "Success";
        //    }
        //    catch (Exception e)
        //    {
        //        m_logger.Error(e.Message);
        //        retMessage = e.ToString();
        //    }
        //    return retMessage;
        //}
    }
}