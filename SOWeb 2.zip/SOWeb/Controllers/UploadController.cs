﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Threading.Tasks;
//using Microsoft.AspNetCore.Http;
//using Microsoft.AspNetCore.Mvc;
//using Microsoft.AspNetCore.Authorization;
//using Microsoft.EntityFrameworkCore;
//using Microsoft.Extensions.Configuration;
//using BusinessLib_VB;
//using SecondOpinionWeb.Dtos;
//using SecondOpinionWeb.Models;
//using SecondOpinionWeb.Repositories;
//using Microsoft.AspNetCore.Hosting;
//using System.IO;
//using System.Net.Http;
//using System.Net.Http.Headers;

//namespace SecondOpinionWeb.Controllers
//{
//    //[Authorize]
//    [Route("api/[controller]")]
//    [ApiController]
//    //[Produces("application/json")]
//    public class UploadController : ControllerBase
//    {
//        private readonly SecondOpinionDBContext _context;
//        private readonly IConfiguration _config;
//        private IWebHostEnvironment _hostingEnvironment;
//        public UploadController(IConfiguration config, SecondOpinionDBContext context, IWebHostEnvironment hostingEnvironment)
//        {
//            _context = context;
//            _config = config;
//            _hostingEnvironment = hostingEnvironment;
//        }

        
//        [HttpPost("upload_file"), DisableRequestSizeLimit]
//        public ActionResult UploadFile([FromBody] IFormFile file)//, string userId
//        {
//            UploadResult result = new UploadResult
//            {
//                Message = "",
//                Files = new List<UploadFilesLI>()
//            };
//            try
//            {
//                //var file = Request.Form.Files[0];
//                string folderName = "Resources/Upload";
//                string webRootPath = _hostingEnvironment.WebRootPath;
//                string newPath = Path.Combine(webRootPath, folderName);
//                if (!Directory.Exists(newPath))
//                {
//                    Directory.CreateDirectory(newPath);
//                }
//                if (file != null)
//                {
//                    if (file.Length > 0)
//                    {
//                        string fileName = ContentDispositionHeaderValue.Parse(file.ContentDisposition).FileName.Trim('"');
//                        string fullPath = Path.Combine(newPath, fileName);
//                        using (var stream = new FileStream(fullPath, FileMode.Create))
//                        {
//                            file.CopyTo(stream);
//                        }
//                        //result.FileName = fileName;
//                        //result.FullPath = fullPath;
//                        UploadFilesLI _li = new UploadFilesLI
//                        {
//                            FileName = fileName,
//                            FullPath = fullPath
//                        };
//                        result.Files.Add(_li);
//                    }
//                }
//                result.Message = "Upload Successful.";

//                return Ok(result);
//            }
//            catch (System.Exception ex)
//            {
//                result.Message = ex.Message;
//                return Ok(result);
//            }
//        }
//        [HttpPost("upload_file_test"), DisableRequestSizeLimit]
//        public JsonResult UploadFile()
//        {
//            try
//            {
//                var file = Request.Form.Files[0];
//                string folderName = "Upload";
//                string webRootPath = _hostingEnvironment.WebRootPath;
//                string newPath = Path.Combine(webRootPath, folderName);
//                if (!Directory.Exists(newPath))
//                {
//                    Directory.CreateDirectory(newPath);
//                }
//                if (file.Length > 0)
//                {
//                    string fileName = ContentDispositionHeaderValue.Parse(file.ContentDisposition).FileName.Trim('"');
//                    string fullPath = Path.Combine(newPath, fileName);
//                    using (var stream = new FileStream(fullPath, FileMode.Create))
//                    {
//                        file.CopyTo(stream);
//                    }
//                }
//                return new JsonResult("Upload Successful.");
//            }
//            catch (System.Exception ex)
//            {
//                return new JsonResult("Upload Failed: " + ex.Message);
//            }
//        }
//        [HttpPost("upload_doc"), DisableRequestSizeLimit]
//        public IActionResult UploadDoc(FileProvider fileProvider)//[FromForm]
//        {
//            //var files = fileProvider.Files;
//            var file = fileProvider.file;
//            var testString = fileProvider.testString;
//            UploadResult result = new UploadResult
//            {
//                Message = "",
//                Files = new List<UploadFilesLI>()
//            };
//            try
//            {
//                //var file = Request.Form.Files[0];
//                string folderName = "Resources/Upload";
//                string webRootPath = _hostingEnvironment.WebRootPath;
//                string newPath = Path.Combine(webRootPath, folderName);
//                if (!Directory.Exists(newPath))
//                {
//                    Directory.CreateDirectory(newPath);
//                }
//                //foreach (var file in files)
//                //{
//                    if (file != null)
//                    {
//                        if (file.Length > 0)
//                        {
//                            string fileName = ContentDispositionHeaderValue.Parse(file.ContentDisposition).FileName.Trim('"');
//                            string fullPath = Path.Combine(newPath, fileName);
//                            using (var stream = new FileStream(fullPath, FileMode.Create))
//                            {
//                                file.CopyTo(stream);
//                            }
//                            UploadFilesLI _li = new UploadFilesLI
//                            {
//                                FileName = fileName,
//                                FullPath = fullPath
//                            };
//                            result.Files.Add(_li);
//                        }
//                    }
//                //}
//                result.Message = "Upload Successful.";

//                return Ok(result);
//            }
//            catch (System.Exception ex)
//            {
//                result.Message = ex.Message;
//                return Ok(result);
//            }
//        }
//        [HttpPost("upload_contract_files"), DisableRequestSizeLimit]
//        public async Task<string> UploadProfilePicture([FromForm(Name = "uploadedFile")] IFormFile file, long userId)
//        {
//            if (file == null || file.Length == 0)
//                return ("Please select profile picture");

//            var folderName = Path.Combine("Resources", "ProfilePics");
//            var filePath = Path.Combine(Directory.GetCurrentDirectory(), folderName);

//            if (!Directory.Exists(filePath))
//            {
//                Directory.CreateDirectory(filePath);
//            }

//            var uniqueFileName = $"{userId}_profilepic.png";
//            var dbPath = Path.Combine(folderName, uniqueFileName);

//            using (var fileStream = new FileStream(Path.Combine(filePath, uniqueFileName), FileMode.Create))
//            {
//                await file.CopyToAsync(fileStream);
//            }

//            return dbPath;
//        }
//        [HttpPost("up_files"), DisableRequestSizeLimit]
//public IActionResult UploadF()
//        {
//            try
//            {
//                var file = Request.Form.Files[0];
//                var folderName = Path.Combine("Resources", "Images");
//                var pathToSave = Path.Combine(Directory.GetCurrentDirectory(), folderName);

//                if (file.Length > 0)
//                {
//                    var fileName = ContentDispositionHeaderValue.Parse(file.ContentDisposition).FileName.Trim('"');
//                    var fullPath = Path.Combine(pathToSave, fileName);
//                    var dbPath = Path.Combine(folderName, fileName);

//                    using (var stream = new FileStream(fullPath, FileMode.Create))
//                    {
//                        file.CopyTo(stream);
//                    }

//                    return Ok(new { dbPath });
//                }
//                else
//                {
//                    return BadRequest();
//                }
//            }
//            catch (Exception ex)
//            {
//                return StatusCode(500, "Internal server error");
//            }
//        }
//        [HttpPost("upload_filex"), DisableRequestSizeLimit]
//        public ActionResult UploadFileX(IFormFile file)//, string userId
//        {
//            UploadResult result = new UploadResult
//            {
//                Message = "",
//                Files = new List<UploadFilesLI>()
//            };
//            try
//            {
//                //var file = Request.Form.Files[0];
//                string folderName = "Resources/Upload";
//                string webRootPath = _hostingEnvironment.WebRootPath;
//                string newPath = Path.Combine(webRootPath, folderName);
//                if (!Directory.Exists(newPath))
//                {
//                    Directory.CreateDirectory(newPath);
//                }
//                if (file != null)
//                {
//                    if (file.Length > 0)
//                    {
//                        string fileName = ContentDispositionHeaderValue.Parse(file.ContentDisposition).FileName.Trim('"');
//                        string fullPath = Path.Combine(newPath, fileName);
//                        using (var stream = new FileStream(fullPath, FileMode.Create))
//                        {
//                            file.CopyTo(stream);
//                        }
//                        //result.FileName = fileName;
//                        //result.FullPath = fullPath;
//                        UploadFilesLI _li = new UploadFilesLI
//                        {
//                            FileName = fileName,
//                            FullPath = fullPath
//                        };
//                        result.Files.Add(_li);
//                    }
//                }
//                result.Message = "Upload Successful.";

//                return Ok(result);
//            }
//            catch (System.Exception ex)
//            {
//                result.Message = ex.Message;
//                return Ok(result);
//            }
//        }
//    }
    
//    //[HttpPost]
//    //[Route("UploadFile")]
//    //public HttpResponseMessage UploadFile()
//    //{
//    //    var httpRequest = System.Web.HttpContext.Current.Request;

//    //    CommonUtils.AttachmentCategory AttachmentCategory = CommonUtils.AttachmentCategory.AuthorityLogo;
//    //    CommonUtils.AttachmentFileType AttachmentFileType = CommonUtils.AttachmentFileType.Image;
//    //    bool IsThruApp = true;
//    //    long RowId = 0;
//    //    string FileName = "";
//    //    long UploadedBy = 0;
//    //    if (httpRequest.Form["AttachmentCategory"] != null)
//    //    {
//    //        try { AttachmentCategory = (CommonUtils.AttachmentCategory)Convert.ToInt32(httpRequest.Form["AttachmentCategory"]); }
//    //        catch { }
//    //    }
//    //    if (httpRequest.Form["AttachmentFileType"] != null)
//    //    {
//    //        try { AttachmentFileType = (CommonUtils.AttachmentFileType)Convert.ToInt32(httpRequest.Form["AttachmentFileType"]); }
//    //        catch { }
//    //    }
//    //    if (httpRequest.Form["IsThruApp"] != null)
//    //    {
//    //        try { bool.TryParse(httpRequest.Form["IsThruApp"].ToString(), out IsThruApp); }
//    //        catch { }
//    //    }
//    //    if (httpRequest.Form["RowId"] != null)
//    //    {
//    //        try { RowId = Convert.ToInt64(httpRequest.Form["RowId"]); }
//    //        catch { }
//    //    }
//    //    if (httpRequest.Form["FileName"] != null)
//    //    {
//    //        try { FileName = httpRequest.Form["FileName"].ToString(); }
//    //        catch { }
//    //    }
//    //    if (httpRequest.Form["UploadedBy"] != null)
//    //    {
//    //        try { UploadedBy = Convert.ToInt64(httpRequest.Form["UploadedBy"]); }
//    //        catch { }
//    //    }
//    //    AppModel.Models.ServiceModels.AttachmentModel Attachment = new AppModel.Models.ServiceModels.AttachmentModel
//    //    {
//    //        AttachmentCategory = AttachmentCategory,
//    //        AttachmentFileType = AttachmentFileType,
//    //        IsThruApp = IsThruApp,
//    //        RowId = RowId,
//    //        FileName = FileName,
//    //        UploadedBy = UploadedBy
//    //    };
//    //    // Check if the request contains multipart/form-data.
//    //    if (!Request.Content.IsMimeMultipartContent())
//    //    {
//    //        throw new HttpResponseException(HttpStatusCode.UnsupportedMediaType);
//    //    }
//    //    if (AttachmentCategory == CommonUtils.AttachmentCategory.AuthorityLogo || AttachmentCategory == CommonUtils.AttachmentCategory.EventFile|| AttachmentCategory==CommonUtils.AttachmentCategory.StickerInstallation)
//    //    {
//    //        Attachment.ImagePath = "Uploads/" + Attachment.AttachmentCategory.ToString() + "/" + Attachment.AttachmentFileType.ToString() + "/";
//    //    }
//    //    if (!Directory.Exists(AppDomain.CurrentDomain.BaseDirectory + Attachment.ImagePath))
//    //    {
//    //        // Try to create the directory.
//    //        DirectoryInfo di = Directory.CreateDirectory(AppDomain.CurrentDomain.BaseDirectory + Attachment.ImagePath);
//    //    }
//    //    Attachment.Root = AppDomain.CurrentDomain.BaseDirectory + Attachment.ImagePath;
//    //    var provider = new MultipartFormDataStreamProvider(Attachment.Root);
//    //    var result = CommonUtils.AsyncHelpers.RunSync<HttpResponseMessage>(() => _UploadFile(Request, provider, Attachment));
//    //    return result;
//    //}
//    //private async Task<HttpResponseMessage> _UploadFile(HttpRequestMessage Request, MultipartFormDataStreamProvider provider, AppModel.Models.ServiceModels.AttachmentModel model)
//    //{
//    //    return await Request.Content.ReadAsMultipartAsync(provider).
//    //        ContinueWith<HttpResponseMessage>
//    //        (o =>
//    //            {
//    //                string filePath = "";
//    //                bool isSuccess = false;
//    //                string msgError = "File failed.";
//    //                if (o.IsFaulted || o.IsCanceled)
//    //                    throw new HttpResponseException(HttpStatusCode.InternalServerError);
//    //                string msgSuccess = "File uploaded.";
//    //                foreach (var item in provider.FileData)
//    //                {
//    //                    FileInfo finfo = new FileInfo(item.LocalFileName);

//    //                    string guid = Guid.NewGuid().ToString();


//    //                    string sFileName = item.Headers.ContentDisposition.FileName.Replace("\"", "").Replace(" ", "");

//    //                    FileInfo FInfos = new FileInfo(Path.Combine(model.Root, guid + "_" + item.Headers.ContentDisposition.FileName.Replace("\"", "").Replace(" ", "")));

//    //                    var today = CommonUtils.Utils.CurrentDateTime;

//    //                    bool allowedToUpload = true;
//    //                    //if (model.AttachmentCategory == CommonUtils.AttachmentCategory.AuthorityLogo)
//    //                    //{
//    //                    //    AppModel.Models.AppSettingModel appSetting = AppModel.AppModelProvider.AppSetting.GetModel();
//    //                    //    if (appSetting != null)
//    //                    //    {
//    //                    //        long _currentCount = AppModel.AppModelProvider.WorkOrderFile.GetRequestId(model.RowId).Count;
//    //                    //        if (_currentCount >= appSetting.RequestImageLimit)
//    //                    //        {
//    //                    //            allowedToUpload = false;
//    //                    //            msgError += " Maximum number of allowable file uploads has been exceeded.";
//    //                    //        }
//    //                    //    }
//    //                    //}

//    //                    if (allowedToUpload)
//    //                    {
//    //                        File.Move(finfo.FullName, Path.Combine(model.Root, guid + "_" + item.Headers.ContentDisposition.FileName.Replace("\"", "").Replace(" ", "")));
//    //                        filePath = model.ImagePath + guid + "_" + item.Headers.ContentDisposition.FileName.Replace("\"", "").Replace(" ", "");
//    //                        //var FileURL = CommonUtils.Utils.UploadUrl + "/" + filePath;
//    //                        model.FileURL = CommonUtils.Utils.UploadUrl + "/" + filePath;
//    //                        if (model.RowId > 0)
//    //                        {
//    //                            isSuccess = UploadedFileSave(model);
//    //                        }
//    //                        else
//    //                        {
//    //                            isSuccess = true;
//    //                        }
//    //                    }
//    //                }
//    //                if (isSuccess && !string.IsNullOrEmpty(filePath))
//    //                    return Request.CreateResponse(HttpStatusCode.OK, string.Format("{0}|" + msgSuccess, CommonUtils.Utils.UploadUrl + "/" + filePath));
//    //                return Request.CreateResponse(HttpStatusCode.OK, string.Format(msgError));
//    //            }
//    //        );
//    //}
//    //private bool UploadedFileSave(AppModel.Models.ServiceModels.AttachmentModel model)
//    //{
//    //    bool isSuccess = false;
//    //    if (model.AttachmentCategory == CommonUtils.AttachmentCategory.AuthorityLogo)
//    //    {
//    //         isSuccess = AppModelProvider.AuthorityProvider.LogoUpdate(model.RowId, model.FileURL);
//    //    }
//    //    if (model.AttachmentCategory == CommonUtils.AttachmentCategory.EventFile)
//    //    {
//    //         isSuccess = AppModelProvider.EventProvider.EventFileCreate(model);
//    //    }
//    //    return isSuccess;
//    //}

//}