using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;

using Microsoft.Extensions.Configuration;
using SecondOpinionWeb.Models;
using log4net;
using System.Reflection;
using BusinessLib;

using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using Microsoft.IdentityModel.Tokens;
using Microsoft.AspNetCore.Http;

using Microsoft.Extensions.Options;
using SecondOpinionWeb;
using System.IO;
using System.Net.Http.Headers;
using System.Collections; 


namespace SecondOpinionWeb.Controllers
{
   
    [Route("api/[controller]")]
    [ApiController]

    public class BookingController : ControllerBase
    {
        
        private readonly IConfiguration _config;
        
        private ILog m_logger = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);

        public BookingController(IConfiguration config)
        {
            _config = config;
          
        }
        [HttpGet("get_doctor_available_date")]
        public IActionResult GetDoctorAvailableDate(int CommunicationTypeID)
        {
            
            List<DoctorAvailableDate> AvailableDates=new List<DoctorAvailableDate>();
            try
            {
                BookingProvider BookingProvider = new BookingProvider();
                var conStr = _config.GetConnectionString("SQLConnection");
                AvailableDates = BookingProvider.GetDoctorAvailableDate(_config,CommunicationTypeID);
                
                if(AvailableDates.Count!=0)
                {
                    return Ok(new{

                            status=1,
                            message="success",
                            AvailableDates = AvailableDates,
                    });
                }
                else
                {
                    return Ok(new{

                            status=0,
                            message="Failed",
                            
                    });
                }
            }
            catch(Exception ex)
            {
                m_logger.Error(ex.Message);
                return Content("Internal Server Error : " + ex.Message);
            }
            
        }
        [HttpGet("get_doctor_available_time")]
        public IActionResult GetDoctorAvailableTime(string date,int CommunicationTypeID)
        {
            
            List<DoctorAvailableTime> AvailableTimes=new List<DoctorAvailableTime>();
            try
            {
                BookingProvider BookingProvider = new BookingProvider();
                var conStr = _config.GetConnectionString("SQLConnection");
                AvailableTimes=BookingProvider.GetDoctorAvailableTime(_config,date,CommunicationTypeID);
                if(AvailableTimes.Count!=0)
                {
                    return Ok(new{

                            status=1,
                            message="success",
                            AvailableTimes=AvailableTimes,
                    });
                }
                else
                {
                    return Ok(new{

                            status=0,
                            message="Failed",
                            
                    });
                }
                
            }
            catch(Exception ex)
            {
                m_logger.Error(ex.Message);
                return Content("Internal Server Error : " + ex.Message);
            }   
        }
        
        [HttpPost("add_timeslotes")]
        public IActionResult AddDoctorAvailableTimes(AvailableDates req)
        {

            string ResultMessage=""; 
            try
            {
                DateTime d1=Convert.ToDateTime(req.FromTime);
                DateTime d2=Convert.ToDateTime(req.ToTime);

                int timeDiff = DateTime.Compare(d2, d1);
                if(timeDiff<0)
                {
                    return Ok(new {

                            status=0,
                            message=Messages.C_MSGBOX_MSG_DATE_ERROR
                            });

                }

                BookingProvider BookingProvider = new BookingProvider();
                var conStr = _config.GetConnectionString("SQLConnection");
                ResultMessage=BookingProvider.AddDoctorAvailableTimes(_config, ref req);

                
                if(ResultMessage!="")
                {
                    if(ResultMessage=="Success")
                    {
                        return Ok(new {
                        status=1,
                        message=ResultMessage,
                        });
                    }
                    else
                    {
                        return Ok(new {
                            status=0,
                            message=ResultMessage,
                            });
                    }
                    
                }
                else
                {
                     return Ok(new {
                        status=0,
                        message="Failed",
                    });
                }

                
            }
            catch(Exception ex)
            {
                m_logger.Error(ex.Message);
                return Content("Internal Server Error : " + ex.Message);
            }
        }
        [HttpGet("get_doctor_unavailable_date")]
        public IActionResult GetDoctorUnAvailableDate(int CommunicationTypeID)
        {
            
            List<DoctorUnAvailableDate> UnavailableDates=new List<DoctorUnAvailableDate>();
            try
            {
                BookingProvider BookingProvider = new BookingProvider();
                UnavailableDates=BookingProvider.GetDoctorUnAvailableDate(_config,CommunicationTypeID);
                
                if(UnavailableDates.Count!=0)
                {
                    return Ok(new{

                            status=1,
                            message="success",
                            UnavailableDates=UnavailableDates,
                    });
                }
                else
                {
                    return Ok(new{

                            status=0,
                            message="Failed",
                            
                    });
                }
            }
            catch(Exception ex)
            {
                m_logger.Error(ex.Message);
                return Content("Internal Server Error : " + ex.Message);
            }
            
        }

        [HttpGet("get_payment_history")]
        public IActionResult GetPaymentHistory(int UserID)
        {
            
            List<PaymentHistory> PaymentHistoryList=new List<PaymentHistory>();
            try
            {
                BookingProvider BookingProvider = new BookingProvider();
                var conStr = _config.GetConnectionString("SQLConnection");
                PaymentHistoryList=BookingProvider.GetPaymentHistory(_config,UserID);
                
                if(PaymentHistoryList.Count!=0)
                {
                    return Ok(new{

                            status=1,
                            message="success",
                            PaymentHistoryList=PaymentHistoryList,
                    });
                }
                else
                {
                    return Ok(new{

                            status=0,
                            message="Failed",
                            
                    });
                }
            }
            catch(Exception ex)
            {
                m_logger.Error(ex.Message);
                return Content("Internal Server Error : " + ex.Message);
            }
            
        }
    }
}