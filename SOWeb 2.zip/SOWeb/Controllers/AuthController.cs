
using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;

using Microsoft.Extensions.Configuration;
using SecondOpinionWeb.Models;
using log4net;
using System.Reflection;

using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using Microsoft.IdentityModel.Tokens;
using SecondOpinionWeb.Dtos;

namespace SecondOpinionWeb.Controllers
{

   [Route("api/[controller]")]
   [ApiController]

   public class AuthController : ControllerBase
   {
        
       private readonly IConfiguration _config;
       private ILog m_logger = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);

       public AuthController(IConfiguration config)
       {
           _config = config;
       }

       //Login

       [HttpPost("user_Login")]
       public async Task<IActionResult> Login(LoginDto loginDto)
       {
           string _id = string.Empty;
           string _email = string.Empty;
           string _name = string.Empty;
           string role = string.Empty;
           string _token = string.Empty;
           string _profilepic_url = string.Empty;
           string _role = string.Empty;
           
           LoginModel LoginInfo = new LoginModel();
           try
           {
               AuthProvider AuthProvider = new AuthProvider();
               LoginInfo = AuthProvider.Login(_config, loginDto.Email.ToLower(), loginDto.Password);

               if(LoginInfo==null)
               {
                   return Ok( new CRUDResponse
                   {
                       status=0,
                       message="Invalid username or password"
                   });
               }
               else
               {
                   _id = LoginInfo.UserID.ToString();
                   _email = LoginInfo.Email;
                   _name = LoginInfo.Name;
                   _profilepic_url = LoginInfo.Profile_Image_URL;
                    _role=LoginInfo.Role;
                   //Generate Token
                   var claims = new[]
                   {
                       new Claim(ClaimTypes.NameIdentifier, LoginInfo.UserID.ToString()),
                       new Claim(ClaimTypes.Name, LoginInfo.Username)
                   };


                   var key = new SymmetricSecurityKey(Encoding.UTF8
                   .GetBytes(_config.GetSection("AppSettings:Token").Value));

                   var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha512Signature);

                   var tokenDescriptor = new SecurityTokenDescriptor
                   {
                       Subject = new ClaimsIdentity(claims),
                       Expires = DateTime.Now.AddDays(1),
                       SigningCredentials = creds
                   };    
                   var tokenHandler = new JwtSecurityTokenHandler();
                   var token = tokenHandler.CreateToken(tokenDescriptor);
                   _token = tokenHandler.WriteToken(token);

                      return Ok(new{status=1,message="Successfully Logined",data=new{id = _id,fullname = _name,email = _email,token = _token,  profilepic_url= _profilepic_url, role=_role}  });
               
               }
               
           }
           catch (Exception ex)
           {

               m_logger.Error(ex.Message);
               return Content("Internal Server Error : " + ex.Message);
           }
            
       }

   }
       
}