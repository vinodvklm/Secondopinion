﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SecondOpinionWeb.Models;
using log4net;
using SecondOpinionWeb;
using Microsoft.Extensions.Configuration;
using System.Reflection;
using Microsoft.Extensions.Options;

namespace SOWeb.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DownloadController : ControllerBase
    {
        private readonly IConfiguration _config;
        private AppSettings AppSettings { get; set; }
        private ILog m_logger = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);

        public DownloadController(IConfiguration config, IOptions<AppSettings> settings)
        {
            _config = config;
            AppSettings = settings.Value;
        }

        ////GET api/download/12345abc
        //[HttpGet("{documentPath}/{uPath}/{fileName}")]
        //public async Task<IActionResult> Download(string documentPath,string uPath,string fileName)
        //{
        //    string path = Path.Combine(documentPath, uPath,fileName);
        //    Stream stream = System.IO.File.OpenRead(path);//await { { __get_stream_based_on_id_here__} }

        //    if (stream == null)
        //        return NotFound(); // returns a NotFoundResult with Status404NotFound response.

        //    return File(stream, "application/octet-stream"); // returns a FileStreamResult
        //}
        [HttpGet("{id}")]
        public async Task<IActionResult> DownloadFile(int id)
        {
            //var path = "<Get the file path using the ID>";
            //var stream = File.OpenRead(path);
            //return new FileStreamResult(stream, "application/octet-stream");
            DocumentUploadProvider documentUploadProvider = new DocumentUploadProvider();
            var doc=documentUploadProvider.GetDocumentDetails(_config,id);
            if (doc != null)
            {
                string path = doc.DocumentPath.Replace(AppSettings.RootUrl,"");//.Replace(doc.FileName,"")
                Stream stream = System.IO.File.OpenRead(path);//await { { __get_stream_based_on_id_here__} }

                if (stream == null)
                    return NotFound(); // returns a NotFoundResult with Status404NotFound response.

                return File(stream, "application/octet-stream",doc.FileName); // returns a FileStreamResult
            }
            else
                return null;
        }
    }
}
