
using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;

using Microsoft.Extensions.Configuration;
using SecondOpinionWeb.Models;
using log4net;
using System.Reflection;

using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using Microsoft.IdentityModel.Tokens;
using SecondOpinionWeb.Dtos;

namespace SecondOpinionWeb.Controllers
{

   [Route("api/[controller]")]
   [ApiController]

   public class DoctorController : ControllerBase
   {
        
       private readonly IConfiguration _config;
       private ILog m_logger = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);

       public DoctorController(IConfiguration config)
       {
           _config = config;
       }

        #region Get dicom uploaded user list
        [HttpGet("get_dicom_uploaded_user")]
        public async Task<IActionResult> GetDicomUploadedUser()
        {
            try
            {

                DoctorProvider DoctorProvider = new DoctorProvider();
                var conStr = _config.GetConnectionString("SQLConnection");
                var UserList = DoctorProvider.GetDicomUploadedUser(_config);

                var List = UserList.
                                    GroupBy(a => new {
                                        a.UserID,
                                        a.DocumentName,
                                        a.ReportDate,
                                        a.UserDocumentFK,
                                        a.ValidFrom,
                                        a.ValidTo,
                                        a.Name,
                                        a.Email,
                                        a.Gender,
                                        a.Age,
                                        a.MobileNumber,
                                        a.Profile_Image_URL,
                                        a.DependentName,
                                        a.DependentID,
                                        a.DependentAge,
                                        a.DependentGender,
                                        a.DependentProfile_Image_URL,
                                        a.UserType

                                    }).Select(g => new {

                                        UserDetails = g.Key,
                                        DocumentPath = g.Select(p => new {
                                            p.DocumentPath,
                                            p.UserDocumentDetailID,
                                            p.FileName
                                        })
                                    }).ToList();
                return Ok(new
                {
                    status = 1,
                    message = "Success",
                    list = List
                });

            }
            catch (Exception ex)
            {
                m_logger.Error(ex.Message);
                return Content("Internal Server Error : " + ex.Message);
            }

        }

        #endregion

        #region Get dicom uploaded user list
        [HttpGet("get_dicom_by_userid")]
        public async Task<IActionResult> GetDicomByUserID(int UserID)
        {
            try
            {

                DoctorProvider DoctorProvider = new DoctorProvider();
                var conStr = _config.GetConnectionString("SQLConnection");
                var DicomList = DoctorProvider.GetDicomByUserID(_config, UserID);

                var List = DicomList.
                                    GroupBy(a => new {
                                        a.UserID,
                                        a.DocumentName,
                                        a.ReportDate,
                                        a.ValidFrom,
                                        a.ValidTo,
                                        a.UserDocumentID
                                        
                                    }).Select(g => new {

                                        DocumentDetails = g.Key,
                                        DocumentPath = g.Select(p => new {
                                            p.DocumentPath,
                                            p.UserDocumentID,
                                            p.UserDocumentDetailID,
                                            p.FileName
                                        })
                                    }).ToList();
                return Ok(new
                {
                    status = 1,
                    message = "Success",
                    list = List
                });

            }
            catch (Exception ex)
            {
                m_logger.Error(ex.Message);
                return Content("Internal Server Error : " + ex.Message);
            }

        }

        #endregion
        #region Get Patient details
        [HttpGet("get_patient_list")]
        public async Task<IActionResult> GetPatientist()
        {
            try
            {

                DoctorProvider DoctorProvider = new DoctorProvider();
                var conStr = _config.GetConnectionString("SQLConnection");
                var PatientList = DoctorProvider.GetPatientist(_config);
                return Ok(new
                {
                    status = 1,
                    message = "Success",
                    list = PatientList
                });

            }
            catch (Exception ex)
            {
                m_logger.Error(ex.Message);
                return Content("Internal Server Error : " + ex.Message);
            }

        }
        #endregion

        #region Get document details
        [HttpGet("get_document_details")]
        public async Task<IActionResult> GetDocumentDetail(int UserID,int DependentID)
        {
            try
            {

                DoctorProvider DoctorProvider = new DoctorProvider();
                var conStr = _config.GetConnectionString("SQLConnection");
                var list = DoctorProvider.GetDocumentDetail(_config, UserID, DependentID);

                var _GroupedList = list.
                                    GroupBy(a => new {
                                        a.DocumentName,
                                        a.ReportDate,
                                        a.UserDocumentID,
                                    }).Select(g => new {

                                        Document = g.Key,
                                        DocumentDetails = g.Select(p => new {
                                            p.UserDocumentDetailID,
                                            p.DocumentPath,
                                            p.FileName
                                        })
                                    }).ToList();

                return Ok(new
                {
                    status = 1,
                    message = "Success",
                    list = _GroupedList
                });

            }
            catch (Exception ex)
            {
                m_logger.Error(ex.Message);
                return Content("Internal Server Error : " + ex.Message);
            }

        }

        #endregion

        #region Get dashboard
        [HttpGet("get_doctor_dashabord")]
        public async Task<IActionResult> GetDoctorDashboard()
        {
            try
            {

                DoctorProvider DoctorProvider = new DoctorProvider();
                var conStr = _config.GetConnectionString("SQLConnection");
                var dashboardInfo = DoctorProvider.GetDoctorDashboard(_config);
                var bookedSlotsInfo= DoctorProvider.GetbookedSlots(_config);
                var thisWeekConsulationList = DoctorProvider.GetThisWeekConsulationList(_config);
                return Ok(new
                {
                    status = 1,
                    message = "Success",
                    dashboardInfo = dashboardInfo,
                    bookedSlotsInfo= bookedSlotsInfo,
                    thisWeekConsulationList = thisWeekConsulationList,
                });

            }
            catch (Exception ex)
            {
                m_logger.Error(ex.Message);
                return Content("Internal Server Error : " + ex.Message);
            }

        }

        #endregion

        #region Add communication types
        [HttpPost("add_communicationtype")]
        public async Task<IActionResult> AddCommunicationType(CommunicationTypes req)
        {
            try
            {
                bool insertedFlag=false;
                DoctorProvider DoctorProvider = new DoctorProvider();
                var conStr = _config.GetConnectionString("SQLConnection");
                insertedFlag=DoctorProvider.AddCommunicationType(_config, ref req);
                if(insertedFlag)
                {
                    return Ok(new
                    {
                            status=1,
                            message="success" ,
                    });  
                }
                else
                {
                    return Ok(new
                    {
                            status=0,
                            message="failed" ,
                    });
                }  
                 
            }
            catch(Exception ex)
            {
                 m_logger.Error(ex.Message);
                return Content("Internal Server Error : " + ex.Message);
            }
        }

        #endregion

        #region Update communication types
        [HttpPost("update_communicationtype")]
        public async Task<IActionResult> UpdateCommunicationType(CommunicationTypes req)
        {
            try
            {
                bool insertedFlag=false;
                 DoctorProvider DoctorProvider = new DoctorProvider();
                var conStr = _config.GetConnectionString("SQLConnection");
                insertedFlag=DoctorProvider.UpdateCommunicationType(_config, ref req);
                if(insertedFlag)
                {
                    return Ok(new
                    {
                            status=1,
                            message="success" ,
                    });  
                }
                else
                {
                    return Ok(new
                    {
                            status=0,
                            message="failed" ,
                    });
                }  
                 
            }
            catch(Exception ex)
            {
                 m_logger.Error(ex.Message);
                return Content("Internal Server Error : " + ex.Message);
            }
        }

        #endregion

        #region Today's appointment
        [HttpGet("get_today_appointments")]
        public async Task<IActionResult> GetTodayAppointmentList(int CommunicationTypeID,int SearchType,int PatientID)
        {
            try
            {

                DoctorProvider DoctorProvider = new DoctorProvider();
                var conStr = _config.GetConnectionString("SQLConnection");
                var PatientList = DoctorProvider.GetTodayAppointmentList(_config, CommunicationTypeID, SearchType, PatientID);
                return Ok(new
                {
                    status = 1,
                    message = "Success",
                    list = PatientList
                });

            }
            catch (Exception ex)
            {
                m_logger.Error(ex.Message);
                return Content("Internal Server Error : " + ex.Message);
            }

        }
        #endregion

        #region Get application settings
        [HttpGet("get_app_settings")]
        public async Task<IActionResult> GetAppSettings()
        {
            try
            {

                DoctorProvider DoctorProvider = new DoctorProvider();
                var conStr = _config.GetConnectionString("SQLConnection");
                var AppSettings = DoctorProvider.GetAppSettings(_config);
                return Ok(new
                {
                    status = 1,
                    message = "Success",
                    data = AppSettings
                });

            }
            catch (Exception ex)
            {
                m_logger.Error(ex.Message);
                return Content("Internal Server Error : " + ex.Message);
            }

        }
        #endregion

        #region Get ConsultationStatus list
        [HttpGet("get_consultation_status")]
        public async Task<IActionResult> GetConsultationStatus()
        {
            try
            {

                DoctorProvider DoctorProvider = new DoctorProvider();
                var conStr = _config.GetConnectionString("SQLConnection");
                var List = DoctorProvider.GetConsultationStatus(_config);
                return Ok(new
                {
                    status = 1,
                    message = "Success",
                    List = List
                });

            }
            catch (Exception ex)
            {
                m_logger.Error(ex.Message);
                return Content("Internal Server Error : " + ex.Message);
            }

        }
        #endregion

        #region save consultation details
        [HttpPost("add_consultation_details")]
        public IActionResult AddConsultationDetail(ConsultationDetailModel req)
        {

            bool Resultflag = false;
            try
            {
                DoctorProvider DoctorProvider = new DoctorProvider();
                var conStr = _config.GetConnectionString("SQLConnection");
                Resultflag = DoctorProvider.AddConsultationDetail(_config, ref req);
                if (Resultflag)
                {
                    return Ok(new CRUDResponse
                    {
                        status = 1,
                        message = "Successfully added"
                    });
                }
                else
                {
                    return Ok(new CRUDResponse
                    {
                        status = 0,
                        message ="Failed"
                    });
                }
            }
            catch (Exception ex)
            {
                m_logger.Error(ex.Message);
                return Content("Internal Server Error : " + ex.Message);
            }
        }
        #endregion

        #region Get timeslots by date wise
        [HttpGet("get_datewise_timeslots")]
        public async Task<IActionResult> GetDatewiseTimeslots(int CommunicationTypeID,string date)
        {
            try
            {

                DoctorProvider DoctorProvider = new DoctorProvider();
                var conStr = _config.GetConnectionString("SQLConnection");
                var List = DoctorProvider.GetDatewiseTimeslots(_config,CommunicationTypeID,date);
                return Ok(new
                {
                    status = 1,
                    message = "Success",
                    List = List
                });

            }
            catch (Exception ex)
            {
                m_logger.Error(ex.Message);
                return Content("Internal Server Error : " + ex.Message);
            }

        }
        #endregion

        #region Get allocated timeslots
        [HttpGet("get_allocated_timeslots")]
        public async Task<IActionResult> GetAllocatedTimeslots()
        {
            try
            {

                DoctorProvider DoctorProvider = new DoctorProvider();
                var conStr = _config.GetConnectionString("SQLConnection");
                var List = DoctorProvider.GetAllocatedTimeslots(_config);
                return Ok(new
                {
                    status = 1,
                    message = "Success",
                    List = List
                });

            }
            catch (Exception ex)
            {
                m_logger.Error(ex.Message);
                return Content("Internal Server Error : " + ex.Message);
            }

        }
        #endregion

        #region Get allocated timeslot details
        [HttpGet("get_allocated_timeslot_details")]
        public async Task<IActionResult> GetAllocatedTimeslotDetails(string AvailableDate,string CommunicationType)
        {
            try
            {

                DoctorProvider DoctorProvider = new DoctorProvider();
                var conStr = _config.GetConnectionString("SQLConnection");
                var List = DoctorProvider.GetAllocatedTimeslotDetails(_config,AvailableDate,CommunicationType);
                return Ok(new
                {
                    status = 1,
                    message = "Success",
                    List = List
                });

            }
            catch (Exception ex)
            {
                m_logger.Error(ex.Message);
                return Content("Internal Server Error : " + ex.Message);
            }

        }
        #endregion

        #region Get questionnaire report
        [HttpGet("get_questionnaire_report")]
        public async Task<IActionResult> GetQuestionnaireReport(int UserID)
        {
            try
            {

                DoctorProvider DoctorProvider = new DoctorProvider();
                var conStr = _config.GetConnectionString("SQLConnection");
                string rpt = DoctorProvider.GetQuestionnaireReport(_config, UserID);
                if(rpt!=null)
                {
                    return Ok(new
                    {
                        status = 1,
                        message = "Success",
                        report = rpt
                    });
                }
                else
                {
                    return Ok(new
                    {
                        status = 0,
                        message = "Failed"
                    });
                }
               

            }
            catch (Exception ex)
            {
                m_logger.Error(ex.Message);
                return Content("Internal Server Error : " + ex.Message);
            }

        }
        #endregion
    }


}