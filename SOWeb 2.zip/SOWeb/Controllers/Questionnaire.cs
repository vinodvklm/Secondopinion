using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;

using Microsoft.Extensions.Configuration;
using SecondOpinionWeb.Models;
using log4net;
using System.Reflection;
using BusinessLib;

using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using Microsoft.IdentityModel.Tokens;
using Microsoft.AspNetCore.Http;

using Microsoft.Extensions.Options;
using SecondOpinionWeb;
using CommonUtils;

namespace SecondOpinionWeb.Controllers
{
   
    [Route("api/[controller]")]
    [ApiController]

    public class QuestionnaireController : ControllerBase
    {
        
        private readonly IConfiguration _config;
        private AppSettings AppSettings { get; set; }
        private MailSettings MailSettings { get; set; }

        private ILog m_logger = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);

        public QuestionnaireController(IConfiguration config,IOptions<AppSettings> settings, IOptions<MailSettings> mailsettings)
        {
            _config = config;
            AppSettings = settings.Value;
            MailSettings = mailsettings.Value;
        }

        [HttpGet("getQuestions")]
        public async Task<IActionResult> GetQuestions(int FormID,int SectionNumber, int UserID=0, int PatientID=0)
        {
            
            List<Form> Q_FormList=new List<Form>();
            try
            {
                List<Form> FormList=new List<Form>();

                QuestionnaireProvider Q_Provider = new QuestionnaireProvider();
                var sectionSubmission = Q_Provider.GetSavedSection(_config,FormID, UserID, PatientID, SectionNumber);
                List<PainSpots> sectionPainSpots = null;
                List<PainLocation> sectionPainLocatons = null;
                List<PainMedication> sectionPainMedications = null;
                if (SectionNumber == (int)SectionNumbers.PainLocations)
                {
                    sectionPainSpots = Q_Provider.GetSavedPainSpots(_config, FormID, UserID, PatientID, SectionNumber);
                    sectionPainLocatons = Q_Provider.GetSavedPainLocation(_config, FormID, UserID, PatientID, SectionNumber); 
                }
                if (SectionNumber == (int)SectionNumbers.PainMedications)
                {
                    sectionPainMedications = Q_Provider.GetSavedPainMedications(_config, FormID, UserID, PatientID, SectionNumber);
                }
                FormList = Q_Provider.GetFormDetails(_config,FormID);
                
                
                for(var i=0;i< FormList.Count;i++)
                {
                    Form FormInfo=new Form();
                    FormInfo.FormID=FormList[i].FormID;
                    FormInfo.FormName=FormList[i].FormName;
                    FormInfo.FormType=FormList[i].FormType;
                    FormInfo.IsActive=FormList[i].IsActive;

                    List<Question> QuestionList=new List<Question>();
                    QuestionList=Q_Provider.GetQuestions(_config,FormID, SectionNumber);

                    List<Question> Temp_QuestionList=new List<Question>();
                    for(var j=0; j< QuestionList.Count; j++)
                    {
                        Question QuestionInfo=new Question();
                        QuestionInfo.QuestionID=QuestionList[j].QuestionID;
                        QuestionInfo.FormFK=QuestionList[j].FormFK;
                        QuestionInfo.QuestionTitle=QuestionList[j].QuestionTitle;
                        QuestionInfo.IsActive=QuestionList[j].IsActive;
                        QuestionInfo.IsMandatory=QuestionList[j].IsMandatory;
                        QuestionInfo.InputDataTypeName=QuestionList[j].InputDataTypeName;
                        QuestionInfo.InputDataType=QuestionList[j].InputDataType;
                        QuestionInfo.InputControlTypeName=QuestionList[j].InputControlTypeName;
                        QuestionInfo.InputControlType=QuestionList[j].InputControlType;
                        QuestionInfo.HasComments=QuestionList[j].HasComments;
                        QuestionInfo.CreatedBy=QuestionList[j].CreatedBy;
                        QuestionInfo.CreatedOn=QuestionList[j].CreatedOn;
                        QuestionInfo.PlaceholderText=QuestionList[j].PlaceholderText;
                        QuestionInfo.InputLabel=QuestionList[j].InputLabel;
                        QuestionInfo.ColumnWidth=QuestionList[j].ColumnWidth;
                        QuestionInfo.IsSection=QuestionList[j].IsSection;
                        QuestionInfo.TableType=QuestionList[j].TableType;
                        QuestionInfo.SectionNumber = QuestionList[j].SectionNumber;
                        QuestionInfo.SectionHeader = QuestionList[j].SectionHeader;
                        QuestionInfo.DisplayControlType = QuestionList[j].DisplayControlType;
                        QuestionInfo.DisplayHeader = QuestionList[j].DisplayHeader;
                        QuestionInfo.MaxLength = QuestionList[j].MaxLength;



                        List<QuestionOption> QuestionOptionList=new List<QuestionOption>();
                        QuestionOptionList=Q_Provider.GetQuestionOptions(_config,QuestionInfo.QuestionID);
                        
                        List<QuestionOption> Temp_QuestionOptionList=new List<QuestionOption>();
                        for(var k=0; k< QuestionOptionList.Count;k++)
                        {
                            QuestionOption QuestionOptionInfo=new QuestionOption();
                            QuestionOptionInfo.QuestionOptionID=QuestionOptionList[k].QuestionOptionID;
                            QuestionOptionInfo.QuestionFK=QuestionOptionList[k].QuestionFK;
                            QuestionOptionInfo.OptionText=QuestionOptionList[k].OptionText;
                            Temp_QuestionOptionList.Add(QuestionOptionInfo);
                        }
                        QuestionInfo.QuestionOptions=Temp_QuestionOptionList;//Add question option list

                        List<QuestionParentBranch> ParentBranchesList=new List<QuestionParentBranch>();
                        ParentBranchesList=Q_Provider.GetParentBranches(_config,QuestionInfo.QuestionID);
                        List<QuestionParentBranch> Temp_QuestionParentBranchesList=new List<QuestionParentBranch>();

                        for(var l=0;l<ParentBranchesList.Count;l++)
                        {
                            QuestionParentBranch ParentBranchInfo=new QuestionParentBranch();
                            ParentBranchInfo.QuestionBranchID=ParentBranchesList[l].QuestionBranchID;
                            ParentBranchInfo.ChildQuestionFK=ParentBranchesList[l].ChildQuestionFK;
                            ParentBranchInfo.ParentQuestionFK=ParentBranchesList[l].ParentQuestionFK;
                            ParentBranchInfo.ParentQuestionOptionFK=ParentBranchesList[l].ParentQuestionOptionFK;
                            Temp_QuestionParentBranchesList.Add(ParentBranchInfo);
                        }
                        QuestionInfo.QuestionParentBranches=Temp_QuestionParentBranchesList;// Add question branch list

                        List<QuestionChildBranch> ChildBranchList=new List<QuestionChildBranch>();
                        ChildBranchList=Q_Provider.GetChildBranches(_config,QuestionInfo.QuestionID);
                        List<QuestionChildBranch> Temp_QuestionChildBranchesList=new List<QuestionChildBranch>();

                        for(var m=0;m<ChildBranchList.Count;m++)
                        {
                            QuestionChildBranch ChildBranchInfo=new QuestionChildBranch();
                            ChildBranchInfo.QuestionBranchID=ChildBranchList[m].QuestionBranchID;
                            ChildBranchInfo.ChildQuestionFK=ChildBranchList[m].ChildQuestionFK;
                            ChildBranchInfo.ParentQuestionFK=ChildBranchList[m].ParentQuestionFK;
                            ChildBranchInfo.ParentQuestionOptionFK=ChildBranchList[m].ParentQuestionOptionFK;
                            Temp_QuestionChildBranchesList.Add(ChildBranchInfo);
                        }
                        QuestionInfo.QuestionChildBranches=Temp_QuestionChildBranchesList;// Add question child list

                        Temp_QuestionList.Add(QuestionInfo);
                    }
                    FormInfo.Questions=Temp_QuestionList;

                    Q_FormList.Add(FormInfo);
                }

   

                var li = Q_FormList[0].Questions.
                              GroupBy(a => new {
                                  a.SectionNumber
                              }).Select(g => new {

                                  SectionNumber = g.Key,
                                  Questions = g.Select(p => new {
                                      p.QuestionID,
                                      p.QuestionTitle,
                                      p.InputControlType,
                                      p.InputControlTypeName,
                                      p.InputDataType,
                                      p.InputLabel,
                                      p.IsActive,
                                      p.IsMandatory,
                                      p.IsSection,
                                      p.QuestionChildBranches,
                                      p.QuestionOptions,
                                      p.QuestionParentBranches,
                                      p.Range,
                                      p.SectionNumber,
                                      p.TableType,
                                      p.ToolTipText,
                                      p.HasComments,
                                      p.FormFK,
                                      p.ColumnWidth,
                                      p.SectionHeader,
                                      p.DisplayControlType,
                                      p.DisplayHeader,
                                      p.MaxLength
                                  }),
                                  Submissions= sectionSubmission,
                                  PainSpots = sectionPainSpots,
                                  PainLocations = sectionPainLocatons,
                                  PainMedications = sectionPainMedications
                              }).ToList();
                return Ok( 
                            new 
                            { 
                                status=1, 
                                MessageTypeString="Success",
                                Result = li
                            } 
                        );
               
            }
            catch (Exception ex)
            {                
                 m_logger.Error(ex.Message);
                return Content("Internal Server Error : " + ex.Message);
            }

        }

        [HttpPost("saveQuestionnaire")]
        public async Task<IActionResult> SaveQuestionnaire(QuestionnaireInfo req)
        {
            bool flag=false;
            try
            {
                QuestionnaireProvider QuestionnaireProvider = new QuestionnaireProvider();
                var conStr = _config.GetConnectionString("SQLConnection");
                flag=QuestionnaireProvider.SaveQuestionnaire(_config, ref req);

                if(flag)
                {
                    return Ok(new{
                        status=1,
                        message="success"
                    });
                }
                else
                {
                    return Ok(new{
                        status=0,
                        message="failed"
                    });
                }
                
            }
            catch(Exception ex)
            {

            }
            
        


            return Ok( 
                            new 
                            { 
                                id=req.UserID,
                                 status=req.FormID, 
                                MessageTypeString=req.FormSubmitted,
                             
                            } 
                        );
        }

        [HttpGet("get_last_saved_section")]
        public async Task<IActionResult> GetLastSavedSection(int FormID,int UserID,int PatientID)
        {
            try
            {
                QuestionnaireProvider QuestionnaireProvider = new QuestionnaireProvider();
                int SectionNumber = QuestionnaireProvider.GetLastSavedSection(_config,FormID, UserID, PatientID);

                return Ok(new
                {
                    SectionNumber = SectionNumber
                });
            }
            catch(Exception ex)
            {
                m_logger.Error(ex.Message);
                return Content("Internal Server Error : " + ex.Message);
            }
        }
    }
}