using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;

using Microsoft.Extensions.Configuration;
using SecondOpinionWeb.Models;
using log4net;
using System.Reflection;
using BusinessLib;

using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using Microsoft.IdentityModel.Tokens;
using Microsoft.AspNetCore.Http;

using Microsoft.Extensions.Options;
using SecondOpinionWeb;


namespace SecondOpinionWeb.Controllers
{
   
    [Route("api/[controller]")]
    [ApiController]

    public class UserController : ControllerBase
    {
        
        private readonly IConfiguration _config;
                    
        private AppSettings AppSettings { get; set; }
        private MailSettings MailSettings { get; set; }

        private ILog m_logger = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);

        public UserController(IConfiguration config,IOptions<AppSettings> settings, IOptions<MailSettings> mailsettings)
        {
            _config = config;
            AppSettings = settings.Value;
            MailSettings = mailsettings.Value;
        }

        //User Registration
        [HttpPost("add_user")]
        public async Task<IActionResult> AddUser(UserModel req)
        {
            UserRegModel UserRegInfo = new UserRegModel();
            string _id = string.Empty;
            string _email = string.Empty;
            string _name = string.Empty;
            string role = string.Empty;
            string _token = string.Empty;
            string _profilepic_url = string.Empty; 
            string _role = string.Empty;

            try
            {
                if (req == null)
                {
                    return BadRequest( new CRUDResponse
                    {
                        status=0,
                        message="Data required"
                    });
                }
               

                UserProvider UserProvider = new UserProvider();
                var conStr = _config.GetConnectionString("SQLConnection");
                UserRegInfo=UserProvider.AddUser(_config, ref req);

                if(UserRegInfo==null)
                {
                    return Ok( new CRUDResponse
                    {
                        status=0,
                        message=Messages.C_MSGBOX_TITLE_USERNAME_EXIST
                    });
                }
                if(UserRegInfo!=null)
                {

                    _id = UserRegInfo.UserID.ToString();
                    _email = UserRegInfo.Email;
                    _name = UserRegInfo.Name;
                    _profilepic_url = UserRegInfo.Profile_Image_URL;
                    _role=UserRegInfo.Role;
                   
                    //Generate Token
                    var claims = new[]
                    {
                        new Claim(ClaimTypes.NameIdentifier, UserRegInfo.UserID.ToString()),
                        new Claim(ClaimTypes.Name, UserRegInfo.Username)
                    };


                    var key = new SymmetricSecurityKey(Encoding.UTF8
                            .GetBytes(_config.GetSection("AppSettings:Token").Value));

                    var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha512Signature);

                    var tokenDescriptor = new SecurityTokenDescriptor
                    {
                        Subject = new ClaimsIdentity(claims),
                        Expires = DateTime.Now.AddDays(1),
                        SigningCredentials = creds
                    };    
                    var tokenHandler = new JwtSecurityTokenHandler();
                    var token = tokenHandler.CreateToken(tokenDescriptor);
                    _token = tokenHandler.WriteToken(token);

                    return Ok(new{status=1,message=Messages.C_MSGBOX_TITLE_ADD_NEW_USER,data=new{id = _id,fullname = _name,email = _email,token = _token,  profilepic_url= _profilepic_url, role=_role }  });
             
                }
                else
                {
                    return BadRequest( new CRUDResponse
                    {
                        status=0,
                        message = Messages.C_MSGBOX_MSG_FAILED_ADD_USER
                    });
                }
                
            }
            catch (Exception ex)
            {
                m_logger.Error(ex.Message);
                return Content("Internal Server Error : " + ex.Message);
            }

        }
        [HttpPost("update_user")]
        public async Task<IActionResult> UpdateUser(UserModel req)
        {
            UserModel UserInfo = new UserModel();
            
            try
            {
                if (req == null)
                {
                    return BadRequest( new CRUDResponse
                    {
                        status=0,
                        message="Data required"
                    });
                }
                
                UserProvider UserProvider = new UserProvider();
                var conStr = _config.GetConnectionString("SQLConnection");
                UserInfo=UserProvider.UpdateUser(_config, ref req);
                return Ok( new { status=1, message="Success",UserDetails = UserInfo} );
                
                
            }
            catch (Exception ex)
            {
                m_logger.Error(ex.Message);
                return Content("Internal Server Error : " + ex.Message);
            }

        }

        //Forgot password

        [HttpPost("forgot_password")]
        [AllowAnonymous]
        public async Task<IActionResult> ForgotPassword(ForgotPasswordRequest req)
        {
            bool UserExistFlag=false;
            try
            {
                UserProvider UserProvider = new UserProvider();
                var conStr = _config.GetConnectionString("SQLConnection");
                UserExistFlag = UserProvider.UserExists(_config, req.Email);
                if(UserExistFlag)
                {

                    UserProvider.UpdatePasswordToken(_config, AppSettings, MailSettings, ref req);
                    return Ok( new CRUDResponse
                    {
                        status=1,
                        message = "Success"
                    });
                }
                else
                {
                    return Ok( new CRUDResponse
                    {
                        status=0,
                        message = Messages.C_MSGBOX_MSG_SUCCESS_PASSWORD_RESET_INVALID_EMAIL
                    });
                }
                
            }
            catch (Exception ex)
            {

                m_logger.Error(ex.Message);
                return Content("Internal Server Error : " + ex.Message);
            }
           
        }
        

        //Dependent registration
        [HttpGet("get_dependent")]
        public async Task<IActionResult> GetDependent(int UserID)
        { 
            List<Dependent> DependentList=new List<Dependent>();
            try
            {
                if(UserID!=0)
                {
                    UserProvider UserProvider = new UserProvider();
                    var conStr = _config.GetConnectionString("SQLConnection");
                    DependentList= UserProvider.GetDependent(_config,UserID);

                    return Ok( new { status=1, message="Success",DependentList = DependentList} );
                }
                else
                {
                    return Ok( new { status=0, message="Failed"} );
                }
                
            }
            catch(Exception ex)
            {
                m_logger.Error(ex.Message);
                return Content("Internal Server Error : " + ex.Message);
            }
        }

        //add dependent

        [HttpPost("add_dependent")]
        public async Task<IActionResult> AddDependent(Dependent req)
        {
            int DependentID_OUT=0;
           
            try
            {
                if (req == null)
                {
                    return BadRequest( new CRUDResponse
                    {
                        status=0,
                        message="Data required"
                    });
                }
                UserProvider UserProvider = new UserProvider();
                var conStr = _config.GetConnectionString("SQLConnection");
                DependentID_OUT=UserProvider.AddDependent(_config, ref req);
                if(DependentID_OUT>0)
                {
                    return Ok(new
                    {
                            status=1,
                            message=Messages.C_MSGBOX_TITLE_ADD_NEW_DEPENDENT ,
                            DependentID= DependentID_OUT 
                    });  
                }
                else
                {
                    return Ok(new
                    {
                            status=0,
                            message=Messages.C_MSGBOX_MSG_FAILED_ADD_USERDEPENDENT    
                    });
                }   
            }
            catch(Exception ex)
            {
                 m_logger.Error(ex.Message);
                return Content("Internal Server Error : " + ex.Message);
            }
        }

        //Get user profile
        [HttpGet("get_user_profile")]
        public async Task<IActionResult> GetUserProfile(int UserID)
        { 
            UserProfile UserProfile=new UserProfile();
            try
            {
                if(UserID!=0)
                {
                    UserProvider UserProvider = new UserProvider();
                    var conStr = _config.GetConnectionString("SQLConnection");
                    UserProfile= UserProvider.GetUserProfile(_config,UserID);
                    if(UserProfile==null)
                    {
                        return Ok( new 
                                    { status=0, message=Messages.C_MSGBOX_MSG_USER_NOT_EXIST
                                });
                    }
                    return Ok( new { status=1, message="Success" ,data=UserProfile} );
                }
                else
                {
                    return Ok( new { status=0, message="Failed"} );
                }
                
            }
            catch(Exception ex)
            {
                m_logger.Error(ex.Message);
                return Content("Internal Server Error : " + ex.Message);
            }
        }

        //To check username already exist
        [HttpGet("check_username_exist")]
        public async Task<IActionResult> CheckUsernameExist(string Email)
        { 
            bool UserExist=false;
            try
            {
                if(Email!="")
                {
                    UserProvider UserProvider = new UserProvider();
                    var conStr = _config.GetConnectionString("SQLConnection");
                    UserExist= UserProvider.UserExists(_config,Email);

                    if(UserExist)
                    {
                        return Ok( new { 
                                    status=1, 
                                    message=Messages.C_MSGBOX_TITLE_USERNAME_EXIST
                                    } );
                    }
                    else
                    {
                         return Ok( new { 
                                    status=0, 
                                    message=Messages.C_MSGBOX_TITLE_USERNAME_NOT_EXIST
                                    } );
                    }

                    
                }
                else
                {
                    return Ok( new { status=0, message="Failed"} );
                }
                
            }
            catch(Exception ex)
            {
                m_logger.Error(ex.Message);
                return Content("Internal Server Error : " + ex.Message);
            }
        }

        #region User Dashboard
        [HttpGet("get_user_dashboard")]
        public async Task<IActionResult> GetUserDashboard(int UserID)
        {
            UserDashboardModel UserDashboardModel = new UserDashboardModel();
            try
            {
                if (UserID != 0)
                {
                    UserProvider UserProvider = new UserProvider();
                    var conStr = _config.GetConnectionString("SQLConnection");
                    UserDashboardModel = UserProvider.GetUserDashboard(_config, UserID);
                    
                    return Ok(new { status = 1, message = "Success", data = UserDashboardModel });
                }
                else
                {
                    return Ok(new { status = 0, message = "Failed" });
                }

            }
            catch (Exception ex)
            {
                m_logger.Error(ex.Message);
                return Content("Internal Server Error : " + ex.Message);
            }
        }
        #endregion
    }
}