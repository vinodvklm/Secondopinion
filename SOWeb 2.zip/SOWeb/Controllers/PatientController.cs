using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;

using Microsoft.Extensions.Configuration;
using SecondOpinionWeb.Models;
using log4net;
using System.Reflection;
using BusinessLib;

using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using Microsoft.IdentityModel.Tokens;
using Microsoft.AspNetCore.Http;

using Microsoft.Extensions.Options;
using SecondOpinionWeb;
using System.IO;
using System.Net.Http.Headers;
using System.Collections; 


namespace SecondOpinionWeb.Controllers
{
   
    [Route("api/[controller]")]
    [ApiController]

    public class PatientController : ControllerBase
    {
        
        private readonly IConfiguration _config;
        
        private ILog m_logger = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);

        public PatientController(IConfiguration config)
        {
            _config = config;
          
        }

        [HttpPost("add_appointment")]
        public IActionResult AddAppointment(Appointment req )
        {
            PatientDetails PatientInfo=new PatientDetails();
            int ResultMessage=0; 
            try
            {
                PatientProvider PatientProvider = new PatientProvider();
                var conStr = _config.GetConnectionString("SQLConnection");

                PatientInfo=PatientProvider.AddAppointment(_config, ref req);
                if(PatientInfo!=null)
                {
                    
                     return Ok(new {

                            status=1,
                            message=Messages.C_MSGBOX_TITLE_ADD_NEW_APPOINTMENT,
                            data = new { 
                                PatientID = PatientInfo.PatientID,
                                PatientNumber= PatientInfo.PatientNumber,
                                PatientInfo = PatientInfo
                            },
                            
                            });
                }
                else
                {
                     return Ok(new {
                            status=0,
                            message="Failed"
                            });
                }
            
                // if(ResultMessage>0)
                // {   
                //      return Ok(new {

                //             status=1,
                //             message=Messages.C_MSGBOX_TITLE_ADD_NEW_APPOINTMENT
                //             });
                // }
                // else
                // {
                //     return Ok(new {

                //             status=0,
                //             message=Messages.C_MSGBOX_TITLE_APPOINTMENT_EXIST
                //             });
                // }
                
            }
            catch(Exception ex)
            {
                m_logger.Error(ex.Message);
                return Content("Internal Server Error : " + ex.Message);
            }
        }

        [HttpGet("get_communication_types")]
        public IActionResult GetCommunicationTypes(bool Is_Active = true)
        {
            List<CommunicationTypes> CommunicationTypeList=new List<CommunicationTypes>();
            try
            {
                PatientProvider PatientProvider = new PatientProvider();
                var conStr = _config.GetConnectionString("SQLConnection");
                CommunicationTypeList = PatientProvider.GetCommunicationTypes(_config);

                if(Is_Active)
                {
                    CommunicationTypeList = CommunicationTypeList.Where(a => a.Is_Active == Is_Active).ToList();
                }
                
                return Ok(new{

                        status=1,
                        message="success",
                        CommunicationTypeList=CommunicationTypeList

                });
            }
            catch(Exception ex)
            {
                m_logger.Error(ex.Message);
                return Content("Internal Server Error : " + ex.Message);
            }
            
        }


        [HttpGet("get_consultation_status_masters")]
        public IActionResult GetConsultationStatus()
        {
            List<ConsultationStatus> ConsultationStatusMasters=new List<ConsultationStatus>();
            try
            {
                PatientProvider PatientProvider = new PatientProvider();
                var conStr = _config.GetConnectionString("SQLConnection");
                ConsultationStatusMasters=PatientProvider.GetConsultationStatus(_config);
                return Ok(new{

                        status=1,
                        message="success",
                        ConsultationStatusMasters=ConsultationStatusMasters

                });
            }
            catch(Exception ex)
            {
                m_logger.Error(ex.Message);
                return Content("Internal Server Error : " + ex.Message);
            }
            
        }

        [HttpGet("get_consultation_details")]
        public IActionResult GetConsultationDetails(int UserID)
        {
            List<PatientDetails> ConsulationDetailsList=new List<PatientDetails>();
            try
            {
                if(UserID!=0)
                {
                    PatientProvider PatientProvider = new PatientProvider();
                    var conStr = _config.GetConnectionString("SQLConnection");
                    ConsulationDetailsList=PatientProvider.GetConsultationDetails(_config,UserID);
                    
                    return Ok(new{

                            status=1,
                            message="success",
                            ConsulationDetailsList=ConsulationDetailsList

                });
                }
                else
                {
                    return Ok( new { status=0, message="Failed"} );
                }
                
            }
            catch(Exception ex)
            {
                m_logger.Error(ex.Message);
                return Content("Internal Server Error : " + ex.Message);
            }
            
        }
        [HttpGet("get_consultation_history")]
        public IActionResult GetConsultationHistory(int PatientID)
        {
            PatientHistory ConsulationHistory=new PatientHistory();
            List<PatientConsultationStatus> ConsultationStatusList=new List<PatientConsultationStatus>();
            try
            {
                if(PatientID!=0)
                {
                    PatientProvider PatientProvider = new PatientProvider();
                    var conStr = _config.GetConnectionString("SQLConnection");
                    ConsulationHistory=PatientProvider.GetConsultationHistory(_config,PatientID);

                    if(ConsulationHistory!=null)
                    {
                        ConsulationHistory.ConsultationStatusList=PatientProvider.GetPatientConsultationStatus(_config,PatientID);
                    }


                    if(ConsulationHistory!=null)
                    {
                        return Ok(new{
                                status=1,
                                message="Success",
                                ConsulationHistory=ConsulationHistory,
                            });
                    }
                    else
                    {
                        return Ok(new{
                                status=0,
                                message="Failed",
                                
                            });
                    }
                    
                }
                else
                {
                    return Ok( new { status=0, message="Failed"} );
                }
                
            }
            catch(Exception ex)
            {
                m_logger.Error(ex.Message);
                return Content("Internal Server Error : " + ex.Message);
            }
            
        }
         //Get medical details provided by doctor to user
        [HttpGet("get_my_consultation_documents")]
        public IActionResult GetMyConsultationDocuments(int UserID,int PatientID=0)
        {
            List<PatientDocumentLi> MedicalReportList=new List<PatientDocumentLi>();
            try
            {
                PatientProvider PatientProvider = new PatientProvider();
                var conStr = _config.GetConnectionString("SQLConnection");
                MedicalReportList=PatientProvider.GetMyConsultationDocuments(_config, UserID, PatientID);
        
                var MedicalDocuments=MedicalReportList.
                                GroupBy(a=>new {
                                            a.Name,
                                            a.Relationship,
                                            a.DocumentName,
                                            a.UploadedDate
                                        }).Select(g=>new {

                                            DocumentDetails= g.Key,
                                            DocumentPath=g.Select(p=> new{
                                            p.uri,
                                            p.ConsultationDocumentDetailID   
                                            }).Where(h => h.uri != null).ToList()
                                        }).ToList();

                return Ok(new
                {
                    status = 1,
                    message = "Success",
                    MedicalDocuments
                });

            }
            catch(Exception ex)
            {
                m_logger.Error(ex.Message);
                return Content("Internal Server Error : " + ex.Message);
            }
        }

        [HttpPost("add_patient_doduments")]
        public IActionResult AddPatientDocuments(PatientDocumentInfo req)
        {
          
            try
            {
                PatientProvider PatientProvider = new PatientProvider();
                var conStr = _config.GetConnectionString("SQLConnection");

                var result = PatientProvider.AddPatientDocuments(_config, ref req);
                if (result)
                {
                    return Ok(new
                    {
                        status = 1,
                        message = "Success"
                    });
                }
                else
                {
                    return Ok(new
                    {
                        status = 0,
                        message = "Failed"
                    });
                }
             

            }
            catch (Exception ex)
            {
                m_logger.Error(ex.Message);
                return Content("Internal Server Error : " + ex.Message);
            }
        }

        [HttpGet("get_free_consultation_count")]
        public IActionResult GetFreeConsultationCount(int UserID,int CommunicationTypeID)
        {
            
            try
            {
                PatientProvider PatientProvider = new PatientProvider();
                var conStr = _config.GetConnectionString("SQLConnection");
                int FreeConsultationCount = PatientProvider.GetFreeConsultationCount(_config, UserID, CommunicationTypeID);

                return Ok(new
                {

                    status = 1,
                    message = "success",
                    FreeConsultationCount = FreeConsultationCount

                });
            }
            catch (Exception ex)
            {
                m_logger.Error(ex.Message);
                return Content("Internal Server Error : " + ex.Message);
            }

        }
        [HttpPost("update_consultation_count")]
        public IActionResult UpdateConsultationCount(FreeConsultationInfo req)
        {
            PatientDetails PatientInfo = new PatientDetails();
            try
            {
                PatientProvider PatientProvider = new PatientProvider();
                var conStr = _config.GetConnectionString("SQLConnection");
                PatientInfo = PatientProvider.UpdateConsultationCount(_config, ref req);

                return Ok(new
                {
                    status = 1,
                    message = "Your booking successfully renewed",
                    data = new
                    {
                        PatientID = PatientInfo.PatientID,
                        PatientNumber = PatientInfo.PatientNumber,
                        PatientInfo = PatientInfo
                    },

                });
            }
            catch (Exception ex)
            {
                m_logger.Error(ex.Message);
                return Content("Internal Server Error : " + ex.Message);
            }

        }
        [HttpGet("get_consultation_completed_list")]
        public IActionResult GetConsultationCompletedList(int UserID)
        {
            List<ConsultationCompletedList> PatientDetails = new List<ConsultationCompletedList>();
            try
            {
                PatientProvider PatientProvider = new PatientProvider();
                var conStr = _config.GetConnectionString("SQLConnection");
                PatientDetails = PatientProvider.GetConsultationCompletedList(_config, UserID);

                return Ok(new
                {

                    status = 1,
                    message = "success",
                    list = PatientDetails

                });
            }
            catch (Exception ex)
            {
                m_logger.Error(ex.Message);
                return Content("Internal Server Error : " + ex.Message);
            }

        }
    }
}