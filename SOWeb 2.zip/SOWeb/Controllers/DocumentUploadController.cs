using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;

using Microsoft.Extensions.Configuration;
using SecondOpinionWeb.Models;
using log4net;
using System.Reflection;
using BusinessLib;

using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using Microsoft.IdentityModel.Tokens;
using Microsoft.AspNetCore.Http;

using Microsoft.Extensions.Options;
using SecondOpinionWeb;

using System.IO;
using System.Net.Http.Headers;

using System.Collections; 


namespace SecondOpinionWeb.Controllers
{
   
    [Route("api/[controller]")]
    [ApiController]

    public class DocumentUploadController : ControllerBase
    {
        
        private readonly IConfiguration _config;
        private AppSettings AppSettings { get; set; }
        private ILog m_logger = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);

        public DocumentUploadController(IConfiguration config,IOptions<AppSettings> settings)
        {
            _config = config;
            AppSettings = settings.Value;
        }
       

        [HttpPost("upload_document")]
        public IActionResult UploadFiles([FromForm] UserDocumentUpload req)
        {
            try
            {
                int UserID=req.UserID;

                //create directory for each user
                var files = Request.Form.Files;
                string folder = Path.Combine("Documents","user"+UserID );
                Directory.CreateDirectory(folder);

                var folderName = Path.Combine("Documents", "user"+UserID);
                var pathToSave = Path.Combine(Directory.GetCurrentDirectory(), folderName);
        
                if (files.Any(f => f.Length == 0))
                {
                    return BadRequest();
                }
                List<UserDocumentPath> DocumentList=new List<UserDocumentPath>();
              
                string RootUrl=AppSettings.RootUrl;

                foreach (var file in files)
                {
                    
                    var fileName = ContentDispositionHeaderValue.Parse(file.ContentDisposition).FileName.Trim('"');
                    var fullPath = Path.Combine(pathToSave, fileName);

                    var dbPath = Path.Combine(folderName, fileName); //you can add this path to a list and then return all dbPaths to the client if require
        
                    using (var stream = new FileStream(fullPath, FileMode.Create))
                    {
                       file.CopyTo(stream);
                    }
                    UserDocumentPath UserDocumentInfo=new UserDocumentPath();
                    UserDocumentInfo.uri=RootUrl+dbPath.Replace("\\", "/");
                    
                    DocumentList.Add(UserDocumentInfo);
                   
                }
                return Ok( new {status="1" ,DocumentPath = DocumentList} );
                
            }
            catch (Exception ex)
            {
                m_logger.Error(ex.Message);
                return Content("Internal Server Error : " + ex.Message);
            }
        }
        [HttpPost("save_documents")]
        public IActionResult AddDocuments(UserDocument req )
        {
        
            bool Resultflag=false; 
            try
            {
                DocumentUploadProvider DocumentUploadProvider = new DocumentUploadProvider();
                var conStr = _config.GetConnectionString("SQLConnection");
                Resultflag=DocumentUploadProvider.AddDocuments(_config, ref req);
                if(!Resultflag)
                {
                        return Ok( new CRUDResponse
                        {
                            status=0,
                            message=Messages.C_MSGBOX_MSG__FAILED_ADD_USER_DOCUMENT
                        });
                }
                else
                {
                     return Ok( new CRUDResponse
                        {
                            status=1,
                            message=Messages.C_MSGBOX_MSG__ADD_USER_DOCUMENT
                        });
                }
            }
            catch(Exception ex)
            {
                m_logger.Error(ex.Message);
                return Content("Internal Server Error : " + ex.Message);
            }
        }

        // [HttpPost("remove_document")]
        // public IActionResult RemoveDocument(UserDocumentRemove req)
        // {
        //     try
        //     {
        //         int UserID=req.UserID;
 
        //         var fileName="";

        //         fileName = Path.GetFileName(req.fileName);    
        //         string _fileToBeDeleted = Path.Combine("Documents\\", "user"+UserID+"\\",fileName);

        //         string RootUrl=AppSettings.RootUrl;

        //         if ((System.IO.File.Exists(_fileToBeDeleted)))
        //         {
        //                 System.IO.File.Delete(_fileToBeDeleted);

        //                 string currentDirectory=Directory.GetCurrentDirectory();
                
        //                 string rootDir=currentDirectory.ToString();
                        
        //                 DirectoryInfo dir = new DirectoryInfo(@""+rootDir+"\\Documents\\user"+UserID+"");
        //                 FileInfo[] Files = dir.GetFiles("*"); //Getting Text files
        //                 List<UserDocumentPath> DocumentList=new List<UserDocumentPath>();
        //                 foreach(FileInfo file in Files )
        //                 {
        //                     UserDocumentPath UserDocumentInfo=new UserDocumentPath();

        //                     UserDocumentInfo.uri=RootUrl+"Documents/user"+UserID+"/"+file.Name;

                            
        //                     DocumentList.Add(UserDocumentInfo);

        //                 }

        //                 return Ok( new 
        //                             {
        //                                 status=1 ,
        //                                 message=Messages.C_MSGBOX_MSG__REMOVE_USER_DOCUMENT,
        //                                 DocumentPath = DocumentList
        //                         } );
        //             }
        //             else
        //             {
        //                  return Ok( new 
        //                             {
        //                                 status=0 ,
        //                                 message=Messages.C_MSGBOX_MSG__FAILED_REMOVE_USER_DOCUMENT,
                                    
        //                         } );
        //             }

        //     }
        //     catch (Exception ex)
        //     {
        //         return Ok( new CRUDResponse
        //                 {
        //                     status=0
                            
        //                 });return StatusCode(500, $"Internal server error: {ex}");
        //     }
        // }

        [HttpPost("remove_document")]
        public IActionResult RemoveDocument(UserDocumentRemove req)
        {
            try
            {
                
                List<UserDocumentLi> MedicalReportList=new List<UserDocumentLi>();
                
                DocumentUploadProvider DocumentUploadProvider = new DocumentUploadProvider();
                var conStr = _config.GetConnectionString("SQLConnection");
                MedicalReportList=DocumentUploadProvider.DeleteUserDocument(_config, req);
                    
                var MedicalDocuments=MedicalReportList.
                                GroupBy(a=>new {
                                            a.UserDocumentID,
                                            a.DocumentName,
                                            a.ReportDate,
                                            a.DocumentAccess,
                                            a.ValidFrom,
                                            a.ValidTo
                                        }).Select(g=>new {

                                            DocumentDetails= g.Key,
                                            DocumentPath=g.Select(p=> new{
                                            p.uri,
                                            p.UserDocumentDetailID   
                                            }).Where(h => h.uri != null).ToList()
                                        }).ToList();
                if(MedicalDocuments.Count!=0)
                {
                     return Ok(new{
                            status=1,
                            message="Success",
                            MedicalDocuments
                        });
                }
                else
                {
                      return Ok(new{
                            status=0,
                            message="Failed",
                            MedicalDocuments
                        });
                }
   
            }
            catch (Exception ex)
            {
                return Ok( new CRUDResponse
                        {
                            status=0
                            
                        });return StatusCode(500, $"Internal server error: {ex}");
            }
        }

        [HttpGet("get_medical_documents")]
        public IActionResult GetMedicalDocuments(bool IsSelfDependent,int RefernceID)
        {
            List<UserDocumentLi> MedicalReportList=new List<UserDocumentLi>();
            try
            {
                DocumentUploadProvider DocumentUploadProvider = new DocumentUploadProvider();
                var conStr = _config.GetConnectionString("SQLConnection");
                MedicalReportList=DocumentUploadProvider.GetMedicalDocuments(_config, IsSelfDependent,RefernceID);
        
                var MedicalDocuments=MedicalReportList.
                                GroupBy(a=>new {
                                            a.UserDocumentID,
                                            a.DocumentName,
                                            a.ReportDate,
                                            a.DocumentAccess,
                                            a.ValidFrom,
                                            a.ValidTo
                                        }).Select(g=>new {

                                            DocumentDetails= g.Key,
                                            DocumentPath=g.Select(p=> new{
                                            p.uri,
                                            p.FileName,
                                            p.DocumentType,
                                            p.UserDocumentDetailID   
                                            }).Where(h => h.uri != null).ToList()
                                        }).ToList();

                return Ok(new
                {
                    status = 1,
                    message = "Success",
                    MedicalDocuments
                });

            }
            catch(Exception ex)
            {
                m_logger.Error(ex.Message);
                return Content("Internal Server Error : " + ex.Message);
            }
        }
        [HttpGet("get_patient_documents")]
        public async Task<IActionResult> GetPatientDocuments(int UserID)
        {
            try
            {
                DocumentUploadProvider DocumentUploadProvider = new DocumentUploadProvider();
                var List = DocumentUploadProvider.GetPatientDocuments(_config, UserID);


                var GroupedList = List.
                               GroupBy(a => new {
                                   a.UserDocumentID,
                                   a.DocumentName,
                                   a.ReportDate,
                                   a.ValidFrom,
                                   a.ValidTo,
                                   a.Name,
                                   a.Relationship,
                               }).Select(g => new {

                                   DocumentDetails = g.Key,
                                   DocumentPath = g.Select(p => new {
                                       DocumentPath=p.DocumentPath.ToLower(),
                                       p.FileName,
                                       p.DocumentType,
                                       p.UserDocumentDetailID
                                   }).Where(h => h.DocumentPath != null).ToList()
                               }).ToList();
                if(GroupedList.Count>0)
                {
                    return Ok(new
                    {
                        status = 1,
                        message = "success",
                        data = GroupedList
                    });
                }
                else
                {
                    return Ok(new
                    {
                        status = 0,
                        message = "failed",
                        data = GroupedList
                    });
                }
            }
            catch(Exception ex)
            {
                m_logger.Error(ex.Message);
                return Content("Internal Server Error : " + ex.Message);
            }
        }

        [HttpPost("update_Document_accessibility")]
        public IActionResult UpdateDocumentAccessibility(DocumentAccessibility req )
        {
            bool Resultflag=false; 
            try
            {
                DocumentUploadProvider DocumentUploadProvider = new DocumentUploadProvider();
                var conStr = _config.GetConnectionString("SQLConnection");
                Resultflag=DocumentUploadProvider.UpdateDocumentAccessibility(_config, ref req);
                
                if(!Resultflag)
                {
                        return Ok( new CRUDResponse
                        {
                            status=0,
                            message=Messages.C_MSGBOX_MSG__FAILED_UPDATE_DOCUMENT_ACCESSIBILITY
                        });
                }
                else
                {
                     return Ok( new CRUDResponse
                        {
                            status=1,
                            message=Messages.C_MSGBOX_MSG__UPDATE_DOCUMENT_ACCESSIBILITY
                        });
                }
            }
            catch(Exception ex)
            {
                m_logger.Error(ex.Message);
                return Content("Internal Server Error : " + ex.Message);
            }
        }

        
        // Upload medical details by doctor
        [HttpPost("upload_patient_document")]
        public IActionResult UploadPatientDocument([FromForm] PatientDocumentUpload req)
        {
            try
            {
                int PatientID=req.PatientID;

                //create directory for each Patient
                var files = Request.Form.Files;
                string folder = Path.Combine("Documents","patient"+PatientID );
                Directory.CreateDirectory(folder);

                var folderName = Path.Combine("Documents", "patient"+PatientID);
                var pathToSave = Path.Combine(Directory.GetCurrentDirectory(), folderName);
        
                if (files.Any(f => f.Length == 0))
                {
                    return BadRequest();
                }
                List<UserDocumentPath> DocumentList=new List<UserDocumentPath>();
              
                string RootUrl=AppSettings.RootUrl;

                foreach (var file in files)
                {
                    
                    var fileName = ContentDispositionHeaderValue.Parse(file.ContentDisposition).FileName.Trim('"');
                    var fullPath = Path.Combine(pathToSave, fileName);

                    var dbPath = Path.Combine(folderName, fileName); //you can add this path to a list and then return all dbPaths to the client if require
        
                    using (var stream = new FileStream(fullPath, FileMode.Create))
                    {
                       file.CopyTo(stream);
                    }
                    UserDocumentPath UserDocumentInfo=new UserDocumentPath();
                    UserDocumentInfo.uri=RootUrl+dbPath.Replace("\\", "/");
                    
                    DocumentList.Add(UserDocumentInfo);
                   
                }
                return Ok( new {status="1" ,DocumentPath = DocumentList} );
                
            }
            catch (Exception ex)
            {
                m_logger.Error(ex.Message);
                return Content("Internal Server Error : " + ex.Message);
            }
        }
        // Save medical details by doctor
        [HttpPost("save_patient_documents")]
        public IActionResult AddPatientDocuments(PatientDocument req )
        {

            bool Resultflag=false; 
            try
            {
                DocumentUploadProvider DocumentUploadProvider = new DocumentUploadProvider();
                var conStr = _config.GetConnectionString("SQLConnection");
                Resultflag=DocumentUploadProvider.AddPatientDocuments(_config, ref req);
                if(!Resultflag)
                {
                        return Ok( new CRUDResponse
                        {
                            status=0,
                            message=Messages.C_MSGBOX_MSG__FAILED_ADD_USER_DOCUMENT
                        });
                }
                else
                {
                     return Ok( new CRUDResponse
                        {
                            status=1,
                            message=Messages.C_MSGBOX_MSG__ADD_USER_DOCUMENT
                        });
                }
            }
            catch(Exception ex)
            {
                m_logger.Error(ex.Message);
                return Content("Internal Server Error : " + ex.Message);
            }
        }
       
    }
}