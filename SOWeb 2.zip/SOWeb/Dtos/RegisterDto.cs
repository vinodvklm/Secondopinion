using System.ComponentModel.DataAnnotations;

namespace SecondOpinionWeb.Dtos
{
    public class RegisterDto
    {
        [Required]
        [StringLength(100, MinimumLength = 3, ErrorMessage = "Name must be at least 3 characters")]
        public string Name { get; set; }
        [Required]
        [StringLength(100, MinimumLength = 3, ErrorMessage = "User Name must be at least 3 characters")]
        public string UserName { get; set; }
        [Required]
        [StringLength(64, MinimumLength = 8, ErrorMessage = "You must provide password between 8 and 20 characters")]
        public string Password { get; set; }
    }
}