using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Data;
using System.ComponentModel.DataAnnotations;

namespace SecondOpinionWeb.Models
{

    public class DoctorAvailableDate
    {
        public string  Date{ get; set; }  
    }
    public class DoctorUnAvailableDate
    {
        public string dayofdate { get; set; }
        public DateTime full_date { get; set; }
        public string date { get { return full_date.ToString("dd/MM/yyyy"); } }
    }
    public class DoctorAvailableTime
    {
        public int      DoctorAvailabilityDetailID{ get; set; }
        public char     BookingStatus{ get; set; }
        public string   TimeFrom{ get; set; }
        public string   TimeTo{ get; set; }
        public string   CommunicationType{ get; set; }
    }
    public class AvailableDates
    {
        [Required]
        public string  Date{ get; set; } 
        [Required]
        public int  CommunicationTypeID{ get; set; } 
        [Required]
        public string  FromTime{ get; set; } 
        [Required]
        public string  ToTime{ get; set; }  
        public string  Timeslot{ get; set; }  

        public string  Status{ get; set; }  
    }
    public class TimeSlotList
    {
        public int  CommunicationTypeID{ get; set; } 

        public string  CommunicationType{ get; set; } 

        public int  Duration{ get; set; } 

        public string  AvailableDate{ get; set; }  

        public string  AvailabilityTimeFrom{ get; set; }  

        public string  AvailabilityTimeTo{ get; set; }
        public string BookingStatus { get; set; }
    }
    public class FreeConsultationInfo
    {
        [Required]
        public int UserID { get; set; }
        [Required]
        public int DoctorAvailabilityDetailID { get; set; }

    }
}
