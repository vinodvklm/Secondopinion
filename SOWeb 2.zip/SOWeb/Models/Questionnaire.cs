using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Data;
using System.ComponentModel.DataAnnotations;

namespace SecondOpinionWeb.Models
{

    public class Form
    {
        public int      FormID{ get; set; }  
        public int      FormType{ get; set; } 
        public string   FormName{ get; set; }  
        public bool     IsActive{ get; set; } 

        public List<Question> Questions { get; set; }
    }

    public class Question
    {
        public int QuestionID { get; set; }
        public int FormFK { get; set; }
        public string QuestionTitle { get; set; }
        public string Range { get; set; }
        public string ToolTipText { get; set; }
        public bool IsActive { get; set; }
        public bool IsMandatory { get; set; }
        public string InputDataTypeName { get; set; }
        public int InputDataType { get; set; }
        public string InputControlTypeName { get; set; }
        public int InputControlType { get; set; }
        public bool HasRate { get; set; }
        public bool HasComments { get; set; }
        public int CreatedBy { get; set; }
        public string CreatedOn { get; set; }
        public string PlaceholderText { get; set; }
        public int InputLabel { get; set; }
        public int ColumnWidth { get; set; }
        public bool IsSection { get; set; }
        public int TableType { get; set; }
        public int SectionNumber { get; set; }
        public string SectionHeader { get; set; }
        public int DisplayControlType { get; set; }
        public string DisplayHeader { get; set; }
        public int MaxLength { get; set; }
        public List<QuestionOption> QuestionOptions { get; set; }
        public List<QuestionParentBranch> QuestionParentBranches { get; set; }
        public List<QuestionChildBranch> QuestionChildBranches { get; set; }
    }
    public class QuestionOption
    {
        public int          QuestionOptionID{ get; set; }
        public int          QuestionFK{ get; set; }
        public string       OptionText{ get; set; }
    }
    public class QuestionParentBranch
    {
        public int          QuestionBranchID{ get; set; }
        public int          ChildQuestionFK{ get; set; }
        public int          ParentQuestionFK{ get; set; }
        public int          ParentQuestionOptionFK{ get; set; }
    }
    public class QuestionChildBranch
    {
        public int          QuestionBranchID{ get; set; }
        public int          ChildQuestionFK{ get; set; }
        public int          ParentQuestionFK{ get; set; }
        public int          ParentQuestionOptionFK{ get; set; }
    }
    public class QuestionnaireInfo
    {
        public string UserID { get; set; }

        public int PatientID { get; set; }
        public int FormID { get; set; }
        public int SectionNumber { get; set; }
        public List<FormSubmitted> FormSubmitted { get; set; }
        public List<PainMedication> PainMedicationList { get; set; }
        public List<PainTreatmentHistory> PainTreatmentHistoryList { get; set; }
        public List<Medication> MedicationsList { get; set; }
        public List<TestInvestigation> TestInvestigationList { get; set; }
        public List<PhysiciansConsulted> PhysiciansConsultedList { get; set; }
        public List<PainLocation> PainLocationList { get; set; }
        public List<PainSpots> PainSpotList { get; set; }
    }
   
    public class FormSubmitted
    {
        public int QuestionFk { get; set; }
        public int QuestionOptionFk { get; set; }
        public string Answer { get; set; }
        public string Comments { get; set; }
 
    }
    public class PainMedication
    {
        public string Medication { get; set; }
        public string Dose { get; set; }
        public string Frequency { get; set; }
        public string Comment { get; set; }
    }
    public class PainTreatmentHistory
    {
        public string TreatmentType { get; set; }
        public string Region { get; set; }
        public string ProceduresLastYear { get; set; }
        public string DateOfLastProcedure { get; set; }
        public string AmountOfPainRelief { get; set; }
        public string SideEffect { get; set; }
    }
    public class Medication
    {
        public string MedicationName { get; set; }
        public string Dosage { get; set; }
        public string Medicationfrequency { get; set; }
    }
    public class TestInvestigation
    {
        public string Investigation { get; set; }
        public string Region1 { get; set; }
        public string Region2 { get; set; }
        public string Recentdate1 { get; set; }
        public string Recentdate2 { get; set; }
    }
    public class PhysiciansConsulted
    {
        public string Speciality { get; set; }
        public string Name { get; set; }
        public string Treatment { get; set; }
        public string Painrelief { get; set; }
        public string Lastinterventiondate { get; set; }
    }
    public class PainLocation
    {
        public string Location { get; set; }
        public string Painrightnow { get; set; }
        public string Thebestitgets { get; set; }
        public string Theworstitgets { get; set; }
    }
    public class PainSpots
    {
        public bool     Enabled { get; set; }
        public bool     Front { get; set; }
        public string   Pos_X { get; set; }
        public string   Pos_Y { get; set; }
        public int      questionID { get; set; }
        public string   Description { get; set; }
    }
}
