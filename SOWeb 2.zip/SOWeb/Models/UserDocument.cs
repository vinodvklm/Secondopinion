using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Data;
using System.ComponentModel.DataAnnotations;

namespace SecondOpinionWeb.Models
{
    #region Data Access

    public class T_UserDocumentDetails
    {
        public int UserDocumentDetailID { get; set; }
        public int UserDocumentFK { get; set; }
        public string DocumentType { get; set; }
        public string DocumentPath { get; set; }
        public bool Is_Active { get; set; }
        public bool Is_Removed { get; set; }
        public string FileName { get; set; }
    }
    #endregion
    public class UserDocumentUpload
    {
        public int   UserID { get;set; }
    }
    public class UserDocumentPath
    {
        public string uri { get;set; }
    }
    public class UserDocument
    {
        public int UserDocumentID { get;set; }
        // [Required]
        public string UserID { get;set; }

        [Required]
        public string DocumentName { get;set; }

        [Required]
        public string ReportDate { get;set; }

        [Required]
        public string DocumentAccess { get;set; }

        public string ValidFrom { get;set; }
        public string ValidTo { get;set; }
        public string Remarks { get;set; }

        [Required]
        public string UserType { get;set; }
        public string DependentFK { get;set; }
        
        [Required]
        public List<UserDocumentPath> DocumentPath { get; set; }
    }
    public class UserDocumentRemove
    {
        public int      UserID { get;set; }
        public string   fileName { get;set; }
        public int      UserDocumentDetailID { get;set; }

    }
    public class UserDocumentLi
    {
        public int      UserDocumentID {get;set;}
        public int      UserDocumentDetailID {get;set;}
        public string   DocumentType {get;set;}
        public string   uri {get;set;}
        public string   FileName {get;set;}

        public string   DocumentName {get;set;}
        public string   ReportDate {get;set;}
        public string   DocumentAccess {get;set;}
        public string   ValidFrom {get;set;}
        public string   ValidTo {get;set;}

    }
    public class DocumentAccessibility
    {
        [Required]
        public int      UserDocumentID {get;set;}
        [Required]
        public string   DocumentAccess { get;set; }
        public string   ValidFrom {get;set;}
        public string   ValidTo {get;set;}
    }
    
    public class PatientDocumentUpload
    {
        public int   PatientID { get;set; }
    }
    public class PatientDocument
    {
        [Required]
        public string PatientID { get;set; }
        [Required]
        public string DocumentName { get;set; }
        [Required]
        public string ReportDate { get;set; }
        public string ValidFrom { get;set; }
        public string ValidTo { get;set; }
        public string Remarks { get;set; }

        [Required]
        public List<UserDocumentPath> DocumentPath { get; set; }
    }
    public class PatientDocumentLi
    {
        public string   Name {get;set;}
        public string   Relationship {get;set;}
        
        public int      ConsultationDocumentID {get;set;}
        public int      ConsultationDocumentDetailID {get;set;}
        public string   DocumentType {get;set;}
        public string   DocumentName {get;set;}
        public string   uri {get;set;}
        public string   UploadedDate {get;set;}
        
    }
    public class DocumentModel
    {
        public int UserID { get; set; }
        public string Name { get; set; }
        public string Relationship { get; set; }

        public int UserDocumentID { get; set; }
        public int UserDocumentDetailID { get; set; }
        public string DocumentName { get; set; }
        public string ReportDate { get; set; }
        public string ValidFrom { get; set; }
        public string ValidTo { get; set; }
        public string FileName { get; set; }
        public string DocumentType { get; set; }
        public string DocumentPath { get; set; }
    }
}
