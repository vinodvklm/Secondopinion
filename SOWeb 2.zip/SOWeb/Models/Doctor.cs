using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Data;
using System.ComponentModel.DataAnnotations;

namespace SecondOpinionWeb.Models
{

    public class DicomUploadedViewer
    {
        public int      UserID{ get; set; }  
        public string   DocumentName{ get; set; }  
        public string   ReportDate{ get; set; }  
        public string   ValidFrom{ get; set; }  
        public string   ValidTo{ get; set; } 
        public int      UserDocumentDetailID{ get; set; }        
        public int      UserDocumentFK{ get; set; }        
        public string   DocumentPath{ get; set; }        
        public string   FileName{ get; set; }        
        public string   UserType{ get; set; }        
        public string   Name{ get; set; }        
        public string   Email{ get; set; }        
        public string   Gender{ get; set; }        
        public string   Age{ get; set; }        
        public string   MobileNumber{ get; set; }        
        public string   Profile_Image_URL{ get; set; }        
        public string   DependentName{ get; set; }        
        public int      DependentID{ get; set; }        
        public string  DependentAge{ get; set; }        
        public string  DependentGender{ get; set; }        
        public string  DependentProfile_Image_URL{ get; set; }             

    }
   public class PatientDetail
    {
        public int PatientID { get; set; }
        public string PatientType { get; set; }
        public int UserID { get; set; }
        public int DependentID { get; set; }
        public string FirstName { get; set; }
        public string MiddleName { get; set; }
        public string LastName { get; set; }
        public string Gender { get; set; }
        public string Age { get; set; }
        public string MobileNumber { get; set; }
        public string Email { get; set; }
        public string Address { get; set; }
        public string ConsultationStatus { get; set; }
        public string CommunicationType { get; set; }
        public string BookedOn { get; set; }
        public string Remarks { get; set; }
        public string AppointmentFrom { get; set; }
        public string AppointmentTo { get; set; }
        public bool DicomExist { get; set; }
        public string PatientNumber { get; set; }
    }
    public class DocumentDetail
    {
        public int UserDocumentID { get; set; }
        public string DocumentName { get; set; }
        public string ReportDate { get; set; }
        public string FileName { get; set; }
        public string DocumentPath { get; set; }
        public string UserDocumentDetailID { get; set; }
    }
    public class Dashboard
    {
        public long TodayCount { get; set; }
        public long WeekCount { get; set; }
        public long MonthCount { get; set; }
    }
    public class TodaysAppointment
    {
        public int PatientID { get; set; }
        public string PatientNumber { get; set; }
        public char PatientType { get; set; }
        public int CommunicationTypeID { get; set; }
        public string CommunicationType { get; set; }
        public string AppointmentFrom { get; set; }
        public string AppointmentTo { get; set; }
        public string Remarks { get; set; }
        public int DependentID { get; set; }
        public int UserID { get; set; }
        public string FirstName { get; set; }
        public string MiddleName { get; set; }
        public string LastName { get; set; }
        public int Age { get; set; }
        public string Gender { get; set; }
        public string MobileNumber { get; set; }
        public string OfficialNumber { get; set; }
        public string WhatsAppNumber { get; set; }
        public string Email { get; set; }
        public int ConsultationStatusID { get; set; }
        public string ConsultationStatus { get; set; }
        public string BookedDate { get; set; }
        public string Profile_Image_URL { get; set; }
    }
    public class M_AppSetting
    {
        public string WhatsAppNumber { get; set; }
    }

    public class ConsultationStatusModel
    {
        public int ConsultationStatusID { get; set; }
        public string ConsultationStatus { get; set; }
    }
    public class ConsultationDetailModel
    {
        [Required]
        public int PatientID { get; set; }
        [Required]
        public int ConsultationStatusID { get; set; }
        public string ConsultationRemarks { get; set; }
        public string CompleteDate { get; set; }
        public List<ConsultaionDocumentPath> DocumentPath { get; set; }
    }
    public class ConsultaionDocumentPath
    {
        public string uri { get; set; }
    }
    public class DashboardAppointmentList
    {
        public string Name { get; set; }
        public string AppointmentFrom { get; set; }
        public string AppointmentTo { get; set; }
        public string Day_Name { get; set; }
        public string CommunicationType { get; set; }
    }
    public class DicomViewerList
    {
        public int UserID { get; set; }
        public int UserDocumentID { get; set; }
        public string DocumentName { get; set; }
        public string ReportDate { get; set; }
        public string DocumentAccess { get; set; }
        public string ValidFrom { get; set; }
        public string ValidTo { get; set; }
        public string Remarks { get; set; }
        public int UserDocumentDetailID { get; set; }
        public string DocumentType { get; set; }
        public string FileName { get; set; }
        public string DocumentPath { get; set; }
    }
}
