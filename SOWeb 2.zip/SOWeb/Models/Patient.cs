using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Data;
using System.ComponentModel.DataAnnotations;

namespace SecondOpinionWeb.Models
{

    public class Appointment
    {
        [Required]
        public string PatientType { get;set; }
        [Required]
        public int ReferenceID { get;set; }
        [Required]
        public int DoctorAvailabilityDetailID { get;set; }
        public string Remarks { get;set; }

        [Required]
        public string PaymentID { get; set; }
        public string PaymentState { get; set; }
        [Required]
        public string PaymentCreate_time { get; set; }
        public string PaymentResponse_type { get; set; }
        [Required]
        public string PaymentAmount { get; set; }
        public string PatientNumber { get; set; }
        public string CurrencySymbol { get; set; }
    }
    public class CommunicationTypes
    {
        [Required]
        public int CommunicationTypeID { get;set; }
        [Required]
        public string CommunicationType { get;set; }
        [Required]
        public string Symbol { get;set; }
        [Required]
        public decimal Amount { get;set; }
        public bool Is_Active { get; set; }
        
        public int Duration { get;set; }
    }

    public class ConsultationStatus
    {
        public int ConsultationStatusID { get;set; }
        public string Status { get;set; } 
    }
    public class PatientDetails
    {
        public int PatientID { get;set; }
        public int UserID { get; set; }
        public string Name { get;set; } 
        public string ConsultationStatus { get;set; } 
        public string Relationship { get;set; } 
        public string ConsultationOn { get;set; } 
        public string CommunicationType { get;set; } 
        public bool DocumentAvailable { get;set; }
        public string PatientNumber { get; set; }
        public string Profile_Image_URL { get; set; }
        public int ConsultationStatusID { get; set; }
        public bool IsSelfDependent { get; set; }
        public bool IsDocumentUploaded { get; set; }
        public bool IsQuestionaireCompleted { get; set; }
        public bool IsNDICompleted { get; set; }
        public int DocumentCount { get; set; }
        public string CreatedOn { get; set; }
        public int CommunicationTypeFK { get; set; }
        public bool IsFreeConsultation { get; set; }
        public int BookingCount { get; set; }
        public string ValidFrom { get; set; }
        public string ValidTo { get; set; }
    }
    public class PatientHistory
    {
        public int PatientID { get;set; }
        public string Name { get;set; } 
        public string ConsultationOn { get;set; } 
        public string CommunicationType { get;set; } 
        public bool IsMySelf { get;set; } 
        public string Relationship { get;set; } 
        public bool IsRequiredAdditionalPayment { get;set; } 

        public List<PatientConsultationStatus> ConsultationStatusList { get; set; }
    }
    public class PatientConsultationStatus
    {
        public int ConsultationStatusID { get;set; }
        public string ConsultationStatus { get;set; } 
        public bool CurrentStatus { get;set; } 
    }
    public class PaymentHistory
    {
        public int PaymentTransactionID { get; set; }
        public int PatientID { get;set; }
        public string PatientNumber { get;set; } 
        public string UserID { get;set; } 
        public string Relationship { get;set; } 
        public string PaymentID { get;set; } 
        public string PaymentOption { get;set; }
        public string PaymentDetails { get; set; }
        public string PaymentStatus { get; set; }
        public string TotalAmount { get; set; }
        public string CreatedOn { get; set; }
        public string PaymentResponseType { get; set; }
        public string Name { get; set; }
        public string CurrencySymbol { get; set; }
        

    }
    public class PatientDocumentInfo
    {
        [Required]
        public int PatientID { get; set; }
        public string DocumentName { get; set; }
        public int UserID { get; set; }
        [Required]
        public List<ConsultaionDocumentPath> DocumentPath { get; set; }
    }
    public class PatientConsultationValidity
    {
        public int PatientConsultationValidityID { get; set; }
        public int PatientFK { get; set; }
        public int CommunicationTypeFK { get; set; }
        public int BookingCount { get; set; }
        public int UserFK { get; set; }
        public DateTime ValidFrom { get; set; }
        public DateTime ValidTo { get; set; }
    }
    public class ConsultationCompletedList
    {
        public int PatientID { get; set; }
        public int UserID { get; set; }
        public string Name { get; set; }
        public string ConsultationStatus { get; set; }
        public string Relationship { get; set; }
        public string CommunicationType { get; set; }
        public string MobileNumber { get; set; }
        public string Profile_Image_URL { get; set; }
        public int ConsultationStatusID { get; set; }
      
    }
}
