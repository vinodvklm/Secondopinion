﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using SecondOpinionWeb.Models;

public partial class SecondOpinionDBContext : DbContext
    {
        public SecondOpinionDBContext()
        {
        }

        public SecondOpinionDBContext(DbContextOptions<SecondOpinionDBContext> options)
            : base(options)
        {
        }

        
    }