using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Data;
using System.ComponentModel.DataAnnotations;

namespace SecondOpinionWeb.Models
{
    public class UserModel
    {
        public int          UserID { get; set; }
        public string       FirstName { get; set; }
        public string       MiddleName { get; set; }
        public string       LastName { get; set; }
        public string       Email { get; set; }
        public string       Gender { get; set; }
        public string       Age { get; set; }
        public string       DOB { get; set; }
        public string       Username { get; set; }
        public string       Password { get; set; }
        public string       PasswordToken { get; set; }
        public string       MobileNumber { get; set; }
        public string       OfficialNumber { get; set; }
        public string       WhatsAppNumber { get; set; }
        public string       Address { get; set; }
        public string       Latitude { get; set; }
        public string       Longitude { get; set; }
        public string       StreetName { get; set; }
        public string       CityName { get; set; }
        public string       Pincode { get; set; }
        public bool         ActiveFlag { get; set; }
        public bool         DeletedFlag { get; set; }
        public string       ImageURL { get; set; }
        public string       Remarks { get; set; }
        public DateTime     FIDate { get; set; }   
        public string       Role { get; set; }
        public string       CountryCode { get; set; }
        public CRUDResponse CRUDResponse { get; set; }

    }  
    public class UserProfile
    {
        public int          UserID { get; set; }
        public string       Name { get; set; }
        public string       FirstName { get; set; }
        public string       MiddleName { get; set; }
        public string       LastName { get; set; }
        public string       Email { get; set; }
        public string       Gender { get; set; }
        public string       Age { get; set; }
        public string       DOB { get; set; }
        public string       MobileNumber { get; set; }
        public string       OfficialNumber { get; set; }
        public string       WhatsAppNumber { get; set; }
        public string       Address { get; set; }
        public string       ImageURL { get; set; }
        public string       LastModifiedDate{ get; set; }
        public int          DependentCount { get; set; }
        public string       StreetName { get; set; }
        public string       CityName { get; set; }
        public string       Pincode { get; set; }
        public string       Remarks { get; set; }
    }   
    public class CRUDResponse
    {
        public int status { get; set; }
        public string message { get; set; }
    }
    public class UserRegModel
    {
        public int          UserID { get; set; }
        public string       Name { get; set; }
        public string       Email { get; set; }
        public string       Username { get; set; }
        public byte[]       Password { get; set; }
        public byte[]       Salt { get; set; }
        public string       Profile_Image_URL { get; set; }
        public string       Role { get; set; }
    } 
    public class LoginModel
    {
        public int          UserID { get; set; }
        public string       Name { get; set; }
        public string       Email { get; set; }
        public string       Username { get; set; }
        public byte[]       Password { get; set; }
        public byte[]       Salt { get; set; }
        public string       Profile_Image_URL { get; set; }
        public string       Role { get; set; }
       
    }   
    public class ForgotPasswordRequest
    {
        [Required]
        public string Email { get; set; }
        
    }
    public class Relationships
    {
        public int RelationshipID {get;set;}
        public string Relationship {get;set;}
    }  
    public class Dependent
    {
        [Required]
        public int          UserID { get;set; }
        [Required]
        public string       Relationship { get;set; }
        [Required]
        public string       FirstName { get;set; }
        public string       LastName { get;set; }
        public string       MiddleName { get;set; }
        public string       Age { get;set; }
        public string       Gender { get;set; }
        public bool         IsSelfDependent { get;set; }
        public string       Profile_Image_URL { get; set; }
        public bool DocumentExist { get; set; }
        public int FreeBookingCount { get; set; }
    }
    public class DependentLi
    {
        public int   UserID { get;set; }
    }
    
    public class ResetPasswordRequest
    {
        public string Password_Token { get; set; }
        public string Password { get; set; }
       
        public string update_user_id { get; set; }
    }
    public class CounterModel
    {
        public long CounterId { get; set; }
        public string Prefix { get; set; }
        public long CounterValue { get; set; }
    }

    public class UserDashboardModel
    {
        public DashBoardCardInfo DashBoardCardInfo;

        public List<UserBookingModel> BookingList = new List<UserBookingModel>();
    }
    public class DashBoardCardInfo
    {
        public long BookingCount { get; set; }
        public long DependentCount { get; set; }
        public long DocumentCount { get; set; }
    }
    public class UserBookingModel
    {
        public string Name { get; set; }
        public string Relationship { get; set; }
        public int PatientID { get; set; }
        public string PatientNumber { get; set; }
        public string AppointmentDate { get; set; }
        public string AppointmentFrom { get; set; }
        public string AppointmentTo { get; set; }
        public string CommunicationType { get; set; }
    }


}
