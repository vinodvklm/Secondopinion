using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.SpaServices.AngularCli;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.IdentityModel.Tokens;
using AutoMapper;
using Microsoft.AspNetCore.Authentication.JwtBearer;

using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

using System.Text;

using SecondOpinionWeb.Models;
using SecondOpinionWeb.Repositories;
using Microsoft.Extensions.FileProviders;
using Microsoft.AspNetCore.Http;
using System.IO;
using Microsoft.AspNetCore.Http.Features;

using Microsoft.Extensions.Logging;
using SecondOpinionWeb.Notification;
//using Microsoft.Extensions.FileProviders;
//using Swashbuckle.AspNetCore.Swagger;
//using Swashbuckle.AspNetCore.SwaggerGen;
//using System.Collections.Generic;
//using Microsoft.OpenApi.Models;
//using Microsoft.OpenApi;
//using SecondOpinionWeb.Helpers;
namespace SecondOpinionWeb
{
    public class AppSettings
    {
        public string StorageConnectionString { get; set; }
        public string RootUrl { get; set; }
        public string SiteName { get; set; }
    }
    public class MailSettings
    {
        public string DisplayName { get; set; }
        public string FromMail { get; set; }
        public string Host { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        public int Port { get; set; }
        public bool EnableSsl { get; set; }
        public bool UseDefaultCredentials { get; set; }
        public string Priority { get; set; }
        public bool IsBodyHtml { get; set; }
    }
    //public class FileUploadOperation : Swashbuckle.AspNetCore.SwaggerGen.IOperationFilter
    //{
    //    public void Apply(Operation operation, OperationFilterContext context)
    //    {
    //        if (operation.OperationId.ToLower() == "apiservicesappuseruploadprofilepicturepost")
    //        {
    //            operation.Parameters.Clear();
    //            operation.Parameters.Add(new OpenApiParameter
    //            {
    //                Name = "uploadedFile",
    //                In = "formData",
    //                Description = "Upload File",
    //                Required = true,
    //                Type = "file"
    //            });
    //            operation.Parameters.Add(new OpenApiParameter
    //            {
    //                Name = "userId",
    //                In = "query",
    //                Description = "",
    //                Required = true,
    //                Type = "long"
    //            });
    //            operation.Consumes.Add("multipart/form-data");
    //        }
    //    }
    //}

    //public class Operation
    //{
    //    public string OperationId { get; set; }
    //    public List<string> Consumes { get; set; }
    //    public List<NonBodyParameter> Parameters { get; set; }
    //}

    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public  void SetDateTimeOffset()
        {
            var offset = Configuration.GetValue< string>("DateTimeOffset");
            if(offset!=null)
            {
                CommonUtils.Utils.DateTimeOffset = offset;//CommonUtils.Utils.AppSettingsItemValue("DateTimeOffset");
            }
           // 
        }
        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            var appconfiguration = Configuration.GetSection("AppSettings");
            services.AddControllersWithViews();
            services.AddControllers().AddNewtonsoftJson();
            //services.AddMvc().SetCompatibilityVersion(CompatibilityVersion.Version_3_0);
            services.AddDbContext<SecondOpinionDBContext>(options => options.UseSqlServer(Configuration.GetConnectionString("SQLConnection")));
            services.Configure<AppSettings>(Configuration.GetSection("AppSettings"));
            services.Configure<MailSettings>(Configuration.GetSection("MailSettings"));
            services.Configure<FormOptions>(o => {
                o.ValueLengthLimit = int.MaxValue;
                o.MultipartBodyLengthLimit = int.MaxValue;
                o.MemoryBufferThreshold = int.MaxValue;
            });
            services.AddCors();
            services.AddSignalR();
            services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
                .AddJwtBearer(options => {
                    options.TokenValidationParameters = new TokenValidationParameters
                    {
                        ValidateIssuerSigningKey = true,
                        IssuerSigningKey = new SymmetricSecurityKey(Encoding.ASCII
                            .GetBytes(Configuration.GetSection("AppSettings:Token").Value)),
                        ValidateIssuer = false,
                        ValidateAudience = false
                    };
                });
            services.AddAutoMapper();
            //services.AddAutoMapper(cfg => cfg.AddProfile(new Helpers.AutoMapperProfile()));
           // services.AddScoped<IAuthRepository, AuthRepository>();
            
            // In production, the Angular files will be served from this directory
            services.AddSpaStaticFiles(configuration =>
            {
                configuration.RootPath = "ClientApp/dist";
            });
            SetDateTimeOffset();
            services.AddCors(options =>
            {
                options.AddDefaultPolicy(
                    builder =>
                    {

                        builder
                        .AllowAnyOrigin()
                        .AllowAnyMethod()
                        .AllowAnyHeader();
                    });

                options.AddPolicy("MyCORSPolicy",
                    builder =>
                    {
                        builder.WithOrigins(appconfiguration.GetValue<string>("RootUrl"))
                                            .AllowAnyHeader()
                                            .AllowAnyMethod();
                    });

            });
            services.Configure<FormOptions>(o => {
                o.ValueLengthLimit = int.MaxValue;
                o.MultipartBodyLengthLimit = int.MaxValue;
                o.MemoryBufferThreshold = int.MaxValue;
            });


        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env, ILoggerFactory loggerFactory)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/Error");
            }

            app.UseCors();
            app.UseStaticFiles();
            app.UseStaticFiles(new StaticFileOptions()
            {
                FileProvider = new PhysicalFileProvider(Path.Combine(Directory.GetCurrentDirectory(), @"Resources")),
                RequestPath = new PathString("/Resources")
            });


            app.UseStaticFiles(new StaticFileOptions()
            {
                FileProvider = new PhysicalFileProvider(Path.Combine(Directory.GetCurrentDirectory(), @"Documents")),
                RequestPath = new PathString("/Documents")
            });


            //app.UseMvc();
            if (!env.IsDevelopment())
            {
                app.UseSpaStaticFiles();
            }

            app.UseRouting();

            //The call to app.UseAuthorization() must appear between app.UseRouting() and app.UseEndpoints(...).
            app.UseCors(x => x.AllowAnyOrigin().AllowAnyHeader().AllowAnyMethod());
            //app.UseSignalR(routes =>
            //{
            //    routes.MapHub<NotifyHub>("/notify");
            //});
            app.UseHttpsRedirection();
            app.UseAuthentication();
            app.UseAuthorization();
            loggerFactory.AddLog4Net(); // << Add this line
            app.UseEndpoints(endpoints =>
            {

                this.CreateRoutes(endpoints);
                endpoints.MapControllers();
                //endpoints.MapControllerRoute(
                //    name: "default",
                //    pattern: "{controller}/{action=Index}/{id?}");
            });
            app.UseSpa(spa =>
            {
                // To learn more about options for serving an Angular SPA from ASP.NET Core,
                // see https://go.microsoft.com/fwlink/?linkid=864501

                spa.Options.SourcePath = "ClientApp";

                if (env.IsDevelopment())
                {
                    spa.UseAngularCliServer(npmScript: "start");
                }
            });
        }
        void CreateRoutes(Microsoft.AspNetCore.Routing.IEndpointRouteBuilder enpoints) // <--
        {
            //enpoints.MapControllerRoute( // <--
            //  "Events",
            //  string.Concat("{moniker}/{controller=Root}/{action=Index}/{id?}")
            //  );

            enpoints.MapHub<NotifyHub>("/notify");
            enpoints.MapControllerRoute( // <--
               "Default",
              "{controller}/{action=Index}/{id?}"
            );

        }
    }
}



//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Threading.Tasks;
//using Microsoft.AspNetCore.Builder;
//using Microsoft.AspNetCore.Hosting;
//using Microsoft.AspNetCore.HttpsPolicy;
//using Microsoft.AspNetCore.Mvc;
//using Microsoft.Extensions.Configuration;
//using Microsoft.Extensions.DependencyInjection;
//using Microsoft.Extensions.Logging;
//using Microsoft.Extensions.Options;

//using Microsoft.EntityFrameworkCore;
//namespace SOWeb
//{
//    public class Startup
//    {
//        public Startup(IConfiguration configuration)
//        {
//            Configuration = configuration;
//        }

//        public IConfiguration Configuration { get; }

//        // This method gets called by the runtime. Use this method to add services to the container.
//        public void ConfigureServices(IServiceCollection services)
//        {
//            services.AddMvc().SetCompatibilityVersion(CompatibilityVersion.Version_2_1);
//            services.AddDbContext<SecondOpinionDBContext>(options => options.UseSqlServer(Configuration.GetConnectionString("SQLConnection")));

//            services.AddCors(options =>
//            {
//                options.AddDefaultPolicy(
//                    builder =>
//                    {

//                        builder
//                        .AllowAnyOrigin()
//                        .AllowAnyMethod()
//                        .AllowAnyHeader();
//                    });

//                options.AddPolicy("MyCORSPolicy",
//                    builder =>
//                    {
//                        builder.WithOrigins("https://localhost:4200")
//                                            .AllowAnyHeader()
//                                            .AllowAnyMethod();
//                    });

//            });

//        }

//        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
//        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
//        {
//            if (env.IsDevelopment())
//            {
//                app.UseDeveloperExceptionPage();
//            }
//            else
//            {
//                app.UseHsts();
//            }

//            app.UseCors();
//            app.UseHttpsRedirection();
//            app.UseMvc();
//        }
//    }
//}
