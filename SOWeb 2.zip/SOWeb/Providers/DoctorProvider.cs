using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Microsoft.Extensions.Configuration;
using SecondOpinionWeb.Models;
using SecondOpinionWeb.Repositories;
using BusinessLib;

public class DoctorProvider 
{


    public List<DicomUploadedViewer> GetDicomUploadedUser(IConfiguration _config)
    {
        var rep = new DoctorRepository(_config);
        return rep.GetDicomUploadedUser();
    }
    public List<DicomViewerList> GetDicomByUserID(IConfiguration _config, int UserID)
    {
        var rep = new DoctorRepository(_config);
        return rep.GetDicomByUserID(UserID);
    }
    public List<PatientDetail> GetPatientist(IConfiguration _config)
    {
        var rep = new DoctorRepository(_config);
        return rep.GetPatientist();
    }
    public List<DocumentDetail> GetDocumentDetail(IConfiguration _config, int UserID, int DependentID)
    {
        var rep = new DoctorRepository(_config);
        return rep.GetDocumentDetail(UserID, DependentID);
    }
    public Dashboard GetDoctorDashboard(IConfiguration _config)
    {
        var rep = new DoctorRepository(_config);
        return rep.GetDoctorDashboard();
    }
    public List<DashboardAppointmentList> GetbookedSlots(IConfiguration _config)
    {
        var rep = new DoctorRepository(_config);
        return rep.GetbookedSlots();
    }
    public List<DashboardAppointmentList> GetThisWeekConsulationList(IConfiguration _config)
    {
        var rep = new DoctorRepository(_config);
        return rep.GetThisWeekConsulationList();
    }
    public bool AddCommunicationType(IConfiguration _config,ref CommunicationTypes model)
    {
        var rep = new DoctorRepository(_config);
        return rep.AddCommunicationType(model);
    }
    public bool UpdateCommunicationType(IConfiguration _config,ref CommunicationTypes model)
    {
        var rep = new DoctorRepository(_config);
        return rep.UpdateCommunicationType(model);
    }
    public List<TodaysAppointment> GetTodayAppointmentList(IConfiguration _config,int CommunicationTypeID,int SearchType,int PatientID)
    {
        var rep = new DoctorRepository(_config);
        return rep.GetTodayAppointmentList(CommunicationTypeID, SearchType, PatientID);
    }
    public M_AppSetting GetAppSettings(IConfiguration _config)
    {
        var rep = new DoctorRepository(_config);
        return rep.GetAppSettings();
    }
    public List<ConsultationStatusModel> GetConsultationStatus(IConfiguration _config)
    {
        var rep = new DoctorRepository(_config);
        return rep.GetConsultationStatus();
    }
    public bool AddConsultationDetail(IConfiguration _config, ref ConsultationDetailModel model)
    {
        var rep = new DoctorRepository(_config);
        return rep.AddConsultationDetail(model);

    }
    public List<AvailableDates> GetDatewiseTimeslots(IConfiguration _config,int GetDatewiseTimeslots,string date)
    {
        var rep = new DoctorRepository(_config);
        return rep.GetDatewiseTimeslots(GetDatewiseTimeslots,date);
    }
    public List<TimeSlotList> GetAllocatedTimeslots(IConfiguration _config)
    {
        var rep = new DoctorRepository(_config);
        return rep.GetAllocatedTimeslots();
    }
    public List<TimeSlotList> GetAllocatedTimeslotDetails(IConfiguration _config,string AvailableDate,string CommunicationType)
    {
        var rep = new DoctorRepository(_config);
        return rep.GetAllocatedTimeslotDetails(AvailableDate, CommunicationType);
    }
    public string GetQuestionnaireReport(IConfiguration _config,int UserID)
    {
        var rep = new DoctorRepository(_config);
        return rep.GetQuestionnaireReport(UserID);
    }
}