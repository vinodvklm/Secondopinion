using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Microsoft.Extensions.Configuration;
using SecondOpinionWeb.Models;
using SecondOpinionWeb.Repositories;
using BusinessLib;

public class PatientProvider 
{
    public PatientDetails AddAppointment(IConfiguration _config,ref Appointment model)
    {
        PatientDetails PatientDetails=new PatientDetails();
        try
        {

            var rep = new PatientRepository(_config);
            PatientDetails = rep.AddAppointment(model);
            return PatientDetails;
        }
        catch(System.Exception)
        {
            return PatientDetails;
        }
        
    }
    public List<ConsultationStatus> GetConsultationStatus(IConfiguration _config)
    {
        List<ConsultationStatus> result=new List<ConsultationStatus>();
      
        var rep = new PatientRepository(_config);
        result = rep.GetConsultationStatus();
        return result;
    }
    
    public List<PatientDetails> GetConsultationDetails(IConfiguration _config,int UserID)
    {
        List<PatientDetails> result=new List<PatientDetails>();
      
        var rep = new PatientRepository(_config);
        result = rep.GetConsultationDetails(UserID);
        return result;
    }
    public PatientHistory GetConsultationHistory(IConfiguration _config,int PatientID)
    {
        PatientHistory result=new PatientHistory();
      
        var rep = new PatientRepository(_config);
        result = rep.GetConsultationHistory(PatientID);
        return result;
    }
    public List<PatientConsultationStatus> GetPatientConsultationStatus(IConfiguration _config,int PatientID)
    {
        List<PatientConsultationStatus> result=new List<PatientConsultationStatus>();
      
        var rep = new PatientRepository(_config);
        result = rep.GetPatientConsultationStatus(PatientID);
        return result;
    }
    public List<CommunicationTypes> GetCommunicationTypes(IConfiguration _config)
    {
        List<CommunicationTypes> result=new List<CommunicationTypes>();
      
        var rep = new PatientRepository(_config);
        result = rep.GetCommunicationTypes();
        return result;
    }
    public List<PatientDocumentLi> GetMyConsultationDocuments(IConfiguration _config,int UserID,int PatientID)
    {
        List<PatientDocumentLi> result=new List<PatientDocumentLi>();
      
        var rep = new PatientRepository(_config);
        result = rep.GetMyConsultationDocuments(UserID, PatientID);
        return result;
    }
    public bool AddPatientDocuments(IConfiguration _config, ref PatientDocumentInfo model)
    {
        var rep = new PatientRepository(_config);
        return rep.AddPatientDocuments(model);

    }
    public int GetFreeConsultationCount(IConfiguration _config, int UserID, int CommunicationTypeID)
    {
        var rep = new PatientRepository(_config);
        return rep.GetFreeConsultationCount(UserID, CommunicationTypeID);

    }
    public PatientDetails UpdateConsultationCount(IConfiguration _config, ref FreeConsultationInfo model)
    {
        var rep = new PatientRepository(_config);
        return rep.UpdateConsultationCount(model);

    }
    public List<ConsultationCompletedList> GetConsultationCompletedList(IConfiguration _config, int UserID)
    {
        var rep = new PatientRepository(_config);
        return rep.GetConsultationCompletedList(UserID);

    }
}