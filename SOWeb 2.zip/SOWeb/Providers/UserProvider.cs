using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BusinessLib;
using System.Data;
using SecondOpinionWeb.Models;
using SecondOpinionWeb.Repositories;
using Microsoft.Extensions.Configuration;
using log4net;
using System.Reflection;
using SecondOpinionWeb;


public class UserProvider 
{

    // User Registration
    public UserRegModel AddUser(IConfiguration _config, ref UserModel model)
    {   
        UserRegModel result = new UserRegModel();
        try
        {
            var rep = new UserRepository(_config);
            result = rep.AddUser(model);
            return result;
        }
        catch (System.Exception)
        {
            
            return result;
        }
            

    }
    public UserModel UpdateUser(IConfiguration _config, ref UserModel model)
    {   
        UserModel result = new UserModel();
        try
        {
            var rep = new UserRepository(_config);
            result = rep.UpdateUser(model);
            return result;
        }
        catch (System.Exception)
        {
            
            return result;
        }
            

    }
   
    public bool UserExists(IConfiguration _config,string email)
    {
        bool res=false;
        try
        {
        UserModel result = new UserModel();

        var rep = new UserRepository(_config);
        result = rep.UserExists(email);
        if(result!=null)
            res=true;

        return res;
        }
        catch(System.Exception)
        {
            return res;
        }
        
    }
    
    public List<Dependent> GetDependent(IConfiguration _config,int UserID)
    {
        List<Dependent> result=new List<Dependent>();
      
        var rep = new UserRepository(_config);
        result = rep.GetDependent(UserID);
        return result;
    }

    public int AddDependent(IConfiguration _config,ref Dependent model)
    {
        int result=0;
        try
        {

            var rep = new UserRepository(_config);
            result=rep.AddDependent(model);
            return result;
        }
        catch(System.Exception)
        {
            return result;
        }
        
    }

    public UserProfile GetUserProfile(IConfiguration _config,int UserID)
    {
        UserProfile UserProfile=new UserProfile();
      
        var rep = new UserRepository(_config);
        UserProfile = rep.GetUserProfile(UserID);
        return UserProfile;
    }
    
    public int UpdatePasswordToken(IConfiguration _config,AppSettings appSettings, MailSettings mailSettings, ref ForgotPasswordRequest model)
    {
        var result =0;
        try
        {
            var rep = new UserRepository(_config);
            int _token = GetRandomNumber(100000, 999999);
        
            result = rep.UpdatePasswordToken(model.Email,_token.ToString());

            if(result>0)
            {

            }
            return result;
        }
        catch(Exception ex)
        {
            return result;
        }
    }

    private static readonly Random getrandom = new Random();
    private static readonly object syncLock = new object();

    public static int GetRandomNumber(int min, int max)
    {
        lock (syncLock)
        {
            return getrandom.Next(min, max);
        }
    }
    public UserDashboardModel GetUserDashboard(IConfiguration _config, int UserID)
    {

        var rep = new UserRepository(_config);
        return rep.GetUserDashboard(UserID);
    }

}