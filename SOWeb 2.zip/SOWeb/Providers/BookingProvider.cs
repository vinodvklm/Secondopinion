using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Microsoft.Extensions.Configuration;
using SecondOpinionWeb.Models;
using SecondOpinionWeb.Repositories;
using BusinessLib;

public class BookingProvider 
{
    public List<DoctorAvailableDate> GetDoctorAvailableDate(IConfiguration _config,int CommunicationTypeID)
    {
        List<DoctorAvailableDate> result=new List<DoctorAvailableDate>();
      
        var rep = new BookingRepository(_config);
        result = rep.GetDoctorAvailableDate(CommunicationTypeID);
        return result;
    }
    public List<DoctorAvailableTime> GetDoctorAvailableTime(IConfiguration _config,string date,int CommunicationTypeID)
    {
        List<DoctorAvailableTime> result=new List<DoctorAvailableTime>();
      
        var rep = new BookingRepository(_config);
        result = rep.GetDoctorAvailableTime(date,CommunicationTypeID);
        return result;
    }
    public string AddDoctorAvailableTimes(IConfiguration _config,ref AvailableDates model)
    {
        string res="";
        try
        {

            var rep = new BookingRepository(_config);
            res = rep.AddDoctorAvailableTimes(model);
            return res;
        }
        catch(System.Exception)
        {
            return res;
        }
        
    }
    public List<DoctorUnAvailableDate> GetDoctorUnAvailableDate(IConfiguration _config,int CommunicationTypeID)
    {
        List<DoctorUnAvailableDate> result=new List<DoctorUnAvailableDate>();
      
        var rep = new BookingRepository(_config);
        result = rep.GetDoctorUnAvailableDate(CommunicationTypeID);
        return result;
    }
    public List<PaymentHistory> GetPaymentHistory(IConfiguration _config,int UserID)
    {
        List<PaymentHistory> result=new List<PaymentHistory>();
      
        var rep = new BookingRepository(_config);
        result = rep.GetPaymentHistory(UserID);
        return result;
    }
}