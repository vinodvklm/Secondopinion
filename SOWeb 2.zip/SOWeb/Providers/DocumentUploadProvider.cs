using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Microsoft.Extensions.Configuration;
using SecondOpinionWeb.Models;
using SecondOpinionWeb.Repositories;
using BusinessLib;

public class DocumentUploadProvider 
{

   
    public bool AddDocuments(IConfiguration _config,ref UserDocument model)
    {
        bool res=false;
        try
        {

            var rep = new DocumentUploadRepository(_config);
            res = rep.AddDocuments(model);
            return res;
        }
        catch(System.Exception)
        {
            return res;
        }
        
    }
    public List<UserDocumentLi> DeleteUserDocument(IConfiguration _config,UserDocumentRemove model)
    {
        List<UserDocumentLi> result=new List<UserDocumentLi>();
        try
        {

            var rep = new DocumentUploadRepository(_config);
            result = rep.DeleteUserDocument(model);
            return result;
        }
        catch(System.Exception)
        {
            return result;
        }
        
    }

    public List<UserDocumentLi> GetMedicalDocuments(IConfiguration _config,bool IsSelfDependent,int RefernceID)
    {
        List<UserDocumentLi> result=new List<UserDocumentLi>();
      
        var rep = new DocumentUploadRepository(_config);
        result = rep.GetMedicalDocuments(IsSelfDependent,RefernceID);
        return result;
    }

    public bool UpdateDocumentAccessibility(IConfiguration _config,ref DocumentAccessibility model)
    {
        bool res=false;
        try
        {

            var rep = new DocumentUploadRepository(_config);
            res = rep.UpdateDocumentAccessibility(model);
            return res;
        }
        catch(System.Exception)
        {
            return res;
        }
        
    }

    public bool AddPatientDocuments(IConfiguration _config, ref PatientDocument model)
    {
        bool res=false;
        try
        {

            var rep = new DocumentUploadRepository(_config);
            res = rep.AddPatientDocuments(model);
            return res;
        }
        catch(System.Exception)
        {
            return res;
        }
        
    }
    public T_UserDocumentDetails GetDocumentDetails(IConfiguration _config, int UserDocumentDetailID)
    {
        try
        {

            var rep = new DocumentUploadRepository(_config);
            return rep.GetDocumentDetails(UserDocumentDetailID);
        }
        catch (System.Exception)
        {
            return null;
        }
    }
    public List<DocumentModel> GetPatientDocuments(IConfiguration _config,int UserID)
    {

        var rep = new DocumentUploadRepository(_config);
        return rep.GetPatientDocuments(UserID);
    }

    }