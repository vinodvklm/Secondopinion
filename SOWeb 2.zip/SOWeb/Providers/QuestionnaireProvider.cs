using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Microsoft.Extensions.Configuration;
using SecondOpinionWeb.Models;
using SecondOpinionWeb.Repositories;
using BusinessLib;

public class QuestionnaireProvider 
{

    public List<Form> GetFormDetails(IConfiguration _config,int FormID)
    {
        List<Form> result=new List<Form>();
      
        var rep = new QuestionnaireRepository(_config);
        result = rep.GetFormDetails(FormID);
        return result;
    }
    public List<Question> GetQuestions(IConfiguration _config,int FormID,int SectionNumber)
    {
        List<Question> result=new List<Question>();
      
        var rep = new QuestionnaireRepository(_config);
        result = rep.GetQuestions(FormID, SectionNumber);
        return result;
    }
    public List<QuestionOption> GetQuestionOptions(IConfiguration _config,int QuestionID)
    {
        List<QuestionOption> result=new List<QuestionOption>();
      
        var rep = new QuestionnaireRepository(_config);
        result = rep.GetQuestionOptions(QuestionID);
        return result;
    }
    public List<QuestionParentBranch> GetParentBranches(IConfiguration _config,int QuestionID)
    {
        List<QuestionParentBranch> result=new List<QuestionParentBranch>();
      
        var rep = new QuestionnaireRepository(_config);
        result = rep.GetParentBranches(QuestionID);
        return result;
    }
    public List<QuestionChildBranch> GetChildBranches(IConfiguration _config,int QuestionID)
    {
        List<QuestionChildBranch> result=new List<QuestionChildBranch>();
      
        var rep = new QuestionnaireRepository(_config);
        result = rep.GetChildBranches(QuestionID);
        return result;
    }
    // User Registration
    public bool SaveQuestionnaire(IConfiguration _config, ref QuestionnaireInfo model)
    {   
        bool result=false;
        try
        {
            var rep = new QuestionnaireRepository(_config);
            result = rep.SaveQuestionnaire(model);
            return result;
        }
        catch (System.Exception)
        {
            
            return result;
        }


    }
    public List<FormSubmitted> GetSavedSection(IConfiguration _config, int FormID, int UserID, int PatientID, int SectionNumber)
    {
        var rep = new QuestionnaireRepository(_config);
        return rep.GetSavedSection(FormID, UserID, PatientID, SectionNumber);
    }
    public List<PainLocation> GetSavedPainLocation(IConfiguration _config, int FormID, int UserID, int PatientID, int SectionNumber)
    {
        var rep = new QuestionnaireRepository(_config);
        return rep.GetSavedPainLocation(FormID, UserID, PatientID, SectionNumber);
    }
    public List<PainSpots> GetSavedPainSpots(IConfiguration _config, int FormID, int UserID, int PatientID, int SectionNumber)
    {
        var rep = new QuestionnaireRepository(_config);
        return rep.GetSavedPainSpots(FormID, UserID, PatientID, SectionNumber);
    }
    public List<PainMedication> GetSavedPainMedications(IConfiguration _config, int FormID, int UserID, int PatientID, int SectionNumber)
    {
        var rep = new QuestionnaireRepository(_config);
        return rep.GetSavedPainMedications(FormID, UserID, PatientID, SectionNumber);
    }
    public int GetLastSavedSection(IConfiguration _config, int FormID,int UserID,int PatientID)
    {
        
        var rep = new QuestionnaireRepository(_config);
        return rep.GetLastSavedSection(FormID, UserID, PatientID);
    }
}