using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Microsoft.Extensions.Configuration;
using SecondOpinionWeb.Models;
using SecondOpinionWeb.Repositories;
using BusinessLib;

public class AuthProvider 
{

    // User Login
   
    public LoginModel Login(IConfiguration _config, string email, string password)
    {
        LoginModel result = new LoginModel{};
        try
        {
            var rep = new AuthRepository(_config);
            result = rep.Login(email,password);
            return result;
        }
        catch (System.Exception)
        {
            
            return result;
        }
        
       
    }
  
   
    
}