using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace BusinessLib
{

    public static partial class Messages
    {
        // Messages

        public const string C_MSGBOX_TITLE_ADD_NEW_USER = "New User Created";
        public const string C_MSGBOX_TITLE_USERNAME_EXIST = "Username already exists";
        public const string C_MSGBOX_MSG_FAILED_ADD_USER = "Failed to add user";
        
        public const string C_MSGBOX_MSG_SUCCESS_PASSWORD_RESET_INVALID_EMAIL = "Emailid doesn't exist.";
        public const string C_MSGBOX_MSG_SUCCESS_PASSWORD_RESET_MAIL = "A link to reset password has been sent to your registered email id.";

        public const string C_MSGBOX_TITLE_ADD_NEW_DEPENDENT = "New Depended Created";
        public const string C_MSGBOX_MSG_FAILED_ADD_USERDEPENDENT = "Failed to add depended";

        public const string C_MSGBOX_MSG__ADD_USER_DOCUMENT = "Document successfully uploaded";
        public const string C_MSGBOX_MSG__FAILED_ADD_USER_DOCUMENT = "Failed to upload user documents";

        public const string C_MSGBOX_MSG__REMOVE_USER_DOCUMENT = "Document successfully removed";
        public const string C_MSGBOX_MSG__FAILED_REMOVE_USER_DOCUMENT = "Failed to remove user documents";

        public const string C_MSGBOX_MSG__UPDATE_DOCUMENT_ACCESSIBILITY = "Document accessibility successfully updated";
        public const string C_MSGBOX_MSG__FAILED_UPDATE_DOCUMENT_ACCESSIBILITY = "Failed to update document accessibility ";

        public const string C_MSGBOX_MSG_APPOINMENT_DATE_ERROR = "Appointment To date should be greater than Appointment From date";
        public const string C_MSGBOX_TITLE_APPOINTMENT_EXIST = "Already an appointment exists";
        public const string C_MSGBOX_TITLE_ADD_NEW_APPOINTMENT= "New Appointment successfully added";
        public const string C_MSGBOX_MSG__FAILED_ADD_APPOINTMENT = "Failed to add new appointment";

        public const string C_MSGBOX_MSG_USER_NOT_EXIST= "User doesn't exists";
        public const string C_MSGBOX_TITLE_USERNAME_NOT_EXIST = "Username not exists";

        public const string C_MSGBOX_TIMESLOT_EXIST = "Time slot already exists";
        public const string C_MSGBOX_MSG_DATE_ERROR = "To date should be greater than From date";
    }
}