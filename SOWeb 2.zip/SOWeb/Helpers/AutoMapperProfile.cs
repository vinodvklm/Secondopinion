using SecondOpinionWeb.Dtos;
using SecondOpinionWeb.Models;
using AutoMapper;

namespace SecondOpinionWeb.Helpers
{
    public class AutoMapperProfile: Profile
    {
        public AutoMapperProfile()
        {
            //CreateMap<LoginDto, T_APP_USER>();
            //CreateMap<RegisterDto, T_APP_USER>();
        }
    }
}