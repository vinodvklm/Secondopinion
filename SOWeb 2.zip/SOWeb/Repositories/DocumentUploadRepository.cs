using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Dapper;
using System.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using SecondOpinionWeb.Models;
using System.IO;

namespace SecondOpinionWeb.Repositories
{
    public class DocumentUploadRepository
    {

        private readonly IDbConnection _db;
      
        public DocumentUploadRepository(IConfiguration _config)
        {
            _db = new SqlConnection(_config.GetConnectionString("SQLConnection"));
        }
        public DocumentUploadRepository(string constr)
        {
            _db = new SqlConnection(constr);
        }

        public bool AddDocuments(UserDocument model)
        {
            int Uploaded = 0;  
            using (IDbConnection dbConnection = _db)
            {
                if (dbConnection.State == ConnectionState.Closed)
                {
                    dbConnection.Open();
                } 

                StringBuilder strXML=new StringBuilder();
                strXML.Append("<UserDocument>");
                strXML.Append("<UserDocumentDetails>");
                strXML.Append("<UserID>"+model.UserID+"</UserID>");
                strXML.Append("<DocumentName>"+model.DocumentName+"</DocumentName>");
                strXML.Append("<ReportDate>"+model.ReportDate+"</ReportDate>");
                strXML.Append("<DocumentAccess>"+model.DocumentAccess+"</DocumentAccess>");
                strXML.Append("<ValidFrom>"+ model.ValidFrom+"</ValidFrom>");
                strXML.Append("<ValidTo>"+model.ValidTo+"</ValidTo>");
                strXML.Append("<UserType>"+model.UserType+"</UserType>");
                strXML.Append("<Remarks>"+model.Remarks+"</Remarks>");
                strXML.Append("</UserDocumentDetails>");
                strXML.Append("<DocumentPathList>");
                
                foreach (var item in model.DocumentPath)
                {
                    string filename = System.IO.Path.GetFileName(item.uri);
                    var fi = new FileInfo(item.uri);
                    var Extension = fi.Extension;

                    strXML.Append("<UserDocumentDetails>");
                    strXML.Append("<DocumentPath>"+item.uri+"</DocumentPath>");
                    strXML.Append("<FileName>"+filename+"</FileName>");
                    strXML.Append("<DocumentType>"+Extension+"</DocumentType>");
                    strXML.Append("</UserDocumentDetails>");
                   
                }
                   
                strXML.Append("</DocumentPathList>");
                strXML.Append("</UserDocument>");

                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@XMLDoc",strXML.ToString());
                parameters.Add("UploadedFlag", dbType: DbType.Int32, direction: ParameterDirection.Output);
                dbConnection.Execute("usp_AddUserDocument",parameters,commandType:CommandType.StoredProcedure);
                Uploaded =  parameters.Get<int>("UploadedFlag");
                
            }
            if(Uploaded==1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public List<UserDocumentLi> DeleteUserDocument(UserDocumentRemove model)
        {
            List<UserDocumentLi> UserDocumentLi=new List<UserDocumentLi>(); 
            using (IDbConnection dbConnection = _db)
            {
                if (dbConnection.State == ConnectionState.Closed)
                {
                    dbConnection.Open();
                } 
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@UserDocumentDetailID",model.UserDocumentDetailID);                
                UserDocumentLi = dbConnection.Query<UserDocumentLi>("usp_RemoveUserDocument", parameters, commandType:CommandType.StoredProcedure).ToList(); 
            }
            return UserDocumentLi;
        }

        public List<UserDocumentLi> GetMedicalDocuments(bool IsSelfDependent,int RefernceID)
        {
            List<UserDocumentLi> UserDocumentLi=new List<UserDocumentLi>();
            using (IDbConnection dbConnection = _db) 
            {
                if (dbConnection.State == ConnectionState.Closed)
                {
                    dbConnection.Open();
                }  
                DynamicParameters parameter = new DynamicParameters();  
                parameter.Add("@IsSelfDependent", IsSelfDependent);  
                parameter.Add("@RefernceID", RefernceID); 
                UserDocumentLi = dbConnection.Query<UserDocumentLi>("usp_GetUserDocument", parameter, commandType:CommandType.StoredProcedure).ToList(); 
            }
            return UserDocumentLi;
        }

        public bool UpdateDocumentAccessibility(DocumentAccessibility model)
        {
            int rowAffected = 0;  
            using (IDbConnection dbConnection = _db)
            {
                if (dbConnection.State == ConnectionState.Closed)
                {
                    dbConnection.Open();
                } 

                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@UserDocumentID",model.UserDocumentID);
                parameters.Add("@DocumentAccess",model.DocumentAccess);
                parameters.Add("@ValidFrom",model.ValidFrom);
                parameters.Add("@ValidTo",model.ValidTo);
                rowAffected=dbConnection.Execute("usp_UpdateDocumentAccess",parameters,commandType:CommandType.StoredProcedure);

            }
            if(rowAffected==1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public bool AddPatientDocuments(PatientDocument model)
        {
            int Uploaded = 0;  
            using (IDbConnection dbConnection = _db)
            {
                if (dbConnection.State == ConnectionState.Closed)
                {
                    dbConnection.Open();
                } 

                StringBuilder strXML=new StringBuilder();
                strXML.Append("<PatientDocument>");
                strXML.Append("<PatientDocumentDetails>");
                strXML.Append("<PatientID>"+model.PatientID+"</PatientID>");
                strXML.Append("<DocumentName>"+model.DocumentName+"</DocumentName>");
                strXML.Append("<ReportDate>"+model.ReportDate+"</ReportDate>");
                strXML.Append("<ValidFrom>"+model.ValidFrom+"</ValidFrom>");
                strXML.Append("<ValidTo>"+model.ValidTo+"</ValidTo>");
                strXML.Append("<Remarks>"+model.Remarks+"</Remarks>");
                strXML.Append("</PatientDocumentDetails>");
                strXML.Append("<DocumentPathList>");
                
                foreach (var item in model.DocumentPath)
                {
                    strXML.Append("<DocumentPathDetails>");
                    strXML.Append("<DocumentPath>"+item.uri+"</DocumentPath>");
                    strXML.Append("</DocumentPathDetails>");
                   
                }
                   
                strXML.Append("</DocumentPathList>");
                strXML.Append("</PatientDocument>");

                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@XMLDoc",strXML.ToString());
                parameters.Add("UploadedFlag", dbType: DbType.Int32, direction: ParameterDirection.Output);
                dbConnection.Execute("usp_AddPatientDocument",parameters,commandType:CommandType.StoredProcedure);
                Uploaded =  parameters.Get<int>("UploadedFlag");
                
            }
            if(Uploaded==1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public T_UserDocumentDetails GetDocumentDetails(int UserDocumentDetailID)
        {
            return this._db.Query<T_UserDocumentDetails>(@"SELECT * FROM T_UserDocumentDetails WHERE UserDocumentDetailID=@UserDocumentDetailID",
                new { UserDocumentDetailID = UserDocumentDetailID }).FirstOrDefault();
        }
        public List<DocumentModel> GetPatientDocuments(int UserID)
        {
            string sQuery = @"SELECT		U.UserID,FirstName+' '+ISNULL(MiddleName,'')+' '+ISNULL(LastName,'') AS Name,Relationship,
			                                D.UserDocumentID,DocumentName,CONVERT(NVARCHAR, ReportDate, 106) AS ReportDate,
			                                CONVERT(NVARCHAR, ValidFrom, 106) AS ValidFrom,CONVERT(NVARCHAR, ValidTo, 106) AS ValidTo,
			                                DD.UserDocumentDetailID,FileName,DocumentType,DocumentPath
                                FROM		T_UserDocument D
                                INNER JOIN	T_UserDocumentDetails DD
                                ON			D.UserDocumentID=DD.UserDocumentFK
                                INNER JOIN	T_UserDependent UD
                                ON			D.UserFK=UD.UserFK
                                INNER JOIN	T_APP_USER U
                                ON			D.UserFK=U.UserID
                                WHERE		D.UserFK IN (SELECT UserFK FROM T_UserDependent WHERE ParentFK=@UserID)";
            return this._db.Query<DocumentModel>(sQuery,new { UserID = UserID }).ToList();
        }
    } 
}
