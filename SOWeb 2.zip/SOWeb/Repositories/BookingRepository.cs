using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Dapper;
using System.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using SecondOpinionWeb.Models;


namespace SecondOpinionWeb.Repositories
{
    public class BookingRepository
    {

        private readonly IDbConnection _db;
      
        public BookingRepository(IConfiguration _config)
        {
            _db = new SqlConnection(_config.GetConnectionString("SQLConnection"));
        }
        public BookingRepository(string constr)
        {
            _db = new SqlConnection(constr);
        }
        public List<DoctorAvailableDate> GetDoctorAvailableDate(int CommunicationTypeID)
        {
            
            List<DoctorAvailableDate> DoctorAvailableDateLi=new List<DoctorAvailableDate>();
            using (IDbConnection dbConnection = _db) 
            {
                if (dbConnection.State == ConnectionState.Closed)
                {
                    dbConnection.Open();
                }  
                DynamicParameters parameter = new DynamicParameters(); 
                parameter.Add("@CommunicationTypeID",CommunicationTypeID);
                DoctorAvailableDateLi = dbConnection.Query<DoctorAvailableDate>("usp_GetDoctorAvailableDates", parameter, commandType:CommandType.StoredProcedure).ToList(); 
            }
            return DoctorAvailableDateLi;
        }
       
        public List<DoctorAvailableTime> GetDoctorAvailableTime(string date,int CommunicationTypeID)
        {
            List<DoctorAvailableTime> DoctorAvailableTimeLi=new List<DoctorAvailableTime>();
            using (IDbConnection dbConnection = _db) 
            {
                if (dbConnection.State == ConnectionState.Closed)
                {
                    dbConnection.Open();
                }  
                DynamicParameters parameter = new DynamicParameters(); 
                parameter.Add("@AvailableDate",date); 
                parameter.Add("@CommunicationTypeID",CommunicationTypeID); 
                DoctorAvailableTimeLi = dbConnection.Query<DoctorAvailableTime>("usp_GetDoctorAvailableTimeSlotes", parameter, commandType:CommandType.StoredProcedure).ToList(); 
            }
            return DoctorAvailableTimeLi;
        }

        public string AddDoctorAvailableTimes(AvailableDates model)
        {
            int RowsAffected =0;
            string  Output="";
            using (IDbConnection dbConnection = _db)
            {
                if (dbConnection.State == ConnectionState.Closed)
                {
                    dbConnection.Open();
                } 

                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@Date",model.Date);
                parameters.Add("@CommunicationTypeID",model.CommunicationTypeID);
                parameters.Add("@FromTime",model.FromTime);
                parameters.Add("@ToTime",model.ToTime);
                parameters.Add("@MessageOUT", dbType:DbType.String,direction:ParameterDirection.Output,size:5215585); 
                RowsAffected=dbConnection.Execute("usp_AddDoctorAvailableTimes",parameters,commandType:CommandType.StoredProcedure);
                Output = parameters.Get<string>("@MessageOUT");  
              
            }
            return Output;

        } 
        public List<DoctorUnAvailableDate> GetDoctorUnAvailableDate(int CommunicationTypeID)
        {
            
            List<DoctorUnAvailableDate> DoctorAvailableDateLi=new List<DoctorUnAvailableDate>();
            using (IDbConnection dbConnection = _db) 
            {
                if (dbConnection.State == ConnectionState.Closed)
                {
                    dbConnection.Open();
                }  
                DynamicParameters parameter = new DynamicParameters(); 
                parameter.Add("@CommunicationTypeID",CommunicationTypeID);
                DoctorAvailableDateLi = dbConnection.Query<DoctorUnAvailableDate>("usp_GetDoctorUnAvailableDayOfThisMonth", parameter, commandType:CommandType.StoredProcedure).ToList(); 
            }
            return DoctorAvailableDateLi;
        }

        public List<PaymentHistory> GetPaymentHistory(int UserID)
        {
            
            List<PaymentHistory> PaymentHistoryLi=new List<PaymentHistory>();
            using (IDbConnection dbConnection = _db) 
            {
                if (dbConnection.State == ConnectionState.Closed)
                {
                    dbConnection.Open();
                }  
                DynamicParameters parameter = new DynamicParameters(); 
                parameter.Add("@UserID",UserID);
                PaymentHistoryLi = dbConnection.Query<PaymentHistory>("usp_GetPaymentHistory", parameter, commandType:CommandType.StoredProcedure).ToList(); 
            }
            return PaymentHistoryLi;
        }
    } 
}
