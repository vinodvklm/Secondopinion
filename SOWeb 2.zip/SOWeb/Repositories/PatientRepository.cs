using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Dapper;
using System.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using SecondOpinionWeb.Models;
using System.IO;

namespace SecondOpinionWeb.Repositories
{
    public class PatientRepository
    {

        private readonly IDbConnection _db;
      
        public PatientRepository(IConfiguration _config)
        {
            _db = new SqlConnection(_config.GetConnectionString("SQLConnection"));
        }
        public PatientRepository(string constr)
        {
            _db = new SqlConnection(constr);
        }

        public PatientDetails AddAppointment(Appointment model)
        {
            PatientDetails PatientInfo=new PatientDetails();

            try
            {
                using (IDbConnection dbConnection = _db)
                {
                    if (dbConnection.State == ConnectionState.Closed)
                    {
                        dbConnection.Open();
                    }

                    var _counter = dbConnection.Query<CounterModel>("SELECT * FROM M_Counter WHERE CounterType=1").Single();
                    _counter.CounterValue += 1;
                    model.PatientNumber = _counter.Prefix + _counter.CounterValue.ToString().PadLeft(5, '0');


                    DynamicParameters parameters = new DynamicParameters();
                    parameters.Add("@PatientType", model.PatientType);
                    parameters.Add("@ReferenceID", model.ReferenceID);
                    parameters.Add("@DoctorAvailabilityDetailID", model.DoctorAvailabilityDetailID);
                    parameters.Add("@Remarks", model.Remarks);
                    parameters.Add("@PaymentID", model.PaymentID);
                    parameters.Add("@PaymentState", model.PaymentState);
                    parameters.Add("@PaymentCreate_time", model.PaymentCreate_time);
                    parameters.Add("@PaymentResponse_type", model.PaymentResponse_type);
                    parameters.Add("@PaymentAmount", model.PaymentAmount);
                    parameters.Add("@PatientNumber", model.PatientNumber);
                    parameters.Add("@CurrencySymbol", model.CurrencySymbol);
                    PatientInfo = dbConnection.Query<PatientDetails>("usp_AddAppointment", parameters, commandType: CommandType.StoredProcedure).FirstOrDefault();

                    if (PatientInfo != null && PatientInfo.PatientID > 0)
                    {
                        if (PatientInfo.CommunicationTypeFK == 3)// only applicable for voice call
                        {
                            DateTime ValidFrom = DateTime.Now;
                            DateTime ValidTo = DateTime.Now.AddDays(1).AddMonths(2).AddDays(-1);

                            var query_insert_validity = @"INSERT INTO T_PatientConsultationValidity(PatientFK,CommunicationTypeFK,BookingCount,UserFK,ValidFrom,ValidTo)
                                                            SELECT	@PatientID,3,1,@ReferenceID,@ValidFrom,@ValidTo";

                            dbConnection.Execute(query_insert_validity, new { PatientID = PatientInfo.PatientID, ReferenceID = model.ReferenceID, @ValidFrom, @ValidTo });

                        }



                        string _query_update_order_counter = @"UPDATE M_Counter SET CounterValue=@CounterValue WHERE CounterType=1";
                        dbConnection.Execute(_query_update_order_counter, new { CounterValue = _counter.CounterValue });
                    }
                }
            }
            catch(Exception ex)
            {
                string msg= ex.Message;
                return PatientInfo;
            }

            return PatientInfo;

        }  

        public List<CommunicationTypes> GetCommunicationTypes()
        {
            string sQuery= " SELECT * FROM M_CommunicationType";
            return _db.Query<CommunicationTypes>(sQuery).ToList();
        }

        public List<ConsultationStatus> GetConsultationStatus()
        {
            string sQuery=  " SELECT ConsultationStatusID,ConsultationStatus AS Status FROM M_ConsultationStatus";
            return _db.Query<ConsultationStatus>(sQuery).ToList();
        }
        public List<PatientDetails> GetConsultationDetails(int UserID)
        {
            List<PatientDetails> PatientDetailsLi=new List<PatientDetails>();
            using (IDbConnection dbConnection = _db) 
            {
                if (dbConnection.State == ConnectionState.Closed)
                {
                    dbConnection.Open();
                }  
                DynamicParameters parameter = new DynamicParameters(); 
                parameter.Add("@UserID",UserID); 
                PatientDetailsLi = dbConnection.Query<PatientDetails>("usp_GetConsultationDetails", parameter, commandType:CommandType.StoredProcedure).ToList(); 
            }
            return PatientDetailsLi;
        }
        public PatientHistory GetConsultationHistory(int PatientID)
        {
            PatientHistory PatientHistory=new PatientHistory();
            using (IDbConnection dbConnection = _db) 
            {
                if (dbConnection.State == ConnectionState.Closed)
                {
                    dbConnection.Open();
                }  
                DynamicParameters parameter = new DynamicParameters(); 
                parameter.Add("@PatientID",PatientID); 
                PatientHistory = dbConnection.Query<PatientHistory>("usp_GetConsultationHistory", parameter, commandType:CommandType.StoredProcedure).FirstOrDefault(); 
            }
            return PatientHistory;
        }
        public List<PatientConsultationStatus> GetPatientConsultationStatus(int PatientID)
        {
            List<PatientConsultationStatus> ConsultationStatusLi=new List<PatientConsultationStatus>();
            using (IDbConnection dbConnection = _db) 
            {
                if (dbConnection.State == ConnectionState.Closed)
                {
                    dbConnection.Open();
                }  
                DynamicParameters parameter = new DynamicParameters(); 
                parameter.Add("@PatientID",PatientID); 
                ConsultationStatusLi = dbConnection.Query<PatientConsultationStatus>("usp_GetPatientConsultationStatus", parameter, commandType:CommandType.StoredProcedure).ToList(); 
            }
            return ConsultationStatusLi;
        }

        public List<PatientDocumentLi> GetMyConsultationDocuments(int UserID,int PatientID)
        {
            List<PatientDocumentLi> PatientDocumentLi=new List<PatientDocumentLi>();
            using (IDbConnection dbConnection = _db) 
            {
                if (dbConnection.State == ConnectionState.Closed)
                {
                    dbConnection.Open();
                }  
                DynamicParameters parameter = new DynamicParameters();  
                parameter.Add("@UserID", UserID);
                parameter.Add("@PatientFK", PatientID);
                PatientDocumentLi = dbConnection.Query<PatientDocumentLi>("usp_GetMyConsultationDocuments", parameter, commandType:CommandType.StoredProcedure).ToList(); 
            }
            return PatientDocumentLi;
        }
        public bool AddPatientDocuments(PatientDocumentInfo model)
        {
            long _insertedId = 0;
            string _query_insert_document = @"INSERT INTO [T_ConsultationDocument] ([PatientFK] ,[DocumentName] ,[Is_Active],[Is_Removed],[Is_Suspended],[UploadedBy]) 
                                                    VALUES (@PatientFK ,@DocumentName ,@Is_Active,@Is_Removed,@Is_Suspended,@UploadedBy);
                                                    SELECT CAST(SCOPE_IDENTITY() as bigint)";
            string _query_insert_documentdetails = @"INSERT INTO [T_ConsultationDocumentDetails]([ConsultationDocumentFK],[DocumentType],[DocumentPath],[Is_Active],[Is_Removed])
                                                    VALUES(@ConsultationDocumentFK,@DocumentType,@DocumentPath,@Is_Active,@Is_Removed)";

            using (var connection = new SqlConnection(_db.ConnectionString))
            {
                connection.Open();
                using (var transaction = connection.BeginTransaction())
                {
                    _insertedId = connection.Query<long>(_query_insert_document,
                     new
                     {
                         PatientFK = model.PatientID,
                         DocumentName = model.DocumentName,
                         Is_Active = true,
                         Is_Removed = false,
                         Is_Suspended = false,
                         UploadedBy= model.UserID
                     }, transaction: transaction).Single();

                    if (_insertedId > 0)
                    {
                        foreach(ConsultaionDocumentPath el in model.DocumentPath)
                        {
                            string filename = System.IO.Path.GetFileName(el.uri);
                            var fi = new FileInfo(el.uri);
                            var Extension = fi.Extension;

                            connection.Query<long>(_query_insert_documentdetails,
                             new
                             {
                                 ConsultationDocumentFK = _insertedId,
                                 DocumentType = Extension,
                                 DocumentPath=el.uri,
                                 Is_Active = true,
                                 Is_Removed = false,
                             }, transaction: transaction);
                        }

                        string _query_insert_consultation_status = @"INSERT INTO [T_PatientConsultationStatus]([PatientFK],[ConsultationStatusFK]) 
                                                                    VALUES(@PatientFK,@ConsultationStatusFK)";
                        connection.Query<long>(_query_insert_consultation_status,
                             new
                             {
                                 PatientFK = model.PatientID,
                                 ConsultationStatusFK= 3
                             }, transaction: transaction);

                        string _query_update_status = @"UPDATE T_Patient SET ConsultationStatusFK=3 WHERE PatientID=@PatientID";
                        connection.Query<long>(_query_update_status,
                             new
                             {
                                 PatientID = model.PatientID,
                             }, transaction: transaction);
                        transaction.Commit();
                        return true;
                    }
                    else
                    {
                        transaction.Rollback();
                        return false;
                    }
                }
            }

        }

        public int GetFreeConsultationCount(int UserID, int CommunicationTypeID)
        {
            DateTime Today = DateTime.Now;
            string sQuery = @"SELECT		TOP 1 BookingCount,UserFK
											FROM		T_PatientConsultationValidity 
											WHERE		UserFK=@UserFK AND ISNULL(BookingCount,0)<4 AND CommunicationTypeFK=@CommunicationTypeFK 
											AND			@Today BETWEEN ValidFrom AND ValidTo
											ORDER BY	PatientConsultationValidityID DESC";

            return _db.Query<int>(sQuery,new { UserFK= UserID, CommunicationTypeFK= CommunicationTypeID, Today = Today }).FirstOrDefault();
        }

        public PatientDetails UpdateConsultationCount(FreeConsultationInfo model)
        {
            PatientDetails PatientInfo = new PatientDetails();

            try
            {
                using (IDbConnection dbConnection = _db)
                {
                    if (dbConnection.State == ConnectionState.Closed)
                    {
                        dbConnection.Open();
                    }

                    var query_select_communicationtype = @"SELECT		CommunicationTypeFK
                                                            FROM		T_DoctorAvailability A
                                                            INNER JOIN	T_DoctorAvailabilityDetails AD
                                                            ON			A.DoctorAvailabilityID=AD.DoctorAvailabilityFK
                                                            WHERE		AD.DoctorAvailabilityDetailID=@DoctorAvailabilityDetailID";

                    int CommunicationTypeFK = dbConnection.Query<int>(query_select_communicationtype, new { model.DoctorAvailabilityDetailID }).Single();

                    if (CommunicationTypeFK == 3)//applicable for voice call 
                    {
                        var query1 = @"select Relationship from T_UserDependent where UserFK=@UserFK";
                        string Relationship = dbConnection.Query<string>(query1, new { UserFK=model.UserID }).Single();

                        if (Relationship == "MySelf")
                        {
                            DateTime Today = DateTime.Now;
                            PatientConsultationValidity ConsultationValidity = new PatientConsultationValidity();
                            var query2 = @"SELECT * FROM T_PatientConsultationValidity WHERE UserFK=@UserFK AND ISNULL(BookingCount,0)<4 AND CommunicationTypeFK=3 
                                    AND @Today BETWEEN ValidFrom AND ValidTo";
                            ConsultationValidity = dbConnection.Query<PatientConsultationValidity>(query2, new { UserFK= model.UserID, Today=Today }).LastOrDefault();
                            if (ConsultationValidity != null && ConsultationValidity.PatientFK > 0 && ConsultationValidity.BookingCount < 3)
                            {
                                int BookingCount = ConsultationValidity.BookingCount + 1;
                                var query_update_validity = @"UPDATE T_PatientConsultationValidity SET BookingCount=@BookingCount WHERE PatientConsultationValidityID=@PatientConsultationValidityID";
                                dbConnection.Execute(query_update_validity, new { BookingCount, ConsultationValidity.PatientConsultationValidityID });

                                var query_update_status = @"UPDATE	T_DoctorAvailabilityDetails SET BookingStatus='B' WHERE		DoctorAvailabilityDetailID=@DoctorAvailabilityDetailID";
                                dbConnection.Execute(query_update_status, new { model.DoctorAvailabilityDetailID });

                                var query_select_patientNumber = @"
                                                                    SELECT		*,UserFK AS UserID 
                                                                    FROM		T_Patient P
                                                                    INNER JOIN	T_PatientConsultationValidity V
                                                                    ON			P.PatientID=V.PatientFK
                                                                    WHERE		V.PatientConsultationValidityID=@PatientConsultationValidityID
                                                                    AND			P.PatientID=@PatientFK";
                                PatientInfo = dbConnection.Query<PatientDetails>(query_select_patientNumber, new { ConsultationValidity.PatientConsultationValidityID, ConsultationValidity.PatientFK }).FirstOrDefault();
                                PatientInfo.IsFreeConsultation = true;
                                return PatientInfo;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                string msg = ex.Message;
                return PatientInfo;
            }

            return PatientInfo;
        }
        public List<ConsultationCompletedList> GetConsultationCompletedList(int UserID)
        {
            string sQuery = @"SELECT		*,ISNULL(FirstName,'') +' '+ISNULL(MiddleName,'')+' '+ISNULL(MiddleName,'')AS Name
                                FROM		T_Patient P
                                INNER JOIN	T_APP_User U
                                ON			P.ReferenceID=U.UserID
                                INNER JOIN	M_ConsultationStatus S
                                ON			P.ConsultationStatusFK=S.ConsultationStatusID
                                INNER JOIN	T_UserDependent D
                                ON			D.UserFK=U.UserID
                                WHERE		ConsultationStatusFK=6
                                AND			ReferenceID IN (SELECT UserFK FROM T_UserDependent WHERE ParentFK=@UserID)";

            return _db.Query<ConsultationCompletedList>(sQuery, new { UserID = UserID}).ToList();
        }

    }
}
