using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Dapper;
using System.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using SecondOpinionWeb.Models;
using System.Text;
using System.IO;

namespace SecondOpinionWeb.Repositories
{
    public class DoctorRepository
    {
        
        private readonly IDbConnection _db;

        public DoctorRepository(IConfiguration _config)
        {
            _db = new SqlConnection(_config.GetConnectionString("SQLConnection"));
        }
        public DoctorRepository(string constr)
        {
            _db = new SqlConnection(constr);
        }
      
      
        public List<DicomUploadedViewer> GetDicomUploadedUser()
        {

         string   sQuery= @"SELECT		D.UserFK AS UserID,D.DocumentName,ReportDate,ValidFrom,ValidTo,DT.*,UserType,
                                        ISNULL(U.FirstName,'')+' '+ISNULL(U.MiddleName,'')+' '+ISNULL(U.LastName,'') AS Name ,
                                        U.Email,U.Gender,U.Age,U.MobileNumber,U.Profile_Image_URL

                            FROM		T_UserDocument D
                            INNER JOIN	T_UserDocumentDetails DT
                            ON			D.UserDocumentID=DT.UserDocumentFK
                            INNER JOIN	T_APP_USER U
                            ON			D.UserFK=U.UserID
                            WHERE		ISNULL(DT.DocumentType,'')='.DCM'";
            return _db.Query<DicomUploadedViewer>(sQuery).ToList();
        }
        public List<DicomViewerList> GetDicomByUserID(int UserID)
        {

            string sQuery = @"SELECT		UserFK AS UserID,UserDocumentID,DocumentName,ReportDate,DocumentAccess,ValidFrom,ValidTo,Remarks,
			                                UserDocumentDetailID,DocumentType,FileName,DocumentPath
                                FROM		T_UserDocument U
                                INNER JOIN	T_UserDocumentDetails D
                                ON			U.UserDocumentID=D.UserDocumentFK
                                WHERE		U.UserFK=@UserFK
                                AND			ISNULL(DocumentType,'')='.DCM'";
            return _db.Query<DicomViewerList>(sQuery,new { UserFK = UserID }).ToList();
        }
        public List<PatientDetail>  GetPatientist()
        {
            List<PatientDetail> PatientList = new List<PatientDetail>();
            using (IDbConnection dbConnection = _db)
            {
                if (dbConnection.State == ConnectionState.Closed)
                {
                    dbConnection.Open();
                }

                PatientList= dbConnection.Query<PatientDetail>("uspGetPatientList", commandType: CommandType.StoredProcedure).ToList();

            }
            return PatientList;


        }
        public List<DocumentDetail> GetDocumentDetail(int UserID, int DependentID)
        {
            string sQuery = "";
            if (DependentID>0)
            {
                sQuery = @"SELECT		D.UserDocumentID,D.DocumentName,CONVERT(VARCHAR(20),ReportDate,106) AS ReportDate ,FileName,DocumentPath,UserDocumentDetailID
                            FROM		T_UserDocument D
                            INNER JOIN	T_UserDocumentDetails DT
                            ON			D.UserDocumentID=DT.UserDocumentFK
                            WHERE		Ref_DependentFK='"+ DependentID + "'";
            }
            else
            {
                sQuery = @"SELECT		D.UserDocumentID,D.DocumentName,CONVERT(VARCHAR(20),ReportDate,106) AS ReportDate,FileName,DocumentPath,UserDocumentDetailID
                            FROM		T_UserDocument D
                            INNER JOIN	T_UserDocumentDetails DT
                            ON			D.UserDocumentID=DT.UserDocumentFK
                            WHERE		UserFk='"+ UserID + "'";
            }
            return  _db.Query<DocumentDetail>(sQuery).ToList();

        }
        public Dashboard GetDoctorDashboard()
        {
            Dashboard DashboardInfo = new Dashboard();
            using (IDbConnection dbConnection = _db)
            {
                if (dbConnection.State == ConnectionState.Closed)
                {
                    dbConnection.Open();
                }

                DashboardInfo = dbConnection.Query<Dashboard>("usp_GetDoctorDashboard", commandType: CommandType.StoredProcedure).FirstOrDefault();

            }
            return DashboardInfo;
        }
        public List<DashboardAppointmentList> GetbookedSlots()
        {
            string sQuery = @"SELECT		DISTINCT FORMAT (AppointmentFrom, 'MM/dd/yyyy ') AppointmentFrom,CommunicationType
                                FROM		T_Patient P
                                INNER JOIN	M_CommunicationType C
                                ON			P.CommunicationTypeFK=C.CommunicationTypeID
                                WHERE		AppointmentFrom>=GETDATE()
                                GROUP BY	AppointmentFrom,CommunicationType";
            return _db.Query<DashboardAppointmentList>(sQuery).ToList();
        }
        public List<DashboardAppointmentList> GetThisWeekConsulationList()
        {
            string sQuery = @"SELECT		ISNULL(FirstName,'')+' '+ISNULL(MiddleName,'')+' '+ISNULL(LastName,'') AS Name,FORMAT(AppointmentFrom,'hh:mm tt') AppointmentFrom,
			                                FORMAT(AppointmentTo,'hh:mm tt')AppointmentTo, datename(dw,AppointmentFrom) AS Day_Name,CommunicationType
                                FROM		T_Patient P
                                INNER JOIN	T_APP_USER U
                                ON			P.ReferenceID=U.UserID
                                INNER JOIN	M_CommunicationType C
                                ON			P.CommunicationTypeFK=C.CommunicationTypeID
                                WHERE		CAST(P.AppointmentFrom AS DATE)
				                                BETWEEN			CAST([dbo].[ufn_getServerDate]() AS DATE)
				                                AND				DATEADD(DAY, 8 - DATEPART(WEEKDAY, CAST([dbo].[ufn_getServerDate]() AS DATE)), CAST([dbo].[ufn_getServerDate]() AS DATE))";
            return _db.Query<DashboardAppointmentList>(sQuery).ToList();
        }
        public bool AddCommunicationType(CommunicationTypes model)
        {
            long _counter_updated = 0;
            string _query_update_communication_type = @"INSERT INTO [M_CommunicationType] ([CommunicationType] ,[Symbol] ,[Amount],[Is_Active]) VALUES (@CommunicationType ,@Symbol ,@Amount,@Is_Active);
                                                    SELECT CAST(SCOPE_IDENTITY() as bigint)";

            using (var connection = new SqlConnection(_db.ConnectionString))
            {
                connection.Open();
                using (var transaction = connection.BeginTransaction())
                {
                    _counter_updated = connection.Query<long>(_query_update_communication_type,
                     new
                     {
                         CommunicationType = model.CommunicationType,
                         Symbol = model.Symbol,
                         Amount = model.Amount,
                     }, transaction: transaction).Single();

                    if (_counter_updated > 0)
                    {
                        transaction.Commit();
                        return true;
                    }
                    else
                    {
                        transaction.Rollback();
                        return false;
                    }
                }
            }

        }
         public bool UpdateCommunicationType(CommunicationTypes model)
        {

            int result = 0;
            using (IDbConnection dbConnection = _db)
            {
                string sQuery = @"UPDATE M_CommunicationType SET CommunicationType=@CommunicationType,Symbol=@Symbol,Amount=@Amount,Is_Active=@Is_Active,Duration=@Duration WHERE CommunicationTypeID=@CommunicationTypeID";
                dbConnection.Open();
                result = dbConnection.Execute(sQuery, 
                    new {
                        CommunicationType = model.CommunicationType,
                        Symbol = model.Symbol,
                        Amount=model.Amount,
                        CommunicationTypeID=model.CommunicationTypeID,
                        Is_Active = model.Is_Active,
                        Duration=model.Duration
                    });
            }
            if(result>0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public List<TodaysAppointment> GetTodayAppointmentList(int CommunicationTypeID,int SearchType,int PatientID)
        {
            List<TodaysAppointment> PatientList = new List<TodaysAppointment>();
            using (IDbConnection dbConnection = _db)
            {
                if (dbConnection.State == ConnectionState.Closed)
                {
                    dbConnection.Open();
                }
                DynamicParameters parameter = new DynamicParameters();
                parameter.Add("@CommunicationTypeID", CommunicationTypeID);
                parameter.Add("@SearchType", SearchType);
                parameter.Add("@PatientID", PatientID);
                PatientList = dbConnection.Query<TodaysAppointment>("usp_GetAppointmentRequest", parameter, commandType: CommandType.StoredProcedure).ToList();

            }
            return PatientList;


        }
        public M_AppSetting GetAppSettings()
        {

            string sQuery = "SELECT * FROM M_AppSetting";
            return _db.Query<M_AppSetting>(sQuery).FirstOrDefault();
        }
        public List<ConsultationStatusModel> GetConsultationStatus()
        {

            string sQuery = "SELECT * FROM M_ConsultationStatus";
            return _db.Query<ConsultationStatusModel>(sQuery).ToList();
        }
        public bool AddConsultationDetail(ConsultationDetailModel model)
        {
            int Uploaded = 0;
            using (IDbConnection dbConnection = _db)
            {
                if (dbConnection.State == ConnectionState.Closed)
                {
                    dbConnection.Open();
                }

                StringBuilder strXML = new StringBuilder();
                strXML.Append("<PatientDocument>");
                strXML.Append("<DocumentPathList>");

                foreach (var item in model.DocumentPath)
                {
                    string filename = System.IO.Path.GetFileName(item.uri);
                    var fi = new FileInfo(item.uri);
                    var Extension = fi.Extension;

                    strXML.Append("<PatientDocumentDetails>");
                    strXML.Append("<DocumentPath>" + item.uri + "</DocumentPath>");
                    strXML.Append("<FileName>" + filename + "</FileName>");
                    strXML.Append("<DocumentType>" + Extension + "</DocumentType>");
                    strXML.Append("</PatientDocumentDetails>");

                }

                strXML.Append("</DocumentPathList>");
                strXML.Append("</PatientDocument>");

                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@PatientID", model.PatientID);
                parameters.Add("@ConsultationStatusID", model.ConsultationStatusID);
                parameters.Add("@ConsultationRemarks", model.ConsultationRemarks);
                parameters.Add("@CompleteDate", model.CompleteDate);
                parameters.Add("@XMLDoc", strXML.ToString());
                parameters.Add("UpdatedFlag", dbType: DbType.Int32, direction: ParameterDirection.Output);
                dbConnection.Execute("usp_AddConsulationDetailsByUser", parameters, commandType: CommandType.StoredProcedure);
                Uploaded = parameters.Get<int>("UpdatedFlag");

            }
            if (Uploaded == 1)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public List<AvailableDates> GetDatewiseTimeslots(int CommunicationTypeID,string date)
        {
            List<AvailableDates> List = new List<AvailableDates>();
            using (IDbConnection dbConnection = _db)
            {
                if (dbConnection.State == ConnectionState.Closed)
                {
                    dbConnection.Open();
                }
                DynamicParameters parameter = new DynamicParameters();
                parameter.Add("@CommunicationTypeID", CommunicationTypeID);
                 parameter.Add("@date", date);
                List = dbConnection.Query<AvailableDates>("usp_GetDatewiseTimeIntervals", parameter, commandType: CommandType.StoredProcedure).ToList();

            }
            return List;


        }
        public List<TimeSlotList> GetAllocatedTimeslots()
        {

            string sQuery = @"	SELECT		CommunicationTypeID,CommunicationType,Duration,FORMAT (AvailableDate, 'MM/dd/yyyy ') AS  AvailableDate
                                FROM		T_DoctorAvailabilityDetails DD
                                INNER JOIN	T_DoctorAvailability D
                                ON			DD.DoctorAvailabilityFK=D.DoctorAvailabilityID
                                INNER JOIN	M_CommunicationType C
                                ON			C.CommunicationTypeID=D.CommunicationTypeFK
                                WHERE		DD.AvailabilityTimeFrom>= CAST([dbo].[ufn_getServerDate]() AS DATETIME)
                                GROUP BY	CommunicationTypeID,CommunicationType,Duration,AvailableDate";
            return _db.Query<TimeSlotList>(sQuery).ToList();
        }
        public List<TimeSlotList> GetAllocatedTimeslotDetails(string AvailableDate,string CommunicationType)
        {

            string sQuery = @"	SELECT		CommunicationTypeID,CommunicationType,Duration,AvailableDate,
											CONVERT(nvarchar(10), CAST(DD.AvailabilityTimeFrom AS TIME), 0) AS AvailabilityTimeFrom,
											CONVERT(nvarchar(10), CAST(DD.AvailabilityTimeTo AS TIME), 0) AS AvailabilityTimeTo,DD.BookingStatus
                                FROM		T_DoctorAvailabilityDetails DD
                                INNER JOIN	T_DoctorAvailability D
                                ON			DD.DoctorAvailabilityFK=D.DoctorAvailabilityID
                                INNER JOIN	M_CommunicationType C
                                ON			C.CommunicationTypeID=D.CommunicationTypeFK
								WHERE		D.AvailableDate=" + AvailableDate+" AND			CommunicationType="+CommunicationType+ " AND DD.BookingStatus<>'B'";
            return _db.Query<TimeSlotList>(sQuery).ToList();
        }

        public string GetQuestionnaireReport(int UserID)
        {

            string report = "";
            using (IDbConnection dbConnection = _db)
            {
                if (dbConnection.State == ConnectionState.Closed)
                {
                    dbConnection.Open();
                }
                DynamicParameters parameter = new DynamicParameters();
                parameter.Add("@UserID", UserID);
                report = dbConnection.Query<string>("uspGetQuestionnaireReport", parameter, commandType: CommandType.StoredProcedure).FirstOrDefault();

            }
            return report;
        }
    } 
}
