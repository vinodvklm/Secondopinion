using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Dapper;
using System.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using SecondOpinionWeb.Models;

namespace SecondOpinionWeb.Repositories
{
    public class QuestionnaireRepository
    {
        
        private readonly IDbConnection _db;

        public QuestionnaireRepository(IConfiguration _config)
        {
            _db = new SqlConnection(_config.GetConnectionString("SQLConnection"));
        }
        public QuestionnaireRepository(string constr)
        {
            _db = new SqlConnection(constr);
        }
        public List<Form> GetFormDetails(int FormID)
        {

         string   sQuery="SELECT FormID,FormName,FormType,IsActive FROM M_Form WHERE FormID='"+FormID+"'";
         return _db.Query<Form>(sQuery).ToList();
        }
        public List<Question> GetQuestions(int FormID,int SectionNumber)
        {

         string   sQuery="SELECT  QuestionID,FormFK,ISNULL(QuestionTitle,'') QuestionTitle, "+
                        " InputControlType,InputDataType,IsMandatory,ISNULL(CreatedBy,0)CreatedBy, "+
                        " IsActive,HasComments,ISNULL(PlaceholderText,'')PlaceholderText, InputLabel,ColumnWidth,"+
                        "IsSection,TableType,SectionNumber,SectionHeader,DisplayControlType,DisplayHeader,ISNULL(MaxLength,0)MaxLength  FROM T_Question WHERE FormFK='" + FormID+ "' AND SectionNumber='"+ SectionNumber + "' AND ISNULL(IsActive,0)=1";
         return _db.Query<Question>(sQuery).ToList();
        }
        public List<QuestionOption> GetQuestionOptions(int QuestionID)
        {

         string   sQuery="SELECT QuestionOptionID,ISNULL(OptionText,'') OptionText,QuestionFK FROM T_QuestionOption WHERE QuestionFK='"+QuestionID+"'";
         return _db.Query<QuestionOption>(sQuery).ToList();
        }
        public List<QuestionParentBranch> GetParentBranches(int QuestionID)
        {

         string   sQuery="SELECT QuestionBranchID,ParentQuestionFK,ParentQuestionOptionFK,ChildQuestionFK FROM T_QuestionBranch WHERE ChildQuestionFK='"+QuestionID+"'";
         return _db.Query<QuestionParentBranch>(sQuery).ToList();
        }
        public List<QuestionChildBranch> GetChildBranches(int QuestionID)
        {

         string   sQuery="SELECT QuestionBranchID,ParentQuestionFK,ParentQuestionOptionFK,ChildQuestionFK FROM T_QuestionBranch WHERE ParentQuestionFK='"+QuestionID+"'";
         return _db.Query<QuestionChildBranch>(sQuery).ToList();
        }

        public bool SaveQuestionnaire(QuestionnaireInfo model)
        {
            int rowAffected=0;
            using (IDbConnection dbConnection = _db)
            {
                if (dbConnection.State == ConnectionState.Closed)
                {
                    dbConnection.Open();
                } 

                StringBuilder strXML=new StringBuilder();
                strXML.Append("<FormSubmission>");
                strXML.Append("<FormSubmissionDetails>");
                strXML.Append("<FormID>"+model.FormID+"</FormID>");
                strXML.Append("<UserID>"+model.UserID+"</UserID>");
                strXML.Append("<PatientID>" + model.PatientID + "</PatientID>");
                strXML.Append("<SectionNumber>" + model.SectionNumber + "</SectionNumber>");
                strXML.Append("</FormSubmissionDetails>");
                #region Answer list
                strXML.Append("<AnswerList>");
                foreach (var item in model.FormSubmitted)
                {
                    strXML.Append("<AnswerListDetails>");
                    strXML.Append("<QuestionFk>"+item.QuestionFk+"</QuestionFk>");

                    strXML.Append("<QuestionOptionFk>"+item.QuestionOptionFk+"</QuestionOptionFk>");
                    strXML.Append("<Answer>"+item.Answer+"</Answer>");
                    strXML.Append("<Comments>"+item.Comments+"</Comments>");
                    strXML.Append("</AnswerListDetails>");
                   
                }
                strXML.Append("</AnswerList>");
                #endregion

                #region PainMedication
                strXML.Append("<PainMedicationList>");
                foreach (var item in model.PainMedicationList)
                {
                    strXML.Append("<PainMedicationListDetails>");
                    strXML.Append("<Medication>"+item.Medication+"</Medication>");
                    strXML.Append("<Dose>"+item.Dose+"</Dose>");
                    strXML.Append("<Frequency>"+item.Frequency+"</Frequency>");
                    strXML.Append("<Comment>"+item.Comment+"</Comment>");
                    strXML.Append("</PainMedicationListDetails>");
                }
                strXML.Append("</PainMedicationList>");
                #endregion
                #region PainTreatmentHistory

                strXML.Append("<PainTreatmentHistoryList>");
                foreach (var item in model.PainTreatmentHistoryList)
                {
                    strXML.Append("<PainTreatmentHistoryListDetails>");
                    strXML.Append("<TreatmentType>"+item.TreatmentType+"</TreatmentType>");
                    strXML.Append("<Region>"+item.Region+"</Region>");
                    strXML.Append("<ProceduresLastYear>"+item.ProceduresLastYear+"</ProceduresLastYear>");
                    strXML.Append("<DateOfLastProcedure>"+item.DateOfLastProcedure+"</DateOfLastProcedure>");
                    strXML.Append("<AmountOfPainRelief>"+item.AmountOfPainRelief+"</AmountOfPainRelief>");
                    strXML.Append("<SideEffect>"+item.SideEffect+"</SideEffect>");
                    strXML.Append("</PainTreatmentHistoryListDetails>");
                }
                strXML.Append("</PainTreatmentHistoryList>");
                
                #endregion
                
                #region Medication
                strXML.Append("<MedicationList>");
                foreach (var item in model.MedicationsList)
                {
                    strXML.Append("<MedicationListDetails>");
                    strXML.Append("<MedicationName>"+item.MedicationName+"</MedicationName>");
                    strXML.Append("<Dosage>"+item.Dosage+"</Dosage>");
                    strXML.Append("<Medicationfrequency>"+item.Medicationfrequency+"</Medicationfrequency>");
                    strXML.Append("</MedicationListDetails>");
                }
                strXML.Append("</MedicationList>");
                #endregion

                #region TestInvestigation
                strXML.Append("<TestInvestigationList>");
                foreach (var item in model.TestInvestigationList)
                {
                    strXML.Append("<TestInvestigationListDetails>");
                    strXML.Append("<Investigation>"+item.Investigation+"</Investigation>");
                    strXML.Append("<Region1>"+item.Region1+"</Region1>");
                    strXML.Append("<Recentdate1>"+item.Recentdate1+"</Recentdate1>");
                    strXML.Append("<Region2>"+item.Region2+"</Region2>");
                    strXML.Append("<Recentdate2>"+item.Recentdate2+"</Recentdate2>");
                    strXML.Append("</TestInvestigationListDetails>");
                }
                strXML.Append("</TestInvestigationList>");
                #endregion

                #region PhysiciansConsulted
                strXML.Append("<PhysiciansConsultedList>");
                foreach (var item in model.PhysiciansConsultedList)
                {
                    strXML.Append("<PhysiciansConsultedListDetails>");
                    strXML.Append("<Speciality>"+item.Speciality+"</Speciality>");
                    strXML.Append("<Name>"+item.Name+"</Name>");
                    strXML.Append("<Treatment>"+item.Treatment+"</Treatment>");
                    strXML.Append("<Painrelief>"+item.Painrelief+"</Painrelief>");
                    strXML.Append("<Lastinterventiondate>"+item.Lastinterventiondate+"</Lastinterventiondate>");
                    strXML.Append("</PhysiciansConsultedListDetails>");
                }
                strXML.Append("</PhysiciansConsultedList>");

                #endregion

                #region Pain location
                strXML.Append("<PainLocationList>");
                foreach (var item in model.PainLocationList)
                {
                    strXML.Append("<PainLocationListDetails>");
                    strXML.Append("<Location>"+item.Location+"</Location>");
                    strXML.Append("<Painrightnow>"+item.Painrightnow+"</Painrightnow>");
                    strXML.Append("<Thebestitgets>"+item.Thebestitgets+"</Thebestitgets>");
                    strXML.Append("<Theworstitgets>"+item.Theworstitgets+"</Theworstitgets>");
                    strXML.Append("</PainLocationListDetails>");
                }
                strXML.Append("</PainLocationList>");

                #endregion

                #region Pain Spots
                strXML.Append("<PainSpotList>");
                foreach (var item in model.PainSpotList)
                {
                    strXML.Append("<PainSpotListDetails>");
                    strXML.Append("<Enabled>"+item.Enabled+"</Enabled>");
                    strXML.Append("<Front>"+item.Front+"</Front>");
                    strXML.Append("<Pos_X>"+item.Pos_X+"</Pos_X>");
                    strXML.Append("<Pos_Y>"+item.Pos_Y+"</Pos_Y>");
                    strXML.Append("<QuestionFK>" + item.questionID + "</QuestionFK>");
                    strXML.Append("<Description>" + item.Description + "</Description>");
                    strXML.Append("</PainSpotListDetails>");
                }
                strXML.Append("</PainSpotList>");
                #endregion
                strXML.Append("</FormSubmission>");

                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@XMLDoc",strXML.ToString());
                rowAffected=dbConnection.Execute("usp_SaveQuestionnaireByUser",parameters,commandType:CommandType.StoredProcedure);
                
                
            }
            if(rowAffected>1)
            {
                return true;
            }
            else
            {
                return false;
            }

        }

        public int GetLastSavedSection(int FormID, int UserID,int PatientID)
        {
           
            string sQuery = @"SELECT		ISNULL(MAX(FD.SectionNumber),0)
                                FROM T_FormSubmission F
                                INNER JOIN T_FormSubmissionDetail FD
                                ON          F.FormSubmissionID = FD.FormSubmissionFK
                                WHERE F.FormFK = @FormID
                                AND F.SubmittedBy = @UserID
                                AND     F.PatientFK=@PatientID";
           return _db.Query<int>(sQuery, new { FormID = FormID, UserID = UserID, PatientID= PatientID }).FirstOrDefault(); 

        }
        public List<FormSubmitted> GetSavedSection(int FormID, int UserID, int PatientID, int SectionNumber)
        {
            //F.FormSubmissionID,F.FormFk,F.PatientFK,FD.SectionNumber
            string sQuery = @"SELECT		
                                FD.QuestionFk,QuestionOptionFk,Answer
                                FROM T_FormSubmission F
                                INNER JOIN T_FormSubmissionDetail FD
                                ON          F.FormSubmissionID = FD.FormSubmissionFK
                                WHERE F.FormFK = @FormID
                                AND F.SubmittedBy = @UserID
                                AND     F.PatientFK=@PatientID
								AND FD.SectionNumber=@SectionNumber
								ORDER BY FormSubmissionDetailID";
            return _db.Query<FormSubmitted>(sQuery, new { FormID = FormID, UserID = UserID, PatientID = PatientID, SectionNumber= SectionNumber }).ToList();

        }
        /// <summary>
        /// Get Painlocations saved in section 3
        /// </summary>
        /// <param name="FormID"></param>
        /// <param name="UserID"></param>
        /// <param name="PatientID"></param>
        /// <param name="SectionNumber"></param>
        /// <returns></returns>
        public List<PainLocation> GetSavedPainLocation(int FormID, int UserID, int PatientID, int SectionNumber=0)
        {
            //F.FormSubmissionID,F.FormFk,F.PatientFK,FD.SectionNumber
            string sQuery = @"select * from T_PainLocationDetail
                                WHERE	PainLocationFK IN(SELECT PainLocationID FROM T_PainLocation 
                                WHERE FormSubmissionFK IN(select FormSubmissionID from T_FormSubmission
                                WHERE FormFK=@FormID AND SubmittedBy=@UserID AND PatientFK=@PatientID
                                ))
								ORDER BY PainLocationFK";
            return _db.Query<PainLocation>(sQuery, new { FormID = FormID, UserID = UserID, PatientID = PatientID, SectionNumber = SectionNumber }).ToList();

        }
        public List<PainSpots> GetSavedPainSpots(int FormID, int UserID, int PatientID, int SectionNumber = 0)
        {
            //F.FormSubmissionID,F.FormFk,F.PatientFK,FD.SectionNumber
            string sQuery = @"select * from T_PainSpotDetail
                                WHERE	PainSpotFK IN(SELECT PainSpotID FROM T_PainSpot
                                WHERE FormSubmissionFK IN(select FormSubmissionID from T_FormSubmission
                                WHERE FormFK=@FormID AND SubmittedBy=@UserID AND PatientFK=@PatientID
                                ))
								ORDER BY PainSpotFK";
            return _db.Query<PainSpots>(sQuery, new { FormID = FormID, UserID = UserID, PatientID = PatientID, SectionNumber = SectionNumber }).ToList();

        }
        public List<PainMedication> GetSavedPainMedications(int FormID, int UserID, int PatientID, int SectionNumber = 0)
        {
            //F.FormSubmissionID,F.FormFk,F.PatientFK,FD.SectionNumber
            string sQuery = @"select *,PeriodApproxiamtelyTaken Approxmity from T_PainMedicationDetail
                                WHERE PainMedicationFK IN(SELECT PainMedicationID FROM T_PainMedication 
                                WHERE FormSubmissionFK IN(select FormSubmissionID from T_FormSubmission
                                WHERE FormFK=@FormID AND SubmittedBy=@UserID AND PatientFK=@PatientID
                                ))
								ORDER BY PainMedicationFK";
            return _db.Query<PainMedication>(sQuery, new { FormID = FormID, UserID = UserID, PatientID = PatientID, SectionNumber = SectionNumber }).ToList();

        }
    } 
}
