using System;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Dapper;
using System.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using SecondOpinionWeb.Models;

namespace SecondOpinionWeb.Repositories
{
    public class UserRepository
    {

        private readonly IDbConnection _db;
      
        public UserRepository(IConfiguration _config)
        {
            _db = new SqlConnection(_config.GetConnectionString("SQLConnection"));
        }
        public UserRepository(string constr)
        {
            _db = new SqlConnection(constr);
        }
      

        public UserRegModel AddUser(UserModel user)
        {
            UserRegModel registerInfo = new UserRegModel(); 

            byte[] passwordHash, salt,EncryptedPassword;
            CreatePasswordHash(user.Password, out passwordHash, out salt);
            EncryptedPassword=passwordHash;

            try
            {
                using (IDbConnection dbConnection = _db)
                {
                    if (dbConnection.State == ConnectionState.Closed)
                    {
                        dbConnection.Open();
                    }
                    DynamicParameters parameters = new DynamicParameters();
                    parameters.Add("@FirstName", user.FirstName);
                    parameters.Add("@MiddleName", user.MiddleName);
                    parameters.Add("@LastName", user.LastName);
                    parameters.Add("@Gender", user.Gender);
                    parameters.Add("@Age", user.Age);
                    parameters.Add("@DOB", user.DOB);
                    parameters.Add("@Email", user.Email);
                    parameters.Add("@Username", user.Email.ToLower());
                    parameters.Add("@Password", EncryptedPassword);
                    parameters.Add("@Salt", salt);
                    parameters.Add("@MobileNumber", user.MobileNumber);
                    parameters.Add("@OfficialNumber", user.OfficialNumber);
                    parameters.Add("@WhatsAppNumber", user.WhatsAppNumber);
                    parameters.Add("@Address", user.Address);
                    parameters.Add("@Latitude", user.Latitude);
                    parameters.Add("@Longitude", user.Longitude);
                    parameters.Add("@StreetName", user.StreetName);
                    parameters.Add("@CityName", user.CityName);
                    parameters.Add("@Pincode", user.Pincode);
                    parameters.Add("@CountryCode", user.CountryCode);
                    registerInfo = dbConnection.Query<UserRegModel>("usp_AddUser", parameters, commandType: CommandType.StoredProcedure).FirstOrDefault();

                }
                return registerInfo;
            }
            catch(Exception ex)
            {
                return registerInfo;
            }

        }
        public UserModel UpdateUser(UserModel user)
        {
            
            UserModel userInfo = new UserModel(); 

            using (IDbConnection dbConnection = _db) 
            {
                 if (dbConnection.State == ConnectionState.Closed)
                 {
                     dbConnection.Open();
                 }  

                StringBuilder strXML=new StringBuilder();
                strXML.Append("<User>");
                strXML.Append("<UserDetails>");
                strXML.Append("<UserID>"+user.UserID+"</UserID>");
                strXML.Append("<MiddleName>"+user.MiddleName+"</MiddleName>");
                strXML.Append("<LastName>"+user.LastName+"</LastName>");
                strXML.Append("<Gender>"+user.Gender+"</Gender>");
                strXML.Append("<Age>"+user.Age+"</Age>");
                strXML.Append("<MobileNumber>"+user.MobileNumber+"</MobileNumber>");
                strXML.Append("<OfficialNumber>"+user.OfficialNumber+"</OfficialNumber>");
                strXML.Append("<WhatsAppNumber>"+user.WhatsAppNumber+"</WhatsAppNumber>");
                strXML.Append("<Address>"+user.Address+"</Address>");
                strXML.Append("<StreetName>"+user.StreetName+"</StreetName>");
                strXML.Append("<CityName>"+user.CityName+"</CityName>");
                strXML.Append("<Pincode>"+user.Pincode+"</Pincode>");
                strXML.Append("<Remarks>"+user.Remarks+"</Remarks>");
                strXML.Append("</UserDetails>");
                strXML.Append("</User>");


                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@XMLDoc",strXML.ToString());

                userInfo=dbConnection.Query<UserModel>("usp_UpdateUser", parameters, commandType:CommandType.StoredProcedure).FirstOrDefault();
                
                
            }
           return userInfo;
        }

        private void CreatePasswordHash(string password, out byte[] passwordHash, out byte[] salt)
        {
            using (var hmac = new System.Security.Cryptography.HMACSHA512())
            {
                salt = hmac.Key;
                passwordHash = hmac.ComputeHash(System.Text.Encoding.UTF8.GetBytes(password));
            }
        }
   
        public UserModel UserExists(string email)
        {
            UserModel UserModel=new UserModel();
            string sQuery="select Username from T_APP_USER WHERE Username ='"+email+"'";
            return _db.Query<UserModel>(sQuery, new { email = email }).FirstOrDefault();
        }
       
        public List<Dependent> GetDependent(int UserID)
        {
            DateTime Today = DateTime.Now;
            string   sQuery= @"SELECT		U.UserID,ISNULL(Relationship,'')AS Relationship,U.*,
										CASE ISNULL(Relationship,'') WHEN 'MySelf' THEN 1 ELSE 0 END AS IsSelfDependent,
										CASE ISNULL(Dep.UserFK,0) WHEN 0 THEN 0 ELSE 1 END AS DocumentExist,
                                        ISNULL(F.BookingCount,0) AS FreeBookingCount
                            FROM        T_APP_USER U
                            INNER JOIN  T_TR_USER_ROLE R
                            ON          U.UserID = R.User_FK
                            INNER JOIN  T_UserDependent D
                            ON          U.UserID = D.UserFK
                            INNER JOIN  T_APP_USER P
                            ON          D.ParentFK = P.UserID
							LEFT JOIN	(SELECT		D.UserFK
										FROM		T_UserDocument D
										INNER JOIN	T_UserDocumentDetails DD
										ON			D.UserDocumentID=DD.UserDocumentFK
										WHERE		D.UserFK IN (SELECT UserFK FROM T_UserDependent WHERE ParentFK=@UserFK)
										GROUP BY	D.UserFK) Dep
							ON			D.UserFK=Dep.UserFK
                            LEFT JOIN	(
											SELECT		TOP 1 BookingCount,UserFK
											FROM		T_PatientConsultationValidity 
											WHERE		UserFK=@UserFK AND ISNULL(BookingCount,0)<4 AND CommunicationTypeFK=3 
											AND			@Today BETWEEN ValidFrom AND ValidTo
											ORDER BY	PatientConsultationValidityID DESC
										)F
							ON			U.UserID=F.UserFK
							WHERE		P.UserID=@UserFK";
            return _db.Query<Dependent>(sQuery, new{ UserFK= UserID, Today=Today }).ToList();
        }
        public int AddDependent(Dependent model)
        {
            int DependentID = 0;
            try
            {
               
                using (IDbConnection dbConnection = _db)
                {
                    if (dbConnection.State == ConnectionState.Closed)
                    {
                        dbConnection.Open();
                    }
                    DynamicParameters parameters = new DynamicParameters();
                    parameters.Add("@ParentFK", model.UserID);
                    parameters.Add("@Relationship", model.Relationship);
                    parameters.Add("@FirstName", model.FirstName);
                    parameters.Add("@MiddleName", model.MiddleName);
                    parameters.Add("@LastName", model.LastName);
                    parameters.Add("@Gender", model.Gender);
                    parameters.Add("@Age", model.Age);
                    parameters.Add("DependentID_OUT", dbType: DbType.Int32, direction: ParameterDirection.Output);
                    dbConnection.Execute("usp_AddUserDependent", parameters, commandType: CommandType.StoredProcedure);
                    DependentID = parameters.Get<int>("DependentID_OUT");
                    return DependentID;
                }
            }
            catch(Exception ex)
            {
                return 0;
            }

            
        }

        public int UpdatePasswordToken(string Username,string token)
        {
            int result = 0;
            using (IDbConnection dbConnection = _db)
            {
                string sQuery = "UPDATE T_APP_USER SET PasswordToken = @Token"
                               + " WHERE Username = @Username";
                dbConnection.Open();
                result = dbConnection.Execute(sQuery, new { Token =token, Username =Username});
            }
            return result;
        }

        public UserProfile GetUserProfile(int UserID)
        {
            UserProfile UserProfile=new UserProfile();

            using (IDbConnection dbConnection = _db) 
            {
                 if (dbConnection.State == ConnectionState.Closed)
                 {
                     dbConnection.Open();
                 }  
                 DynamicParameters parameters = new DynamicParameters(); 
                 parameters.Add("@UserID",UserID);
                 UserProfile=dbConnection.Query<UserProfile>("usp_GetUserProfile", parameters, commandType:CommandType.StoredProcedure).FirstOrDefault(); 

            }
            return UserProfile;
        }
        public UserDashboardModel GetUserDashboard(int UserID)
        {
            UserDashboardModel Model = new UserDashboardModel();

            using (IDbConnection dbConnection = _db)
            {
                if (dbConnection.State == ConnectionState.Closed)
                {
                    dbConnection.Open();
                }
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@UserID", UserID);

                var reader = dbConnection.QueryMultiple("usp_GetPatientDashboard", param: parameters, commandType: CommandType.StoredProcedure);
                Model.DashBoardCardInfo = reader.Read<DashBoardCardInfo>().FirstOrDefault();
                Model.BookingList= reader.Read<UserBookingModel>().ToList();

            }
            return Model;
        }
    } 
}
