using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Dapper;
using System.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using SecondOpinionWeb.Models;

namespace SecondOpinionWeb.Repositories
{
    public class AuthRepository
    {
        
        private readonly IDbConnection _db;

        public AuthRepository(IConfiguration _config)
        {
            _db = new SqlConnection(_config.GetConnectionString("SQLConnection"));
        }
        public AuthRepository(string constr)
        {
            _db = new SqlConnection(constr);
        }
      
        public LoginModel Login(string email, string password)
        {
            LoginModel userInfo = new LoginModel(); 
            
            using (IDbConnection dbConnection = _db) 
            {
                    if (dbConnection.State == ConnectionState.Closed)
                    {
                        dbConnection.Open();
                    }  
                    DynamicParameters parameter = new DynamicParameters();  
                    parameter.Add("@Username", email);  
                    userInfo = dbConnection.Query<LoginModel>("usp_UserLogin", parameter, commandType:CommandType.StoredProcedure).FirstOrDefault(); 
            }
            if(userInfo==null)
                return null;
            
            if (!VerifyPasswordHash(password, userInfo.Password, userInfo.Salt))
                return null;

            return userInfo; 
        }

        public bool VerifyPasswordHash(string password, byte[] passwordHash, byte[] salt)
        {
            using (var hmac = new System.Security.Cryptography.HMACSHA512(salt))
            {
                var computedHash = hmac.ComputeHash(System.Text.Encoding.UTF8.GetBytes(password));
                for (int i = 0; i < computedHash.Length; i++)
                {
                    if (computedHash[i] != passwordHash[i]) return false;
                }
            }
            return true;
        }
       
  
    } 
}
