import { TestBed } from '@angular/core/testing';

import { UseruserRegistrationDialogService } from './useruser-registration-dialog.service';

describe('UseruserRegistrationDialogService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: UseruserRegistrationDialogService = TestBed.get(UseruserRegistrationDialogService);
    expect(service).toBeTruthy();
  });
});
