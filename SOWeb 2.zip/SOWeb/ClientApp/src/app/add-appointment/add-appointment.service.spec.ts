import { TestBed } from '@angular/core/testing';

import { AddAppointmentService } from './add-appointment.service';

describe('AddAppointmentService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: AddAppointmentService = TestBed.get(AddAppointmentService);
    expect(service).toBeTruthy();
  });
});
