import { TestBed } from '@angular/core/testing';

import { FullcalendarService } from './fullcalendar.service';

describe('FullcalendarService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: FullcalendarService = TestBed.get(FullcalendarService);
    expect(service).toBeTruthy();
  });
});
