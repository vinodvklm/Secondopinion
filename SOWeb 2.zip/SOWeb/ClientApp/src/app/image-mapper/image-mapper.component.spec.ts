import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ImageMapperComponent } from './image-mapper.component';

describe('ImageMapperComponent', () => {
  let component: ImageMapperComponent;
  let fixture: ComponentFixture<ImageMapperComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ImageMapperComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ImageMapperComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
