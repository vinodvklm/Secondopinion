import { Routes } from '@angular/router';

import { DashboardComponent } from '../../dashboard/dashboard.component';
import { UserProfileComponent } from '../../user-profile/user-profile.component';
import { AddDependentComponent } from '../../add-dependent/add-dependent.component';
import { DocumentUploadComponent} from '../../document-upload/document-upload.component';
import { ProfileComponent} from '../../profile/profile.component';
import { AddAppointmentComponent } from '../../add-appointment/add-appointment.component';
import { MyDocumentsComponent } from '../../my-documents/my-documents.component';
import { BookingHistoryComponent } from '../../booking-history/booking-history.component';
import { DependencyCircleComponent } from '../../dependency-circle/dependency-circle.component';
import { ThanksComponent } from '../../common/thanks/thanks.component';

export const SecondOpinionLayoutRoutes: Routes = [
   
    { 
       path: 'user-profile',   component: UserProfileComponent,
    }, 
    { 
        path: 'dashboard',   component: DashboardComponent,
    },
    { 
        path: 'add_dependent',   component: AddDependentComponent,
    },
    { 
        path: 'upload_document',   component: DocumentUploadComponent,
    },
    { 
        path: 'profile',   component: ProfileComponent,
    },
    { 
        path: 'appointment',   component: AddAppointmentComponent,
    },
    { 
        path: 'mydocuments',   component: MyDocumentsComponent,
    },
    { 
        path: 'bookinghistory',   component: BookingHistoryComponent,
    },
    { 
        path: 'dependencycircle',   component: DependencyCircleComponent,
    },
    { 
        path: 'thanks',   component: ThanksComponent,
    },
];
