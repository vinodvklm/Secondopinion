import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SecondOpinionLayoutComponent } from './second-opinion-layout.component';

describe('SecondOpinionLayoutComponent', () => {
  let component: SecondOpinionLayoutComponent;
  let fixture: ComponentFixture<SecondOpinionLayoutComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SecondOpinionLayoutComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SecondOpinionLayoutComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
