import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SecondOpinionLayoutRoutes } from './second-opinion-layout.routing';

import { DashboardComponent } from '../../dashboard/dashboard.component';
import { UserProfileComponent } from '../../user-profile/user-profile.component';
import { AddDependentComponent } from '../../add-dependent/add-dependent.component';
import { DocumentUploadComponent } from '../../document-upload/document-upload.component';
import { ProfileComponent } from '../../profile/profile.component';
import { AddAppointmentComponent } from '../../add-appointment/add-appointment.component';
import { MyDocumentsComponent } from '../../my-documents/my-documents.component';
import { BookingHistoryComponent } from '../../booking-history/booking-history.component';
import { DependencyCircleComponent } from '../../dependency-circle/dependency-circle.component';
import { ThanksComponent } from '../../common/thanks/thanks.component';


import {MatButtonModule} from '@angular/material/button';
import {MatInputModule} from '@angular/material/input';
import {MatRippleModule} from '@angular/material/core';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatTooltipModule} from '@angular/material/tooltip';
import {MatSelectModule} from '@angular/material/select';
import { MatRadioModule} from '@angular/material/radio'
import { MatCheckboxModule } from '@angular/material/checkbox';

import { NgxDropzoneModule } from 'ngx-dropzone';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';

import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatStepperModule } from '@angular/material/stepper';

import { MatTableModule } from '@angular/material/table';
import { MatPaginatorModule } from '@angular/material/paginator';
import {MatChipsModule} from '@angular/material/chips';
import { MatCardModule} from '@angular/material/card';
import {MatExpansionModule} from '@angular/material/expansion';
import { MatIconModule } from '@angular/material/icon';
@NgModule({
  
  declarations: [
  
    UserProfileComponent,
    DashboardComponent,
    AddDependentComponent,
    DocumentUploadComponent,
    ProfileComponent,
    AddAppointmentComponent,
    MyDocumentsComponent,
    BookingHistoryComponent,
    DependencyCircleComponent,
    ThanksComponent
  ],
  imports: [
    CommonModule,
    RouterModule.forChild(SecondOpinionLayoutRoutes),
    FormsModule,
    ReactiveFormsModule,
    MatButtonModule,
    MatRippleModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatTooltipModule,
    NgxDropzoneModule,
    MatRadioModule,
    MatCheckboxModule,
    MatProgressSpinnerModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatStepperModule,
    MatTableModule,
    MatPaginatorModule,
    MatChipsModule,
    MatCardModule,
    MatExpansionModule,
    MatIconModule
  ],
  providers: [
    MatDatepickerModule
  ],
})

export class SecondOpinionLayoutModule {}
