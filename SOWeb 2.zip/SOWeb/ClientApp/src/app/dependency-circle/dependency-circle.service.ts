import { environment } from './../../environments/environment';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class DependencyCircleService {

  baseUrl: any;
  constructor(private http: HttpClient) { 
    this.baseUrl = environment.url;
  }
  getDependentList(id) {
    return this.http.get(this.baseUrl + `api/User/get_dependent?UserID=`+id);
  }
}
