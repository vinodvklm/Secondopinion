import { TestBed } from '@angular/core/testing';

import { DependencyCircleService } from './dependency-circle.service';

describe('DependencyCircleService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: DependencyCircleService = TestBed.get(DependencyCircleService);
    expect(service).toBeTruthy();
  });
});
