import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DependencyCircleComponent } from './dependency-circle.component';

describe('DependencyCircleComponent', () => {
  let component: DependencyCircleComponent;
  let fixture: ComponentFixture<DependencyCircleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DependencyCircleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DependencyCircleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
