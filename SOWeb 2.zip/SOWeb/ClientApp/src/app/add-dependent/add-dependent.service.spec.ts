import { TestBed } from '@angular/core/testing';

import { AddDependentService } from './add-dependent.service';

describe('AddDependentService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: AddDependentService = TestBed.get(AddDependentService);
    expect(service).toBeTruthy();
  });
});
