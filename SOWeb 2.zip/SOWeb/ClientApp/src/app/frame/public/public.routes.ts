
import { ThanksMobileComponent } from '../../common/thanks-mobile/thanks-mobile.component';
import { QuestionnaireComponent } from '../../questionnaire/questionnaire.component';
import { BodyMarkerComponent } from '../../common/body-marker/body-marker.component';
import { DicomComponent } from '../../dicom/dicom.component';
import { UserRegistrationComponent } from '../../user-registration/user-registration.component';

import { Routes } from '@angular/router';
export const PUBLIC_ROUTES: Routes = [
  // { path: '', component: UnauthorizedComponent, pathMatch: 'full' },
  { path: '',component: UserRegistrationComponent ,pathMatch: 'full',}, 
  { path: 'login', component: UserRegistrationComponent },
  { path: 'thanks-mob', component: ThanksMobileComponent },
  { path: 'questionnaire/:id', component: QuestionnaireComponent},
  { path: 'bodyMarker', component: BodyMarkerComponent },

  { path: 'imgviewer', component: DicomComponent },
];
