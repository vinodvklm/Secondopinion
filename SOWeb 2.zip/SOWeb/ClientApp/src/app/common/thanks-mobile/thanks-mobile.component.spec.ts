import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ThanksMobileComponent } from './thanks-mobile.component';

describe('ThanksMobileComponent', () => {
  let component: ThanksMobileComponent;
  let fixture: ComponentFixture<ThanksMobileComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ThanksMobileComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ThanksMobileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
