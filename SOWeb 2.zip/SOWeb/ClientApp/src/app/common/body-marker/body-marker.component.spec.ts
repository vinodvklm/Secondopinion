import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BodyMarkerComponent } from './body-marker.component';

describe('BodyMarkerComponent', () => {
  let component: BodyMarkerComponent;
  let fixture: ComponentFixture<BodyMarkerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BodyMarkerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BodyMarkerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
