import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PaypalWebviewComponent } from './paypal-webview.component';

describe('PaypalWebviewComponent', () => {
  let component: PaypalWebviewComponent;
  let fixture: ComponentFixture<PaypalWebviewComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PaypalWebviewComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PaypalWebviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
