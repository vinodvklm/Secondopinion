import { TestBed } from '@angular/core/testing';

import { MyDocumentsService } from './my-documents.service';

describe('MyDocumentsService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: MyDocumentsService = TestBed.get(MyDocumentsService);
    expect(service).toBeTruthy();
  });
});
