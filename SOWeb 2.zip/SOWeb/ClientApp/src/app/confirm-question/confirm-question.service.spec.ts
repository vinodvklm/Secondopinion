import { TestBed } from '@angular/core/testing';

import { ConfirmQuestionService } from './confirm-question.service';

describe('ConfirmQuestionService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ConfirmQuestionService = TestBed.get(ConfirmQuestionService);
    expect(service).toBeTruthy();
  });
});
