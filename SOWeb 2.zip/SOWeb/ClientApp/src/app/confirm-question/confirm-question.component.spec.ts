import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfirmQuestionComponent } from './confirm-question.component';

describe('ConfirmQuestionComponent', () => {
  let component: ConfirmQuestionComponent;
  let fixture: ComponentFixture<ConfirmQuestionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConfirmQuestionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConfirmQuestionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
