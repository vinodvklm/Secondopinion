  function PostMessageToReact(){
      
  
      var OS='';
      var userAgent = navigator.userAgent || navigator.vendor || window.opera;
      if (userAgent.match(/iPad/i) || userAgent.match(/iPhone/i) || userAgent.match(/iPod/i)) {
        OS='iOS';

      }
      else if (userAgent.match(/Android/i)) {
          OS='Android';
      }
      else {
        OS='Unknown';
      }
      console.log(OS);
      console.log('external js');
      try {
        var messageToPost = {};
        messageToPost.status = 1;
        messageToPost.message = 'success';

        if(OS == 'iOS'){
          window.ReactNativeWebView.postMessage(JSON.stringify(messageToPost));//for react
            webkit.messageHandlers.FormSaveSaveButtonCallBack.postMessage(messageToPost);
        }
        else if (OS== 'Android') {
          window.ReactNativeWebView.postMessage(JSON.stringify(messageToPost));//for react
          window.JSInterface.FormSaveButtonClick(messageToPost.status,messageToPost.message);
        }
        else { return; }

    } catch (err) {
      console.log(err);
        console.log('error');
    }

  }



  function PayPalPostMessageToReact(messageToPost){
    var OS='';
    var userAgent = navigator.userAgent || navigator.vendor || window.opera;
    if (userAgent.match(/iPad/i) || userAgent.match(/iPhone/i) || userAgent.match(/iPod/i)) {
      OS='iOS';

    }
    else if (userAgent.match(/Android/i)) {
        OS='Android';
    }
    else {
      OS='Unknown';
    }
   
    try {

      console.log(messageToPost);

      console.log(JSON.stringify(messageToPost));

      if(OS == 'iOS'){
        window.ReactNativeWebView.postMessage(JSON.stringify(messageToPost));//for react
          webkit.messageHandlers.FormSaveSaveButtonCallBack.postMessage(messageToPost);
      }
      else if (OS== 'Android') {
        window.ReactNativeWebView.postMessage(JSON.stringify(messageToPost));//for react
        window.JSInterface.FormSaveButtonClick(messageToPost.status,messageToPost.message);
      }
      else { return; }

  } catch (err) {
    console.log(err);
      console.log('error');
  }

  }