export const environment = {
  production: true,
  url:'https://secondopinionweb.azurewebsites.net/',
  
  //staging
  paypalClientId:'AWnuagGj31UCpRvgklv3zLqopfbw2x5elH6IO3EQv9KMJyd3DD9ltv--EuXxTWH1siXfH76EwgdmhjF0'
};
